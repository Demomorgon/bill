// ignore_for_file: file_names

import 'package:flutter/services.dart';

class OrientacionPlataforma {
  DeviceOrientation orientacion() => DeviceOrientation.landscapeRight;
}
