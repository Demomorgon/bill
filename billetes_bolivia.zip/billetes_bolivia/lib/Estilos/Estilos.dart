// ignore_for_file: constant_identifier_names, file_names

import 'package:flutter/material.dart';

class Estilos {
  static const Color PLOMO_OSCURO = Color.fromRGBO(71, 81, 84, 1.0);
  // static const Color PLOMO_OSCURO = Colors.red;
  static const Color PLOMO = Color.fromRGBO(91, 100, 105, 1.0);

  static const Color BEIGE_OSCURO = Color.fromRGBO(179, 174, 146, 1.0);
  static const Color BEIGE = Color.fromRGBO(207, 200, 168, 1.0);

  static const Color CAFE_OSCURO = Color.fromRGBO(133, 109, 66, 1.0);
  static const Color CAFE = Color.fromRGBO(150, 123, 70, 1.0);
}
