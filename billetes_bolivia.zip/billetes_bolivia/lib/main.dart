// ignore_for_file: depend_on_referenced_packages, unnecessary_nullable_for_final_variable_declarations, unused_import

import 'package:billetes_bolivia/Estilos/Estilos.dart';
import 'package:billetes_bolivia/Services/LocalStorage.dart';
// import 'package:billetes_bolivia/plataforma/orientacionMobil.dart'
//     if (dart.library.html) 'package:billetes_bolivia/plataforma/orientacionHtml.dart';

import 'package:billetes_bolivia/provider/providerBillete.dart';
import 'package:billetes_bolivia/provider/providerCamara.dart';
import 'package:billetes_bolivia/provider/providerTheme.dart';
import 'package:billetes_bolivia/ui/view/ListaBilletes.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:google_fonts/google_fonts.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LocalStore.configuracionPreferencias();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
  runApp(MyApp());

  // SystemChrome.setPreferredOrientations([OrientacionPlataforma().orientacion()])
  //     .then((_) {
  //   runApp(MyApp(
  //     cameras: cameras,
  //   ));
  // });
}
//flutter build web --web-renderer canvaskit
//flutter run -d chrome --web-renderer canvaskit
//flutter build ios
//flutter run --release
//flutter build apk --release
//flutter build appbundle
//flutter packages pub run build_runner build --delete-conflicting-outputs

class MyApp extends StatelessWidget {
  const MyApp({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ProviderCamara()),
        ChangeNotifierProvider(create: (_) => ProviderBillete()),
        ChangeNotifierProvider(
          create: (context) => ProviderTheme(LocalStore.temaOscuro()),
        )
      ],
      child: Consumer<ProviderTheme>(
        builder: (context, providerThema, child) {
          return MaterialApp(
            locale: const Locale('es'),
            debugShowCheckedModeBanner: false,
            localizationsDelegates: AppLocalizations.localizationsDelegates,
            supportedLocales: AppLocalizations.supportedLocales,
            title: 'Billetes de Bolivia',
            home: ListaBilletes(),
            theme: providerThema.temeOscuro
                ? ThemeData.dark().copyWith(
                    listTileTheme:
                        const ListTileThemeData(textColor: Colors.white),
                    textTheme: GoogleFonts.montserratTextTheme(const TextTheme(
                        caption: TextStyle(color: Colors.white))),
                    switchTheme: SwitchThemeData(
                        overlayColor: MaterialStateProperty.all<Color>(
                            Estilos.CAFE_OSCURO),
                        thumbColor: MaterialStateProperty.all<Color>(
                            Estilos.CAFE_OSCURO),
                        trackColor:
                            MaterialStateProperty.all<Color>(Estilos.BEIGE)),
                    floatingActionButtonTheme:
                        const FloatingActionButtonThemeData(
                            backgroundColor: Estilos.CAFE_OSCURO,
                            foregroundColor: Estilos.BEIGE))
                : ThemeData.light().copyWith(
                    drawerTheme: const DrawerThemeData(
                        backgroundColor: Estilos.PLOMO_OSCURO),
                    dividerColor: Estilos.BEIGE,
                    listTileTheme: const ListTileThemeData(
                        iconColor: Estilos.BEIGE,
                        textColor: Estilos.BEIGE,
                        selectedTileColor: Estilos.PLOMO_OSCURO,
                        tileColor: Estilos.PLOMO_OSCURO),
                    iconTheme: const IconThemeData(color: Estilos.PLOMO_OSCURO),

                    textTheme: GoogleFonts.montserratTextTheme(const TextTheme(
                        caption: TextStyle(color: Estilos.BEIGE))),
                    // primaryTextTheme:te,
                    appBarTheme: const AppBarTheme(
                        color: Estilos.PLOMO_OSCURO,
                        foregroundColor: Estilos.BEIGE),
                    scaffoldBackgroundColor: Estilos.BEIGE_OSCURO,

                    // focusColor: Estilos.BEIGE,
                    // hintColor: Estilos.BEIGE,

                    // backgroundColor: Estilos.BEIGE,
                    // navigationBarTheme:const  NavigationBarThemeData(backgroundColor: Estilos.BEIGE),
                    bottomAppBarColor: Estilos.BEIGE_OSCURO,
                    cardTheme: const CardTheme(
                      color: Estilos.CAFE_OSCURO,
                    ),
                    elevatedButtonTheme: ElevatedButtonThemeData(
                        style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all<Color>(Estilos.CAFE),
                    )),
                    floatingActionButtonTheme:
                        const FloatingActionButtonThemeData(
                            // focusColor: Colors.black,
                            foregroundColor: Estilos.BEIGE,
                            backgroundColor: Estilos.PLOMO_OSCURO),
                    // scaffoldBackgroundColor: Estilos.BEIGE
                  ),
          );
        },
      ),
    );
  }
}

// class Home extends StatefulWidget {
//   const Home({Key? key}) : super(key: key);

//   @override
//   State<Home> createState() => _HomeState();
// }

// class _HomeState extends State<Home> with WidgetsBindingObserver {
//   late ProviderCamara providerCamara;
//   @override
//   void initState() {
//     providerCamara = context.read<ProviderCamara>();
//     providerCamara.iniciarCamara();
//     super.initState();
//   }

//   @override
//   void dispose() {
//     providerCamara.controller.dispose();
//     super.dispose();
//   }

//   @override
//   void didChangeAppLifecycleState(AppLifecycleState state) {
//     final CameraController? cameraController = providerCamara.controller;

//     // App state changed before we got the chance to initialize.
//     if (cameraController == null || !cameraController.value.isInitialized) {
//       return;
//     }

//     if (state == AppLifecycleState.inactive) {
//       cameraController.dispose();
//     } else if (state == AppLifecycleState.resumed) {}
//     super.didChangeAppLifecycleState(state);
//   }

//   @override
//   Widget build(BuildContext context) {
//     Size size = MediaQuery.of(context).size;
//     return Scaffold(
//       body: Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           ClipOval(
//             child: Container(
//               color: Colors.black,
//               padding: const EdgeInsets.all(8),
//               width: size.height,
//               height: size.height,
//               child: ClipOval(
//                 child: FutureBuilder<void>(
//                   future: providerCamara.inicializarFuturaCamera,
//                   builder: (context, snapshot) {
//                     if (snapshot.connectionState == ConnectionState.done) {
//                       // Si el futuro está completo, muestra la vista previa.
//                       return CameraPreview(providerCamara.controller);
//                     } else {
//                       // De lo contrario, muestra un indicador de carga.
//                       return const Center(child: CircularProgressIndicator());
//                     }
//                   },
//                 ),
//               ),
//             ),
//           ),
//           Container(
//             width: size.height / 1.5,
//             height: 30,
//             color: Colors.black,
//           )
//         ],
//       ),
//     );
//   }
// }
