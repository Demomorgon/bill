// ignore_for_file: depend_on_referenced_packages, file_names

import 'package:shared_preferences/shared_preferences.dart';

class LocalStore {
  static late SharedPreferences pref;
  static Future<void> configuracionPreferencias() async {
    pref = await SharedPreferences.getInstance();
  }

  static bool temaOscuro() => pref.getBool('tema') ?? false;

  static guardarClaro() => pref.setBool('tema', false);
  static guardarTemaOscuro() => pref.setBool('tema', true);
}
