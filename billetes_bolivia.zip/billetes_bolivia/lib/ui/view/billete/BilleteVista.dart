// ignore_for_file: depend_on_referenced_packages, file_names, must_be_immutable, unused_local_variable

import 'package:billetes_bolivia/Estilos/Estilos.dart';
import 'package:billetes_bolivia/provider/providerBillete.dart';
import 'package:billetes_bolivia/provider/providerTheme.dart';
import 'package:billetes_bolivia/ui/view/billete/widgets/AssetsImagen.dart';
import 'package:billetes_bolivia/ui/view/billete/widgets/CacheImagen.dart';
import 'package:billetes_bolivia/ui/view/dialogo/Dialogo.dart';
import 'package:billetes_bolivia/ux/objetos/Billete.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:provider/provider.dart';
import 'package:animate_do/animate_do.dart';

class BilleteVista extends StatelessWidget {
  final Billete billete;
  BilleteVista({Key? key, required this.billete}) : super(key: key);
  late ProviderBillete providerBillete;
  late ProviderTheme providerTheme;
  late AnimationController animationController;
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    var tam = obtenerTamanio(size);
    var len = AppLocalizations.of(context)!;
    providerTheme = context.read<ProviderTheme>();
    providerBillete = context.watch<ProviderBillete>();
    return Scaffold(
      // appBar: AppBar(
      //   iconTheme: providerTheme.temeOscuro
      //       ? null
      //       : const IconThemeData(color: Estilos.PLOMO_OSCURO),
      //   elevation: 0,
      //   backgroundColor: Colors.red,
      // ),
      extendBodyBehindAppBar: true,
      // extendBody: true,
      body: SafeArea(
        left: false,
        right: false,
        bottom: false,
        child: Stack(
          children: [
            Center(
              child: SizedBox(
                height: tam * 0.5,
                width: tam,
                child: Stack(children: [
                  // AnimatedCrossFade(
                  //     firstChild: gestosImagen(tam),
                  //     secondChild: gestosImagen(tam),
                  //     // firstCurve: Curves.bounceInOut,
                  //     // secondCurve: Curves.bounceInOut,
                  //     crossFadeState: providerBillete.swAnverso
                  //         ? CrossFadeState.showFirst
                  //         : CrossFadeState.showSecond,
                  //     duration: providerBillete.duracionAnimacion),
                  AnimatedSwitcher(
                    // key: ValueKey<bool>(providerBillete.swAnverso),
                    duration: providerBillete.duracionAnimacion,
                    transitionBuilder:
                        (Widget child, Animation<double> animation) {
                      return SlideTransition(
                        position: Tween<Offset>(
                                begin: const Offset(0.0, -1.5),
                                end: const Offset(0.0, 0.0))
                            .animate(animation),
                        child: child,
                      );
                    },
                    child: providerBillete.swAnverso
                        ? gestosImagen(
                            tam, ValueKey<bool>(providerBillete.swAnverso))
                        : gestosImagen(
                            tam, ValueKey<bool>(providerBillete.swAnverso)),
                  ),
                  ...billete.obtenerIndexWidget(providerBillete.index,
                      providerBillete.swAnverso, tam, context),
                ]),
              ),
            ),
            const Positioned(top: 8, left: 8, child: BackButton()),
            // Positioned(
            //     top: 8,
            //     left: 8,
            //     child: IconButton(
            //         onPressed: () {
            //           Navigator.pop(context);
            //         },
            //         icon: const Icon(Icons.home))),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
            color: Estilos.BEIGE.withOpacity(0.3),
            borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(5), topRight: Radius.circular(5))),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              FadeInLeft(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    iconButton(
                        icon: Icons.remove_red_eye, color: Colors.orange, i: 0),
                    iconButton(
                        icon: Icons.touch_app, color: Colors.green, i: 1),
                    iconButton(
                        icon: Icons.style_outlined,
                        color: Colors.redAccent,
                        i: 2),
                    iconButton(
                        icon: Icons.lightbulb_outlined,
                        color: Colors.purple,
                        i: 3),
                    iconButton(
                        icon: Icons.color_lens_outlined,
                        color: Colors.blue,
                        i: 4),
                  ],
                ),
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Bounce(
                    // infinite: true,
                    animate: true,
                    child: IconButton(
                        onPressed: () => providerBillete.cambiarPosicion(),
                        icon: const Icon(Icons.swap_vert_sharp)),
                  ),
                  Pulse(
                    animate: true,
                    // infinite: true,
                    child: IconButton(
                        onPressed: () {
                          providerBillete.restablecerZoom();
                          providerBillete.swUVista = providerBillete.swUV;
                          providerBillete.swAnversoDialogo =
                              providerBillete.swAnverso;
                          Dialogo().showImagen(
                              providerBillete.swUV
                                  ? providerBillete.swAnverso
                                      ? billete.imagenAnversoUV
                                      : billete.imagenReversoUV
                                  : providerBillete.swAnverso
                                      ? billete.imagenAnverso
                                      : billete.imagenReverso,
                              tam,
                              billete,
                              context);
                        },
                        icon: const Icon(Icons.zoom_out_map)),
                  ),
                  SpinPerfect(
                    controller: (p0) => animationController = p0,
                    manualTrigger: true,
                    animate: true,
                    // infinite: true,
                    child: IconButton(
                      onPressed: () {
                        // print(animationController);
                        animationController.reset();
                        providerBillete.irMenuBillete();
                      },
                      icon: Stack(
                        children: const [
                          Icon(Icons.more_horiz),
                          Icon(Icons.more_vert),
                        ],
                      ),
                      // icon: const Icon(Icons.developer_board)
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget iconButton(
      {required IconData icon, required Color color, required int i}) {
    return ClipOval(
      child: Container(
          color: providerBillete.index == i ? color : null,
          child: IconButton(
              onPressed: () => providerBillete.cambiarIndex(i),
              icon: Icon(
                icon,
                color: providerBillete.index == i ? Colors.white : null,
              ))),
    );
  }

  double obtenerTamanio(Size size) {
    if ((size.width / 2) > size.height) {
      return (size.height * 0.7) * 2;
    } else {
      return size.width * 0.9;
    }
  }

  Widget gestosImagen(double tam, Key key) {
    return GestureDetector(
      key: key,
      onHorizontalDragEnd: (details) {
        if (details.velocity.pixelsPerSecond.dx > 0) {
          providerBillete.irDerecha();
        } else if (details.velocity.pixelsPerSecond.dx < 0) {
          providerBillete.irIzquierda();
        }
      },
      onVerticalDragEnd: (details) {
        providerBillete.cambiarPosicion();
      },
      child: providerBillete.swAnverso
          ? (providerBillete.swUV
              ? (billete.assetsAnversoUV
                  ? AssetsImagen(tam: tam, path: billete.imagenAnversoUV)
                  : CacheImagen(tam: tam, url: billete.imagenAnversoUV))
              : (billete.assetsAnverso
                  ? AssetsImagen(tam: tam, path: billete.imagenAnverso)
                  : CacheImagen(tam: tam, url: billete.imagenAnverso)))
          : (providerBillete.swUV
              ? (billete.assetsReversoUV
                  ? AssetsImagen(tam: tam, path: billete.imagenReversoUV)
                  : CacheImagen(tam: tam, url: billete.imagenReversoUV))
              : (billete.assetsReverso
                  ? AssetsImagen(tam: tam, path: billete.imagenReverso)
                  : CacheImagen(tam: tam, url: billete.imagenReverso))),
    );
  }
}
