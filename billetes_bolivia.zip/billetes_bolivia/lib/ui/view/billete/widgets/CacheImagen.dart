// ignore_for_file: file_names

import 'package:billetes_bolivia/ui/view/widgets/ErrorRecarga.dart';
import 'package:billetes_bolivia/ui/view/widgets/Recargando.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class CacheImagen extends StatelessWidget {
  final double tam;
  final String url;
  const CacheImagen({Key? key, required this.tam, required this.url})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      width: tam,
      height: tam * 0.5,
      placeholder: (context, url) => const Recargando(),
      errorWidget: (context, url, error) => const ErrorRecarga(),
      imageUrl: url,
      fit: BoxFit.fill,
    );
  }
}
