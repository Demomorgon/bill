// ignore_for_file: file_names

import 'package:flutter/material.dart';

class AssetsImagen extends StatelessWidget {
  final double tam;
  final String path;
  const AssetsImagen({Key? key, required this.tam, required this.path})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Image.asset('assets/imagenes/${path.toLowerCase()}.jpg',
        width: tam, height: tam * 0.5, fit: BoxFit.fill);
  }
}
