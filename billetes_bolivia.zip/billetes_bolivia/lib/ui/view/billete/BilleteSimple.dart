// ignore_for_file: file_names, depend_on_referenced_packages, must_be_immutable

import 'package:billetes_bolivia/provider/providerBillete.dart';
import 'package:billetes_bolivia/ui/view/billete/BilleteVista.dart';
import 'package:billetes_bolivia/ui/view/billete/widgets/AssetsImagen.dart';
import 'package:billetes_bolivia/ui/view/billete/widgets/CacheImagen.dart';
import 'package:billetes_bolivia/ux/objetos/Billete.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class BilleteSimple extends StatelessWidget {
  final Billete billete;
  BilleteSimple({Key? key, required this.billete}) : super(key: key);
  late ProviderBillete providerBillete;

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    var tam = obtenerTamanio(size);
    providerBillete = context.read<ProviderBillete>();
    return Scaffold(
      body: Center(
        child: InkWell(
          onTap: () {
            providerBillete.reiniciar();
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => BilleteVista(billete: billete)));
          },
          child: SizedBox(
            height: tam * 0.5,
            width: tam,
            child: billete.assetsAnverso
                ? AssetsImagen(tam: tam, path: billete.imagenAnverso)
                : CacheImagen(tam: tam, url: billete.imagenAnverso),
          ),
        ),
      ),
    );
  }

  double obtenerTamanio(Size size) {
    if ((size.width / 2) > size.height) {
      return (size.height * 0.7) * 2;
    } else {
      return size.width * 0.7;
    }
  }
}
