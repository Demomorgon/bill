// ignore_for_file: unused_local_variable

import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class Informacion extends StatelessWidget {
  const Informacion({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var len = AppLocalizations.of(context)!;
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(),
              Text(len.bancoCentralBolivia),
              Text(len.app_name),
              SizedBox(
                  height: size.height * 0.6,
                  child: Image.asset('assets/imagenes/bcb.png')),
              Text(len.subtituloinfo),
              Text('${len.version}: 1.06.0000'),
            ],
          ),
          const Positioned(top: 8, left: 8, child: BackButton()),
        ],
      ),
    );
  }
}
