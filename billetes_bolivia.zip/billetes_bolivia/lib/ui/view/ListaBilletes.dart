// ignore_for_file: depend_on_referenced_packages, file_names, use_build_context_synchronously, must_be_immutable

import 'package:billetes_bolivia/ui/view/billete/BilleteSimple.dart';
import 'package:billetes_bolivia/ui/view/billete/BilleteVista.dart';
import 'package:billetes_bolivia/ui/view/widgets/AppBar.dart';
import 'package:billetes_bolivia/ui/view/widgets/DrawerBilletes.dart';
import 'package:billetes_bolivia/ui/view/widgets/Recargando.dart';
import 'package:billetes_bolivia/ux/objetos/Billete.dart';
// import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:billetes_bolivia/provider/providerBillete.dart';
import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';

class ListaBilletes extends StatelessWidget {
  ListaBilletes({Key? key}) : super(key: key);
  late ProviderBillete providerBillete;

  @override
  Widget build(BuildContext context) {
    providerBillete = context.watch<ProviderBillete>();
    return FutureBuilder<bool>(
        future: leerJson(context),
        builder: (_, value) {
          if (!value.hasData) {
            return const Recargando();
          }
          return listAnimadaTab(providerBillete, context);
        });
  }

  Future<bool> leerJson(BuildContext context) async {
    if (providerBillete.mapBillete.isEmpty) {
      String na200 = await DefaultAssetBundle.of(context)
          .loadString("assets/json/na200.json");
      String na100 = await DefaultAssetBundle.of(context)
          .loadString("assets/json/na100.json");
      String na50 = await DefaultAssetBundle.of(context)
          .loadString("assets/json/na50.json");
      String na20 = await DefaultAssetBundle.of(context)
          .loadString("assets/json/na20.json");
      String na10 = await DefaultAssetBundle.of(context)
          .loadString("assets/json/na10.json");
      String a200 = await DefaultAssetBundle.of(context)
          .loadString("assets/json/a200.json");
      String a100 = await DefaultAssetBundle.of(context)
          .loadString("assets/json/a100.json");
      String a50 = await DefaultAssetBundle.of(context)
          .loadString("assets/json/a50.json");
      String a20 = await DefaultAssetBundle.of(context)
          .loadString("assets/json/a20.json");
      String a10 = await DefaultAssetBundle.of(context)
          .loadString("assets/json/a10.json");

      providerBillete.mapBillete.putIfAbsent(0, () => Billete.fromJson(na200));
      providerBillete.mapBillete.putIfAbsent(1, () => Billete.fromJson(na100));
      providerBillete.mapBillete.putIfAbsent(2, () => Billete.fromJson(na50));
      providerBillete.mapBillete.putIfAbsent(3, () => Billete.fromJson(na20));
      providerBillete.mapBillete.putIfAbsent(4, () => Billete.fromJson(na10));

      providerBillete.mapBillete.putIfAbsent(5, () => Billete.fromJson(a200));
      providerBillete.mapBillete.putIfAbsent(6, () => Billete.fromJson(a100));
      providerBillete.mapBillete.putIfAbsent(7, () => Billete.fromJson(a50));
      providerBillete.mapBillete.putIfAbsent(8, () => Billete.fromJson(a20));
      providerBillete.mapBillete.putIfAbsent(9, () => Billete.fromJson(a10));
    }
    return false;
  }

  // Widget listTab(ProviderBillete providerBillete) {
  //   return DefaultTabController(
  //     length: 10,
  //     initialIndex: 0,
  //     child: Scaffold(
  //         body: TabBarView(
  //       children: [
  //         BilleteSimple(
  //           billete: providerBillete.billetena200,
  //         ),
  //         BilleteSimple(
  //           billete: providerBillete.billetena100,
  //         ),
  //         BilleteSimple(
  //           billete: providerBillete.billetena50,
  //         ),
  //         BilleteSimple(
  //           billete: providerBillete.billetena20,
  //         ),
  //         BilleteSimple(
  //           billete: providerBillete.billetena10,
  //         ),
  //         BilleteSimple(
  //           billete: providerBillete.billete200,
  //         ),
  //         BilleteSimple(
  //           billete: providerBillete.billete100,
  //         ),
  //         BilleteSimple(
  //           billete: providerBillete.billete50,
  //         ),
  //         BilleteSimple(
  //           billete: providerBillete.billete20,
  //         ),
  //         BilleteSimple(
  //           billete: providerBillete.billete10,
  //         ),
  //       ],
  //     )),
  //   );
  // }

  Widget listAnimadaTab(ProviderBillete providerBillete, BuildContext context) {
    return SafeArea(
      left: false,
      right: false,
      bottom: false,
      child: Scaffold(
        drawer: DrawerBilletes(),
        appBar: AppBar(
          title: AppBarBillere(),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            providerBillete.reiniciar();
            // SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => BilleteVista(
                        billete: providerBillete.obtenerIndexBillete(
                            providerBillete.indexBillete))));
          },
          child: const Icon(Icons.zoom_out_map),
        ),
        body: InkWell(
          onTap: () {
            providerBillete.reiniciar();
            // SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => BilleteVista(
                        billete: providerBillete.obtenerIndexBillete(
                            providerBillete.indexBillete))));
          },
          child: RotatedBox(
            quarterTurns: 3,
            child: ListWheelScrollView(
              onSelectedItemChanged: (index) {
                providerBillete.cambiarIndexBillete(index);
              },
              diameterRatio: 6,
              physics: const FixedExtentScrollPhysics(),
              itemExtent: MediaQuery.of(context).size.width * 0.7,
              children: providerBillete.mapBillete.entries
                  .map((e) => RotatedBox(
                        quarterTurns: 1,
                        child: BilleteSimple(billete: e.value),
                      ))
                  .toList(),
            ),
          ),
        ),
      ),
    );
  }
}
