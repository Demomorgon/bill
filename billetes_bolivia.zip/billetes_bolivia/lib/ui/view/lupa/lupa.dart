// ignore_for_file: depend_on_referenced_packages, unnecessary_nullable_for_final_variable_declarations

// import 'package:billetes_bolivia/Estilos/Estilos.dart';
import 'package:billetes_bolivia/provider/providerCamara.dart';
import 'package:billetes_bolivia/provider/providerTheme.dart';
import 'package:billetes_bolivia/ui/view/ListaBilletes.dart';
import 'package:billetes_bolivia/ui/view/lupa/widgets/zoom.dart';
import 'package:billetes_bolivia/ui/view/widgets/Recargando.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:camera/camera.dart';

class Lupa extends StatefulWidget {
  const Lupa({Key? key}) : super(key: key);

  @override
  State<Lupa> createState() => _LupaState();
}

class _LupaState extends State<Lupa> with WidgetsBindingObserver {
  late ProviderCamara providerCamara;
  late ProviderTheme providerTheme;
  bool flash = false;
  @override
  void initState() {
    providerCamara = context.read<ProviderCamara>();
    providerTheme = context.read<ProviderTheme>();
    providerCamara.iniciarCamara();
    WidgetsBinding.instance.addObserver(this);
    super.initState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    providerCamara.controller.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive) {
      providerCamara.controller.dispose();
    } else if (state == AppLifecycleState.resumed) {
      // Navigator.pushAndRemoveUntil(context,
      //     MaterialPageRoute(builder: (_) => ListaBilletes()), (route) => false);
    } else if (state == AppLifecycleState.paused) {
      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (_) => ListaBilletes()), (route) => false);
    }
    super.didChangeAppLifecycleState(state);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
          elevation: 0.0,
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white),
      extendBodyBehindAppBar: true,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          flash = !flash;
          providerCamara.controller
              .setFlashMode(flash ? FlashMode.torch : FlashMode.off);
          // setState(() {});
        },
        child: const Icon(Icons.flash_on_outlined),
      ),
      body: FutureBuilder<bool>(
        future: providerCamara.obtenercamara(),
        builder: (context, snapshot) {
          // if (!snapshot.hasData) return Recargando();
          try {
            if (snapshot.connectionState == ConnectionState.done) {
              return SizedBox(
                  width: size.width,
                  height: size.height,
                  child: Stack(
                    children: [
                      snapshot.data!
                          ? RotatedBox(
                              quarterTurns: 3,
                              child: SizedBox(
                                  width: size.height,
                                  height: size.width,
                                  child:
                                      CameraPreview(providerCamara.controller)),
                            )
                          : SizedBox(
                              width: size.width,
                              height: size.height,
                              child: CameraPreview(providerCamara.controller)),
                      const Positioned(bottom: 8, left: 8, child: ZoomCamara())
                    ],
                  ));
            } else {
              return const Center(child: Recargando());
            }
          } catch (e) {
            return const Recargando();
          }
        },
      ),
    );
  }

  Future<bool> obtenerCamara() async {
    await Future.delayed(const Duration(seconds: 3));
    return true;
  }
}
