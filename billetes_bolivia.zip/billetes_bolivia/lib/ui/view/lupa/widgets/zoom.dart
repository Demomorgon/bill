// ignore_for_file: depend_on_referenced_packages

import 'package:billetes_bolivia/Estilos/Estilos.dart';
import 'package:billetes_bolivia/provider/providerCamara.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ZoomCamara extends StatefulWidget {
  const ZoomCamara({Key? key}) : super(key: key);

  @override
  State<ZoomCamara> createState() => _ZoomCamaraState();
}

class _ZoomCamaraState extends State<ZoomCamara> {
  late ProviderCamara providerCamara;
  @override
  void initState() {
    providerCamara = context.read<ProviderCamara>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Slider(
        value: providerCamara.zoomAux,
        min: providerCamara.zoomMin,
        max: providerCamara.zoom,
        divisions: 6,
        activeColor: Estilos.CAFE_OSCURO,
        inactiveColor: Estilos.BEIGE_OSCURO,
        thumbColor: Estilos.PLOMO_OSCURO,
        onChanged: (value) {
          providerCamara.cambiarZoom(value);
          setState(() {});
        });
  }
}
