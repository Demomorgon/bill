// ignore_for_file: must_be_immutable, file_names, depend_on_referenced_packages

import 'package:billetes_bolivia/ui/view/dialogo/traduccion/obtenerTraduccion.dart';
import 'package:billetes_bolivia/ux/objetos/MedidasDeSeguridad.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:animate_do/animate_do.dart';

class VerContenido extends StatelessWidget {
  final MedidasDeSeguridad medidasDeSeguridad;
  VerContenido({Key? key, required this.medidasDeSeguridad}) : super(key: key);
  ObtenerTraduccion ot = ObtenerTraduccion();

  @override
  Widget build(BuildContext context) {
    var len = AppLocalizations.of(context)!;
    var size = MediaQuery.of(context).size;
    var tam = size.width > size.height ? size.height : size.width;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        // const CloseButton(),
        Column(
          children: [
            // Text(ot.obtenerTraduccion('${medidasDeSeguridad.idString}T', len)),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Dance(
                  animate: medidasDeSeguridad.gif,
                  child: Container(
                      padding: const EdgeInsets.all(8.0),
                      width: tam * 0.75,
                      height: tam * 0.75,
                      child: tipoImagen()),
                ),
                Expanded(
                  child: Container(
                      padding: const EdgeInsets.all(8.0),
                      // width: size.width * 0.30,
                      child: Text(
                          textAlign: TextAlign.justify,
                          ot.obtenerTraduccion(
                              medidasDeSeguridad.idString, len))),
                )
              ],
            )
          ],
        )
      ],
    );
  }

  Widget tipoImagen() {
    if (medidasDeSeguridad.assets) {
      return Image.asset(
        alignment: Alignment.topCenter,
        'assets/imagenes/${medidasDeSeguridad.imagen.toLowerCase()}.png',
        fit: BoxFit.contain,
      );
    } else {
      return CachedNetworkImage(
        placeholder: (context, url) => const CircularProgressIndicator(),
        errorWidget: (context, url, error) => const Icon(Icons.error),
        alignment: Alignment.topCenter,
        imageUrl: medidasDeSeguridad.imagenUrl,
        fit: BoxFit.contain,
      );
    }
  }
}
