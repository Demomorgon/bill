// ignore_for_file: prefer_const_constructors_in_immutables, depend_on_referenced_packages, file_names, must_be_immutable, unused_local_variable

import 'package:billetes_bolivia/provider/providerBillete.dart';
import 'package:billetes_bolivia/ui/view/billete/widgets/AssetsImagen.dart';
import 'package:billetes_bolivia/ui/view/billete/widgets/CacheImagen.dart';
import 'package:billetes_bolivia/ux/objetos/Billete.dart';
// import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:provider/provider.dart';

class VerImagen extends StatelessWidget {
  final String imagen;
  double tam;
  final Billete billete;
  VerImagen(
      {Key? key,
      required this.imagen,
      required this.tam,
      required this.billete})
      : super(key: key);
  late ProviderBillete providerBillete;

  @override
  Widget build(BuildContext context) {
    var len = AppLocalizations.of(context)!;
    var size = MediaQuery.of(context).size;

    providerBillete = context.watch<ProviderBillete>();

    return SizedBox(
      width: tam,
      height: tam * 0.5,
      child: InkWell(
        onDoubleTap: () => providerBillete.restablecerZoom(),
        child: InteractiveViewer(
            transformationController: providerBillete.transformationController,
            panEnabled: true,
            alignPanAxis: true,
            onInteractionEnd: (value) {
              // providerBillete.anularVista();
            },

            // onInteractionUpdate: (value) {
            //   providerBillete.anularVista();
            // },
            minScale: 1,
            maxScale: 15,
            child: providerBillete.swAnversoDialogo
                ? (providerBillete.swUVista
                    ? (billete.assetsAnversoUV
                        ? AssetsImagen(tam: tam, path: billete.imagenAnversoUV)
                        : CacheImagen(tam: tam, url: billete.imagenAnversoUV))
                    : (billete.assetsAnverso
                        ? AssetsImagen(tam: tam, path: billete.imagenAnverso)
                        : CacheImagen(tam: tam, url: billete.imagenAnverso)))
                : (providerBillete.swUVista
                    ? (billete.assetsReversoUV
                        ? AssetsImagen(tam: tam, path: billete.imagenReversoUV)
                        : CacheImagen(tam: tam, url: billete.imagenReversoUV))
                    : (billete.assetsReverso
                        ? AssetsImagen(tam: tam, path: billete.imagenReverso)
                        : CacheImagen(tam: tam, url: billete.imagenReverso)))
            // CachedNetworkImage(
            //   placeholder: (context, url) => const CircularProgressIndicator(),
            //   errorWidget: (context, url, error) => const Icon(Icons.error),
            //   imageUrl: providerBillete.swAnverso
            //       ? providerBillete.swUVista
            //           ? billete.imagenAnversoUV
            //           : billete.imagenAnverso
            //       : providerBillete.swUVista
            //           ? billete.imagenReversoUV
            //           : billete.imagenReverso,
            //   fit: BoxFit.fill,
            // ),
            ),
      ),
    );
  }
}
