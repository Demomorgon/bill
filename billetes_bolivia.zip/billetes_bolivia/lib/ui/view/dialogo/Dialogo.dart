// ignore_for_file: file_names, depend_on_referenced_packages

// import 'package:billetes_bolivia/icons/icon_redes_icons.dart';
// import 'package:billetes_bolivia/provider/providerBillete.dart';
import 'package:billetes_bolivia/ui/view/dialogo/traduccion/obtenerTraduccion.dart';
import 'package:billetes_bolivia/ui/view/dialogo/widget/verContenido.dart';
import 'package:billetes_bolivia/ui/view/dialogo/widget/verImagen.dart';
import 'package:billetes_bolivia/ux/objetos/Billete.dart';
import 'package:billetes_bolivia/ux/objetos/MedidasDeSeguridad.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
// import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';

class Dialogo {
  final ObtenerTraduccion ot = ObtenerTraduccion();
  void showDialogo(
      MedidasDeSeguridad medidasDeSeguridad, BuildContext context) {
    var len = AppLocalizations.of(context)!;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.black54,
          // titleTextStyle: const TextStyle(color: Colors.white),
          // contentTextStyle: const TextStyle(color: Colors.white),
          titleTextStyle: GoogleFonts.montserrat(
              color: Colors.white, fontWeight: FontWeight.bold),
          contentTextStyle: GoogleFonts.montserrat(color: Colors.white),
          contentPadding: const EdgeInsets.all(0),
          scrollable: true,
          elevation: 0,
          title: Row(
            children: [
              Expanded(
                child: Center(
                  child: Text(ot.obtenerTraduccion(
                      '${medidasDeSeguridad.idString}T', len)),
                ),
              ),
              const CloseButton(
                color: Colors.white,
              )
            ],
          ),
          content: VerContenido(medidasDeSeguridad: medidasDeSeguridad),
          // actions: [
          //   ElevatedButton(
          //       onPressed: () {
          //         Navigator.pop(context);
          //       },
          //       child: const Text('Aceptar'))
          // ],
        );
      },
    );
  }

  void showImagen(
      String imagen, double tam, Billete billete, BuildContext context) {
    // ProviderBillete providerBillete = context.read<ProviderBillete>();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.black54,
          titleTextStyle: GoogleFonts.montserrat(color: Colors.white),
          contentTextStyle: const TextStyle(color: Colors.white),
          contentPadding: const EdgeInsets.all(0),
          elevation: 0,
          // scrollable: true,
          // title: Row(
          //   mainAxisAlignment: MainAxisAlignment.end,
          //   children: const [
          //     CloseButton(
          //       color: Colors.white,
          //     )
          //   ],
          // ),
          content: VerImagen(
            imagen: imagen,
            tam: tam * 0.9,
            billete: billete,
          ),
          // actions: [
          //   Row(
          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //     children: [
          //       const CloseButton(
          //         color: Colors.white,
          //       ),
          //       Row(
          //         mainAxisAlignment: MainAxisAlignment.end,
          //         children: [
          //           IconButton(
          //               onPressed: () => providerBillete.activarUV(),
          //               icon: const Icon(
          //                 Icons.lightbulb_outline_sharp,
          //                 color: Colors.white,
          //               )),
          //           IconButton(
          //               onPressed: () =>
          //                   providerBillete.cambiarPosicionDialogo(),
          //               icon: const Icon(
          //                 IconRedes.arrows_cw,
          //                 color: Colors.white,
          //               ))
          //         ],
          //       )
          //     ],
          //   )
          // ],
        );
      },
    );
  }
}
