// ignore_for_file: file_names

import 'package:billetes_bolivia/Estilos/Estilos.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class Recargando extends StatelessWidget {
  const Recargando({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var len = AppLocalizations.of(context)!;
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(),
          const CircularProgressIndicator(
            color: Estilos.CAFE_OSCURO,
          ),
          Text(len.cargando)
        ],
      ),
    );
  }
}
