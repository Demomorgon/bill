// ignore_for_file: depend_on_referenced_packages, must_be_immutable, file_names, prefer_spread_collections, empty_catches, deprecated_member_use, unused_catch_clause

import 'package:billetes_bolivia/Estilos/Estilos.dart';
import 'package:billetes_bolivia/icons/icon_redes_icons.dart';
import 'package:billetes_bolivia/provider/providerBillete.dart';
import 'package:billetes_bolivia/provider/providerCamara.dart';
import 'package:billetes_bolivia/provider/providerTheme.dart';
import 'package:billetes_bolivia/ui/view/billete/BilleteVista.dart';
import 'package:billetes_bolivia/ui/view/informacion/informacion.dart';
import 'package:billetes_bolivia/ui/view/lupa/lupa.dart';
import 'package:billetes_bolivia/ux/objetos/Billete.dart';
import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:camera/camera.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'package:billetes_bolivia/plataforma/orientacionMobil.dart'
//     if (dart.library.html) 'package:billetes_bolivia/plataforma/orientacionHtml.dart';

class DrawerBilletes extends StatelessWidget {
  DrawerBilletes({Key? key}) : super(key: key);
  late ProviderBillete providerBillete;
  late ProviderCamara providerCamara;
  late ProviderTheme providerTheme;
  @override
  Widget build(BuildContext context) {
    var len = AppLocalizations.of(context)!;
    providerBillete = context.read<ProviderBillete>();
    providerTheme = context.read<ProviderTheme>();
    providerCamara = context.read<ProviderCamara>();

    return Drawer(
      // width: size.width / 4,
      child: ListView(
        children: [
          SizedBox(
            width: double.maxFinite,
            child: DrawerHeader(
              decoration: const BoxDecoration(
                  color: Estilos.PLOMO_OSCURO,
                  image: DecorationImage(
                      fit: BoxFit.contain,
                      image: AssetImage('assets/imagenes/bcb.png'))),
              child: Align(
                alignment: Alignment.bottomRight,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      providerTheme.temeOscuro
                          ? Icons.nightlight_round
                          : Icons.light_mode_outlined,
                      color: Colors.white,
                    ),
                    Switch(
                        value: providerTheme.temeOscuro,
                        onChanged: (sw) => providerTheme.cambiarTema(sw))
                  ],
                ),
              ),
            ),
          )
        ]..addAll(obternerListaBilletes(context, len)),
      ),
    );
  }

  List<Widget> obternerListaBilletes(
      BuildContext context, AppLocalizations len) {
    List<Widget> list = [];
    list.add(ListTile(
      leading: const Icon(IconRedes.money_bill_wave),
      title: Text(len.billetes),
      onTap: () => providerBillete.activarMenuBillete(),
    ));
    if (providerBillete.menuBilletes) {
      list.add(ListTile(
        leading: const Icon(Icons.list),
        title: Text(len.menuTitulo11),
        onTap: () => providerBillete.activarNaBillete(),
      ));
    }
    if (providerBillete.menuNa && providerBillete.menuBilletes) {
      list.addAll(providerBillete.mapBillete.entries
          .where((element) => element.value.isNuevoBillete())
          .map((e) => ListTile(
                leading: const Icon(Icons.subdirectory_arrow_right_outlined),
                title: Text(obtenerSubtitulo(e.value, len)),
                onTap: () {
                  providerBillete.reiniciar();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => BilleteVista(billete: e.value)));
                },
              )));
    }
    if (providerBillete.menuBilletes) {
      list.add(ListTile(
        leading: const Icon(Icons.view_list_outlined),
        title: Text(len.menuTitulo12),
        onTap: () => providerBillete.activarABillete(),
      ));
    }
    if (providerBillete.menuA && providerBillete.menuBilletes) {
      list.addAll(providerBillete.mapBillete.entries
          .where((element) => !element.value.isNuevoBillete())
          .map((e) => ListTile(
                leading: const Icon(Icons.subdirectory_arrow_right_outlined),
                title: Text(obtenerSubtitulo(e.value, len)),
                onTap: () {
                  providerBillete.reiniciar();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => BilleteVista(billete: e.value)));
                },
              )));
    }
    list.addAll([
      const Divider(),
      ListTile(
        leading: const Icon(Icons.search),
        title: Text(len.lupa),
        onTap: () async {
          // SystemChrome.setPreferredOrientations(
          //     [OrientacionPlataforma().orientacion()]).then((_) {
          try {
            var status = await Permission.camera.status;
            if (status.isGranted) {
              // Permission is granted

              final cameras = await availableCameras();
              providerCamara.cameras = cameras;
              providerCamara.controller = CameraController(
                  providerCamara.cameras.first, ResolutionPreset.max,
                  enableAudio: false);
              await providerCamara.controller.initialize();
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const Lupa()));
            } else if (status.isDenied) {
              // Scaffold.of(context).showSnackBar(
              //     const SnackBar(content: Text('Sin permiso de cámara')));
              if (await Permission.camera.request().isGranted) {
                // Either the permission was already granted before or the user just granted it.
                final cameras = await availableCameras();
                providerCamara.cameras = cameras;
                providerCamara.controller = CameraController(
                    providerCamara.cameras.first, ResolutionPreset.max,
                    enableAudio: false);
                await providerCamara.controller.initialize();
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => const Lupa()));
              } else {
                Navigator.pop(context);
                Scaffold.of(context).showSnackBar(const SnackBar(
                  content: Text('Sin permiso de cámara'),
                  duration: Duration(seconds: 3),
                ));
              }
            } else {
              Navigator.pop(context);
              Scaffold.of(context).showSnackBar(const SnackBar(
                content: Text('Sin permiso de cámara'),
                duration: Duration(seconds: 3),
              ));
            }
          } on Exception catch (e) {}
          // });
        },
      ),
      const Divider()
    ]);
    // list.add(li)
    list.add(ListTile(
      // leading: const Icon(Icons.soci),
      title: Text(len.redesociales),
      // onTap: () async => providerBillete.swRedesSociales(),
    ));
    // if (providerBillete.menuRedesSociales) {
    list.addAll([
      listTitle(IconRedes.facebook_official, len.facebook,
          'https://www.facebook.com/BancoCentralBO/'),
      listTitle(IconRedes.instagram, len.instagram,
          'https://www.instagram.com/bancocentralbo/'),
      listTitle(IconRedes.youtube_play, len.youTube,
          'https://www.youtube.com/c/BancoCentralBO'),
      listTitle(
          IconRedes.twitter, len.twitter, 'https://twitter.com/BancoCentralBO'),
      listTitle(
          Icons.tiktok, len.tikTok, 'https://www.tiktok.com/@bancocentralbo'),
      listTitle(IconRedes.linkedin_squared, len.linkedIn,
          'https://www.linkedin.com/company/bancocentralbo'),
    ]);
    // }
    list.add(listTitle(Icons.language, len.web, 'https://www.bcb.gob.bo/'));
    list.add(ListTile(
      leading: const Icon(Icons.info),
      title: Text(len.informacion),
      onTap: () => Navigator.push(
          context, MaterialPageRoute(builder: (_) => const Informacion())),
    ));

    return list;
  }

  String obtenerSubtitulo(Billete billete, AppLocalizations len) {
    switch (billete.cabecera) {
      case 'na200':
        return len.menuTitulo115;
      case 'na100':
        return len.menuTitulo114;
      case 'na50':
        return len.menuTitulo113;
      case 'na20':
        return len.menuTitulo112;
      case 'na10':
        return len.menuTitulo111;
      case 'a200':
        return len.menuTitulo121;
      case 'a100':
        return len.menuTitulo122;
      case 'a50':
        return len.menuTitulo123;
      case 'a20':
        return len.menuTitulo124;
      case 'a10':
        return len.menuTitulo125;
      default:
        return '';
    }
  }

  Future<void> openUrl(String url) async {
    try {
      // launchUrl(mode: LaunchMode.externalApplication, Uri.parse('url'));
      if (await canLaunch(url)) {
        await launch(url, forceSafariVC: false);
      } else {
        await launch(url, forceSafariVC: true);
      }
    } catch (e) {}
  }

  Widget listTitle(IconData icon, String title, String url) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      onTap: () async => await openUrl(url),
    );
  }
}
