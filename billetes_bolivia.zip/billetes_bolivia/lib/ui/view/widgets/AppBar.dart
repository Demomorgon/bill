// ignore_for_file: prefer_const_constructors_in_immutables, depend_on_referenced_packages, must_be_immutable, file_names

import 'package:billetes_bolivia/provider/providerBillete.dart';
import 'package:billetes_bolivia/ux/objetos/Billete.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AppBarBillere extends StatelessWidget {
  AppBarBillere({Key? key}) : super(key: key);
  late ProviderBillete providerBillete;

  @override
  Widget build(BuildContext context) {
    var len = AppLocalizations.of(context)!;
    providerBillete = context.watch<ProviderBillete>();
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(providerBillete
                .obtenerIndexBillete(providerBillete.indexBillete)
                .isNuevoBillete()
            ? len.subtitulosplash
            : len.tituloa1),
        Text(obtenerSubtitulo(
            providerBillete.obtenerIndexBillete(providerBillete.indexBillete),
            len)),
        Row()
      ],
    );
  }

  String obtenerSubtitulo(Billete billete, AppLocalizations len) {
    switch (billete.cabecera) {
      case 'na200':
        return len.titulon200;
      case 'na100':
        return len.titulon100;
      case 'na50':
        return len.titulon50;
      case 'na20':
        return len.titulon20;
      case 'na10':
        return len.titulon10;
      case 'a200':
        return len.tituloa200;
      case 'a100':
        return len.tituloa100;
      case 'a50':
        return len.tituloa50;
      case 'a20':
        return len.tituloa20;
      case 'a10':
        return len.tituloa10;
      default:
        return '';
    }
  }
}
