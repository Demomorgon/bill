// ignore_for_file: unused_local_variable, file_names

import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class ErrorRecarga extends StatelessWidget {
  const ErrorRecarga({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var len = AppLocalizations.of(context)!;
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(),
          const Icon(Icons.perm_scan_wifi_outlined),
        ],
      ),
    );
  }
}
