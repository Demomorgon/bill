// ignore_for_file: file_names

import 'dart:convert';

class MedidasDeSeguridad {
  String caracteristica;
  String detalle;
  String posicion;
  String idString;
  int verticalBias;
  int horizontalBias;
  bool habilitado;
  String imagen;
  bool gif;
  String imagenUrl;
  bool assets;
  String gifHorientacion;
  MedidasDeSeguridad({
    required this.caracteristica,
    required this.detalle,
    required this.posicion,
    required this.idString,
    required this.verticalBias,
    required this.horizontalBias,
    required this.habilitado,
    required this.imagen,
    required this.gif,
    required this.imagenUrl,
    required this.assets,
    required this.gifHorientacion,
  });

  Map<String, dynamic> toMap() {
    return {
      'Caracteristica': caracteristica,
      'Detalle': detalle,
      'Posicion': posicion,
      'IdString': idString,
      'VerticalBias': verticalBias,
      'HorizontalBias': horizontalBias,
      'Habilitado': habilitado,
      'Imagen': imagen,
      'Gif': gif,
      'ImagenUrl': imagenUrl,
      'Assets': assets,
      'GifHorientacion': gifHorientacion,
    };
  }

  factory MedidasDeSeguridad.fromMap(Map<String, dynamic> map) {
    return MedidasDeSeguridad(
      caracteristica: map['Caracteristica'] ?? '',
      detalle: map['Detalle'] ?? '',
      posicion: map['Posicion'] ?? '',
      idString: map['IdString'] ?? '',
      verticalBias: map['VerticalBias']?.toInt() ?? 0,
      horizontalBias: map['HorizontalBias']?.toInt() ?? 0,
      habilitado: map['Habilitado'] ?? false,
      imagen: map['Imagen'] ?? '',
      gif: map['Gif'] ?? false,
      imagenUrl: map['ImagenUrl'] ?? '',
      assets: map['Assets'] ?? false,
      gifHorientacion: map['GifHorientacion'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory MedidasDeSeguridad.fromJson(String source) =>
      MedidasDeSeguridad.fromMap(json.decode(source));

  @override
  String toString() {
    return 'MedidasDeSeguridad(caracteristica: $caracteristica, detalle: $detalle, posicion: $posicion, idString: $idString, verticalBias: $verticalBias, horizontalBias: $horizontalBias, habilitado: $habilitado, imagen: $imagen, gif: $gif, imagenUrl: $imagenUrl, assets: $assets, gifHorientacion: $gifHorientacion)';
  }

  bool anverso() => posicion == 'ANVERSO';

  bool mire() => caracteristica == 'MIRE';

  double escalaHorizontal() => (((horizontalBias * 0.95) * 100) / 2800) / 100;

  double escalaVertical() => (((verticalBias * 0.95) * 100) / (2800 / 2)) / 100;

  bool reverso() => posicion == 'REVERSO';

  bool toque() => caracteristica == 'TOQUE';

  bool incline() => caracteristica == 'INCLINE';

  bool mireUltravioleta() => caracteristica == 'MIREUV';

  bool detalleArtistico() => caracteristica == 'DETALLESARTISTICOS';
}
