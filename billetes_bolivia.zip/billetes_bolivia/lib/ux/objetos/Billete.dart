// ignore_for_file: file_names, depend_on_referenced_packages, unused_local_variable

import 'dart:convert';

import 'package:billetes_bolivia/provider/providerBillete.dart';
import 'package:billetes_bolivia/ui/view/dialogo/Dialogo.dart';
import 'package:billetes_bolivia/ux/objetos/MedidasDeSeguridad.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:animate_do/animate_do.dart';
// import 'package:flutter/src/widgets/framework.dart';
// import 'package:flutter/widgets.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class Billete {
  String cabecera;
  String imagenAnverso;
  String imagenReverso;
  String imagenAnversoUV;
  String imagenReversoUV;
  List<MedidasDeSeguridad> medidasDeSeguridad;
  bool assetsAnverso;
  bool assetsReverso;
  bool assetsAnversoUV;
  bool assetsReversoUV;
  Billete(
      {required this.cabecera,
      required this.imagenAnverso,
      required this.imagenReverso,
      required this.imagenAnversoUV,
      required this.imagenReversoUV,
      required this.medidasDeSeguridad,
      required this.assetsAnverso,
      required this.assetsReverso,
      required this.assetsAnversoUV,
      required this.assetsReversoUV});

  Map<String, dynamic> toMap() {
    return {
      'Cabecera': cabecera,
      'ImagenAnverso': imagenAnverso,
      'ImagenReverso': imagenReverso,
      'ImagenAnversoUV': imagenAnversoUV,
      'ImagenReversoUV': imagenReversoUV,
      'MedidasDeSeguridad': medidasDeSeguridad.map((x) => x.toMap()).toList(),
      "assetsAnverso": assetsAnverso,
      "assetsReverso": assetsReverso,
      "assetsAnversoUV": assetsAnversoUV,
      "assetsReversoUV": assetsReversoUV
    };
  }

  factory Billete.fromMap(Map<String, dynamic> map) {
    List<dynamic> listM = map['MedidasDeSeguridad'];
    return Billete(
      cabecera: map['Cabecera'] ?? '',
      imagenAnverso: map['ImagenAnverso'] ?? '',
      imagenReverso: map['ImagenReverso'] ?? '',
      imagenAnversoUV: map['ImagenAnversoUV'] ?? '',
      imagenReversoUV: map['ImagenReversoUV'] ?? '',
      medidasDeSeguridad:
          listM.map((e) => MedidasDeSeguridad.fromMap(e)).toList(),
      assetsAnverso: map['AssetsAnverso'] ?? false,
      assetsReverso: map['AssetsReverso'] ?? false,
      assetsAnversoUV: map['AssetsAnversoUV'] ?? false,
      assetsReversoUV: map['AssetsReversoUV'] ?? false,
    );
  }

  factory Billete.valorNull() {
    return Billete(
        cabecera: '',
        imagenAnverso: '',
        imagenReverso: '',
        imagenAnversoUV: '',
        imagenReversoUV: '',
        medidasDeSeguridad: [],
        assetsAnverso: false,
        assetsReverso: false,
        assetsAnversoUV: false,
        assetsReversoUV: false);
  }

  String toJson() => json.encode(toMap());

  factory Billete.fromJson(String source) =>
      Billete.fromMap(json.decode(source));

  @override
  String toString() {
    return 'Billete(cabecera: $cabecera, imagenAnverso: $imagenAnverso, imagenReverso: $imagenReverso, imagenAnversoUV: $imagenAnversoUV, imagenReversoUV: $imagenReversoUV, medidasDeSeguridad: $medidasDeSeguridad)';
  }

  //mire
  List<MedidasDeSeguridad> obtenerAnversoMire() =>
      medidasDeSeguridad.where((x) => x.anverso() && x.mire()).toList();

  List<MedidasDeSeguridad> obtenerReversoMire() =>
      medidasDeSeguridad.where((x) => x.reverso() && x.mire()).toList();
  //toque
  List<MedidasDeSeguridad> obtenerAnversoToque() =>
      medidasDeSeguridad.where((x) => x.anverso() && x.toque()).toList();

  List<MedidasDeSeguridad> obtenerReversoToque() =>
      medidasDeSeguridad.where((x) => x.reverso() && x.toque()).toList();

  //incline
  List<MedidasDeSeguridad> obtenerAnversoIncline() =>
      medidasDeSeguridad.where((x) => x.anverso() && x.incline()).toList();

  List<MedidasDeSeguridad> obtenerReversoIncline() =>
      medidasDeSeguridad.where((x) => x.reverso() && x.incline()).toList();
  //mire ultravioleta
  List<MedidasDeSeguridad> obtenerAnversoMireUltravioleta() =>
      medidasDeSeguridad
          .where((x) => x.anverso() && x.mireUltravioleta())
          .toList();

  List<MedidasDeSeguridad> obtenerReversoMireUltravioleta() =>
      medidasDeSeguridad
          .where((x) => x.reverso() && x.mireUltravioleta())
          .toList();
  //detalle artistico
  List<MedidasDeSeguridad> obtenerAnversoDetalleArtistico() =>
      medidasDeSeguridad
          .where((x) => x.anverso() && x.detalleArtistico())
          .toList();

  List<MedidasDeSeguridad> obtenerReversoDetalleArtistico() =>
      medidasDeSeguridad
          .where((x) => x.reverso() && x.detalleArtistico())
          .toList();

  List<Widget> obtenerIndexWidget(
      int i, bool anverso, double tam, BuildContext context) {
    switch (i) {
      case 0:
        return obtenerMireWidget(anverso, tam, context);
      case 1:
        return obtenerToqueWidget(anverso, tam, context);
      case 2:
        return obtenerInclineWidget(anverso, tam, context);
      case 3:
        return obtenerMireUVWidget(anverso, tam, context);
      case 4:
        return obtenerDetalleArtisticoWidget(anverso, tam, context);
      case 5:
        return obtenerMenuWidget(tam, context);
      default:
        return [];
    }
  }

  List<Widget> obtenerMenuWidget(double tam, BuildContext context) {
    tam = tam * 0.95;
    var len = AppLocalizations.of(context)!;
    return [
      Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          menuPosicion(len.toque, Colors.green, Icons.touch_app, 1, context),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              menuPosicion(
                  len.mire, Colors.orange, Icons.remove_red_eye, 0, context),
              menuPosicion(len.detalleArtistico, Colors.blue,
                  Icons.color_lens_outlined, 4, context),
              menuPosicion(len.incline, Colors.redAccent, Icons.style_outlined,
                  2, context),
            ],
          ),
          menuPosicion(
              len.mireUV, Colors.purple, Icons.lightbulb_outlined, 3, context)
        ],
      )
    ];
  }

  List<Widget> obtenerMireWidget(
      bool anverso, double tam, BuildContext context) {
    if (anverso) {
      return obtenerAnversoMire()
          .map((e) => cololocarPosicion(
              tam, e, Icons.remove_red_eye, Colors.orange, context))
          .toList();
    } else {
      return obtenerReversoMire()
          .map((e) => cololocarPosicion(
              tam, e, Icons.remove_red_eye, Colors.orange, context))
          .toList();
    }
  }

  List<Widget> obtenerToqueWidget(
      bool anverso, double tam, BuildContext context) {
    if (anverso) {
      return obtenerAnversoToque()
          .map((e) =>
              cololocarPosicion(tam, e, Icons.touch_app, Colors.green, context))
          .toList();
    } else {
      return obtenerReversoToque()
          .map((e) =>
              cololocarPosicion(tam, e, Icons.touch_app, Colors.green, context))
          .toList();
    }
  }

  List<Widget> obtenerInclineWidget(
      bool anverso, double tam, BuildContext context) {
    if (anverso) {
      return obtenerAnversoIncline()
          .map((e) => cololocarPosicion(
              tam, e, Icons.style_outlined, Colors.redAccent, context))
          .toList();
    } else {
      return obtenerReversoIncline()
          .map((e) => cololocarPosicion(
              tam, e, Icons.style_outlined, Colors.redAccent, context))
          .toList();
    }
  }

  List<Widget> obtenerMireUVWidget(
      bool anverso, double tam, BuildContext context) {
    if (anverso) {
      return obtenerAnversoMireUltravioleta()
          .map((e) => cololocarPosicion(
              tam, e, Icons.lightbulb_outlined, Colors.purple, context))
          .toList();
    } else {
      return obtenerReversoMireUltravioleta()
          .map((e) => cololocarPosicion(
              tam, e, Icons.lightbulb_outlined, Colors.purple, context))
          .toList();
    }
  }

  List<Widget> obtenerDetalleArtisticoWidget(
      bool anverso, double tam, BuildContext context) {
    if (anverso) {
      return obtenerAnversoDetalleArtistico()
          .map((e) => cololocarPosicion(
              tam, e, Icons.color_lens_outlined, Colors.blue, context))
          .toList();
    } else {
      return obtenerReversoDetalleArtistico()
          .map((e) => cololocarPosicion(
              tam, e, Icons.color_lens_outlined, Colors.blue, context))
          .toList();
    }
  }

  Widget cololocarPosicion(double tam, MedidasDeSeguridad e, IconData icon,
      Color color, BuildContext context) {
    late AnimationController control;
    return Positioned(
      left: tam * e.escalaHorizontal(),
      top: tam * 0.5 * e.escalaVertical(),
      child: Pulse(
        key: GlobalKey(debugLabel: '${e.horizontalBias}+${e.verticalBias}'),
        controller: (a) => control = a,
        // duration: const Duration(milliseconds: 1000),
        infinite: true,
        // animate: true,
        child: InkWell(
          onTap: () {
            control.reset();
            // var global =
            //     GlobalKey(debugLabel: '${e.horizontalBias}+${e.verticalBias}');
            //     global.currentContext
            Dialogo().showDialogo(e, context);
          },
          child: ClipOval(
              child: Container(
            color: color.withOpacity(0.8),
            padding: const EdgeInsets.all(8),
            child: Icon(
              icon,
              color: Colors.white,
            ),
          )),
        ),
      ),
    );
  }

  Widget menuPosicion(
    String title,
    Color color,
    IconData icon,
    int i,
    BuildContext context,
  ) {
    return InkWell(
      onTap: () => context.read<ProviderBillete>().cambiarIndex(i),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ClipOval(
            child: Container(
              padding: const EdgeInsets.all(8),
              color: color.withOpacity(0.8),
              child: Icon(
                icon,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(
            height: 8,
          ),
          Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: color.withOpacity(0.8),
                  borderRadius: const BorderRadius.all(Radius.circular(8))),
              child: Text(title))
        ],
      ),
    );
  }

  bool isNuevoBillete() => cabecera.contains('na');
}
