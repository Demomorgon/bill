// ignore_for_file: file_names

import 'package:billetes_bolivia/Services/LocalStorage.dart';
import 'package:flutter/material.dart';

class ProviderTheme with ChangeNotifier {
  bool _darkTheme = false;
  bool _customTheme = false;

  late ThemeData _currentTheme;
  bool temeOscuro = false;

  ProviderTheme(bool tema) {
    temeOscuro = tema;
  }

  bool get darkTheme => _darkTheme;
  bool get customTheme => _customTheme;
  ThemeData get currentTheme => _currentTheme;

  // ProviderTheme(int theme) {
  //   switch (theme) {
  //     case 1: // light
  //       _darkTheme = false;
  //       _customTheme = false;
  //       _currentTheme = ThemeData.light();
  //       break;

  //     case 2: // Dark
  //       _darkTheme = true;
  //       _customTheme = false;
  //       _currentTheme = ThemeData.dark().copyWith(
  //           colorScheme:
  //               ColorScheme.fromSwatch().copyWith(secondary: Colors.pink));
  //       break;

  //     case 3: // Dark
  //       _darkTheme = false;
  //       _customTheme = true;
  //       break;

  //     default:
  //       _darkTheme = false;
  //       _darkTheme = false;
  //       _currentTheme = ThemeData.light();
  //   }
  // }

  set darkTheme(bool value) {
    _customTheme = false;
    _darkTheme = value;

    if (value) {
      _currentTheme = ThemeData.dark().copyWith(
          colorScheme:
              ColorScheme.fromSwatch().copyWith(secondary: Colors.pink));
    } else {
      _currentTheme = ThemeData.light();
    }

    notifyListeners();
  }

  set customTheme(bool value) {
    _customTheme = value;
    _darkTheme = false;

    if (value) {
      _currentTheme = ThemeData.dark().copyWith(
          primaryColorLight: Colors.white,
          scaffoldBackgroundColor: const Color(0xff16202B),
          textTheme: const TextTheme(bodyText1: TextStyle(color: Colors.white)),
          colorScheme: ColorScheme.fromSwatch()
              .copyWith(secondary: const Color(0xff48A0EB)));
    } else {
      _currentTheme = ThemeData.light();
    }

    notifyListeners();
  }

  void temaOscuro() {
    temeOscuro = true;
    LocalStore.guardarTemaOscuro();
    notifyListeners();
  }

  void temaClaro() {
    temeOscuro = false;
    LocalStore.guardarClaro();
    notifyListeners();
  }

  cambiarTema(bool sw) => sw ? temaOscuro() : temaClaro();
}
