// ignore_for_file: file_names

import 'package:billetes_bolivia/ux/objetos/Billete.dart';
import 'package:flutter/cupertino.dart';

class ProviderBillete extends ChangeNotifier {
  // Billete billetena200 = Billete.valorNull();
  // Billete billetena100 = Billete.valorNull();
  // Billete billetena50 = Billete.valorNull();
  // Billete billetena20 = Billete.valorNull();
  // Billete billetena10 = Billete.valorNull();

  // Billete billete200 = Billete.valorNull();
  // Billete billete100 = Billete.valorNull();
  // Billete billete50 = Billete.valorNull();
  // Billete billete20 = Billete.valorNull();
  // Billete billete10 = Billete.valorNull();

  Map<int, Billete> mapBillete = {};

  int index = 0;
  Duration duracionAnimacion = const Duration(milliseconds: 1000);
  bool swAnverso = true;
  bool swAnversoDialogo = true;
  bool swUV = false;
  bool swUVista = false;
  int indexBillete = 0;

  bool menuBilletes = false;
  bool menuRedesSociales = false;

  bool menuNa = false;
  bool menuA = false;

  //zoom
  TransformationController transformationController =
      TransformationController();
  void cambiarIndex(int i) {
    transformationController.value = Matrix4.identity();
    if (i == 3) {
      swUV = true;
    } else {
      swUV = false;
    }
    index = i;
    notifyListeners();
  }

  void cambiarPosicion() {
    swAnverso = !swAnverso;
    transformationController.value = Matrix4.identity();
    notifyListeners();
  }

  void cambiarPosicionDialogo() {
    swAnversoDialogo = !swAnversoDialogo;
    transformationController.value = Matrix4.identity();
    notifyListeners();
  }

  void anularVista() {
    index = -1;
    notifyListeners();
  }

  void irMenuBillete() {
    if (index != 5) {
      index = 5;
    } else {
      index = -1;
    }
    swUV = false;
    notifyListeners();
  }

  void reiniciar() {
    index = 5;
    swAnverso = true;
    swUV = false;
    transformationController.value = Matrix4.identity();
    notifyListeners();
  }

  void irDerecha() {
    transformationController.value = Matrix4.identity();
    index--;
    if (index < 0) {
      index = 5;
    }
    if (index == 3) {
      swUV = true;
    } else {
      swUV = false;
    }
    notifyListeners();
  }

  void irIzquierda() {
    transformationController.value = Matrix4.identity();
    index++;
    if (index > 5) {
      index = 0;
    }
    if (index == 3) {
      swUV = true;
    } else {
      swUV = false;
    }
    notifyListeners();
  }

  void restablecerZoom() {
    transformationController.value = Matrix4.identity();
  }

  void activarUV() {
    swUVista = !swUVista;
    notifyListeners();
  }

  Billete obtenerIndexBillete(int i) => mapBillete[i] ?? Billete.valorNull();

  void cambiarIndexBillete(int index) {
    indexBillete = index;
    notifyListeners();
  }

  void activarMenuBillete() {
    menuBilletes = !menuBilletes;
    notifyListeners();
  }

  void activarNaBillete() {
    menuNa = !menuNa;
    notifyListeners();
  }

  void activarABillete() {
    menuA = !menuA;
    notifyListeners();
  }

  void swRedesSociales() {
    menuRedesSociales = !menuRedesSociales;
    notifyListeners();
  }
}
