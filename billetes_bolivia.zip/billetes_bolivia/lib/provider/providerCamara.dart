// ignore_for_file: depend_on_referenced_packages, file_names, empty_catches, unused_catch_clause

import 'package:flutter/cupertino.dart';
import 'package:camera/camera.dart';
import 'package:flutter/services.dart';

class ProviderCamara extends ChangeNotifier {
  late List<CameraDescription> cameras;
  late CameraController controller;
  double zoom = 2;
  double zoomAux = 2;
  double zoomMin = 0;
  bool camaraInicializada = false;
  // late Future<void> inicializarFuturaCamera;

  iniciarCamara() async {
    // controller = CameraController(cameras.first, ResolutionPreset.max,
    //     enableAudio: false);

    // await controller.setExposureMode(ExposureMode.locked);
    // await controller.setExposureOffset(offset);
    // await controller.setExposurePoint(point);
    // await controller.lockCaptureOrientation();

    // inicializarFuturaCamera = controller.initialize().whenComplete(() {
    //   controller.getMaxZoomLevel().then((value) {
    //     zoom = value;
    //     zoomAux = value / 2;
    //     controller.setZoomLevel(value);
    //   });
    // });
  }

  Future<bool> obtenercamara() async {
    try {
      camaraInicializada = true;
      var value = await controller.getMaxZoomLevel();
      var valueMin = await controller.getMinZoomLevel();
      await controller.lockCaptureOrientation();
      var valor = controller.value;
      var valor2 = valor.deviceOrientation;

      // print('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
      // print(valor2);
      zoomMin = valueMin;
      zoom = value;
      zoomAux = value / 2;
      await controller.setZoomLevel(zoomAux);
      if (valor2 == DeviceOrientation.portraitUp) {
        return true;
      }
    } on Exception catch (e) {}
    return false;
  }

  void reducirZoom() {
    // print(zoomAux);
    if (zoomAux > 1) {
      zoomAux -= zoom * 0.1;
      controller.setZoomLevel(zoomAux > 1 ? zoomAux : 1.0);
    }
  }

  void ampliarZoom() {
    // print(zoomAux);
    if (zoom > zoomAux) {
      zoomAux += zoom * 0.1;
      controller.setZoomLevel(zoom > zoomAux ? zoomAux : zoom);
    }
  }

  void cambiarZoom(double value) {
    zoomAux = value;
    controller.setZoomLevel(value);
  }
}
