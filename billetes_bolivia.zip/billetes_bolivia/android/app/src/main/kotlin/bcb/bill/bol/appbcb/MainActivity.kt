package bcb.bill.bol.appbcb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
