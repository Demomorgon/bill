
import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_es.dart';

/// Callers can lookup localized strings with an instance of AppLocalizations returned
/// by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// localizationDelegates list, and the locales they support in the app's
/// supportedLocales list. For example:
///
/// ```
/// import 'gen_l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('es')
  ];

  /// No description provided for @app_name.
  ///
  /// In en, this message translates to:
  /// **'Billetes de Bolivia'**
  String get app_name;

  /// No description provided for @titulo.
  ///
  /// In en, this message translates to:
  /// **'Nuevo Billete de Bs10'**
  String get titulo;

  /// No description provided for @subtituloinfo.
  ///
  /// In en, this message translates to:
  /// **'Primera Familia de Billetes del Estado Plurinacional de Bolivia (PFB-EPB)'**
  String get subtituloinfo;

  /// No description provided for @subtitulosplash.
  ///
  /// In en, this message translates to:
  /// **'Primera Familia de Billetes del Estado Plurinacional de Bolivia'**
  String get subtitulosplash;

  /// No description provided for @titulon1.
  ///
  /// In en, this message translates to:
  /// **'Primera Familia de Billetes del Estado Plurinacional de Bolivia'**
  String get titulon1;

  /// No description provided for @titulon200.
  ///
  /// In en, this message translates to:
  /// **'Nuevo Billete de Bs200'**
  String get titulon200;

  /// No description provided for @titulon100.
  ///
  /// In en, this message translates to:
  /// **'Nuevo Billete de Bs100'**
  String get titulon100;

  /// No description provided for @titulon50.
  ///
  /// In en, this message translates to:
  /// **'Nuevo Billete de Bs50'**
  String get titulon50;

  /// No description provided for @titulon20.
  ///
  /// In en, this message translates to:
  /// **'Nuevo Billete de Bs20'**
  String get titulon20;

  /// No description provided for @titulon10.
  ///
  /// In en, this message translates to:
  /// **'Nuevo Billete de Bs10'**
  String get titulon10;

  /// No description provided for @tituloa1.
  ///
  /// In en, this message translates to:
  /// **'Familia Anterior de Billetes'**
  String get tituloa1;

  /// No description provided for @tituloa200.
  ///
  /// In en, this message translates to:
  /// **'Bs200'**
  String get tituloa200;

  /// No description provided for @tituloa100.
  ///
  /// In en, this message translates to:
  /// **'Bs100'**
  String get tituloa100;

  /// No description provided for @tituloa50.
  ///
  /// In en, this message translates to:
  /// **'Bs50'**
  String get tituloa50;

  /// No description provided for @tituloa20.
  ///
  /// In en, this message translates to:
  /// **'Bs20'**
  String get tituloa20;

  /// No description provided for @tituloa10.
  ///
  /// In en, this message translates to:
  /// **'Bs10'**
  String get tituloa10;

  /// No description provided for @web.
  ///
  /// In en, this message translates to:
  /// **'www.bcb.gob.bo'**
  String get web;

  /// No description provided for @version.
  ///
  /// In en, this message translates to:
  /// **'Versión'**
  String get version;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'primerafamiliabilletes@bcb.gob.bo'**
  String get email;

  /// No description provided for @navigation_drawer_open.
  ///
  /// In en, this message translates to:
  /// **'Abierto'**
  String get navigation_drawer_open;

  /// No description provided for @navigation_drawer_close.
  ///
  /// In en, this message translates to:
  /// **'Cerrado'**
  String get navigation_drawer_close;

  /// No description provided for @menuTitulo1.
  ///
  /// In en, this message translates to:
  /// **'Billetes'**
  String get menuTitulo1;

  /// No description provided for @menuTitulo11.
  ///
  /// In en, this message translates to:
  /// **'1ra Familia de Billetes del EPB'**
  String get menuTitulo11;

  /// No description provided for @menuTitulo111.
  ///
  /// In en, this message translates to:
  /// **'Bs10'**
  String get menuTitulo111;

  /// No description provided for @menuTitulo112.
  ///
  /// In en, this message translates to:
  /// **'Bs20'**
  String get menuTitulo112;

  /// No description provided for @menuTitulo113.
  ///
  /// In en, this message translates to:
  /// **'Bs50'**
  String get menuTitulo113;

  /// No description provided for @menuTitulo114.
  ///
  /// In en, this message translates to:
  /// **'Bs100'**
  String get menuTitulo114;

  /// No description provided for @menuTitulo115.
  ///
  /// In en, this message translates to:
  /// **'Bs200'**
  String get menuTitulo115;

  /// No description provided for @menuTitulo12.
  ///
  /// In en, this message translates to:
  /// **'Familia Anterior'**
  String get menuTitulo12;

  /// No description provided for @menuTitulo121.
  ///
  /// In en, this message translates to:
  /// **'Bs200'**
  String get menuTitulo121;

  /// No description provided for @menuTitulo122.
  ///
  /// In en, this message translates to:
  /// **'Bs100'**
  String get menuTitulo122;

  /// No description provided for @menuTitulo123.
  ///
  /// In en, this message translates to:
  /// **'Bs50'**
  String get menuTitulo123;

  /// No description provided for @menuTitulo124.
  ///
  /// In en, this message translates to:
  /// **'Bs20'**
  String get menuTitulo124;

  /// No description provided for @menuTitulo125.
  ///
  /// In en, this message translates to:
  /// **'Bs10'**
  String get menuTitulo125;

  /// No description provided for @menuTitulo3.
  ///
  /// In en, this message translates to:
  /// **'Herramientas'**
  String get menuTitulo3;

  /// No description provided for @menuTitulo31.
  ///
  /// In en, this message translates to:
  /// **'Luz Ultravioleta'**
  String get menuTitulo31;

  /// No description provided for @menuTitulo32.
  ///
  /// In en, this message translates to:
  /// **'Lupa'**
  String get menuTitulo32;

  /// No description provided for @menuTitulo2.
  ///
  /// In en, this message translates to:
  /// **'Enlaces'**
  String get menuTitulo2;

  /// No description provided for @menuTitulo21.
  ///
  /// In en, this message translates to:
  /// **'Facebook'**
  String get menuTitulo21;

  /// No description provided for @menuTitulo23.
  ///
  /// In en, this message translates to:
  /// **'Twitter'**
  String get menuTitulo23;

  /// No description provided for @menuTitulo22.
  ///
  /// In en, this message translates to:
  /// **'www.bcb.gob.bo'**
  String get menuTitulo22;

  /// No description provided for @menuTitulo4.
  ///
  /// In en, this message translates to:
  /// **'Ayuda'**
  String get menuTitulo4;

  /// No description provided for @menuTitulo41.
  ///
  /// In en, this message translates to:
  /// **'Información'**
  String get menuTitulo41;

  /// No description provided for @optionImage1.
  ///
  /// In en, this message translates to:
  /// **'Mire'**
  String get optionImage1;

  /// No description provided for @optionImage2.
  ///
  /// In en, this message translates to:
  /// **'Toque'**
  String get optionImage2;

  /// No description provided for @optionImage3.
  ///
  /// In en, this message translates to:
  /// **'Incline'**
  String get optionImage3;

  /// No description provided for @optionImage4.
  ///
  /// In en, this message translates to:
  /// **'Mire Ultravioleta'**
  String get optionImage4;

  /// No description provided for @optionImage5.
  ///
  /// In en, this message translates to:
  /// **'Detalles Artísticos'**
  String get optionImage5;

  /// No description provided for @a10Mire1.
  ///
  /// In en, this message translates to:
  /// **'La marca de agua incluye tres elementos: la imagen del personaje histórico (Cecilio Guzman de Rojas), el cuadro de puntos ubicados al lado del personaje histórico y el valor del billete escrito en sentido vertical.'**
  String get a10Mire1;

  /// No description provided for @a10Mire2.
  ///
  /// In en, this message translates to:
  /// **'Figura geométrica impresa en el anverso y reverso del billete, que vista a contraluz encaja exactamente.'**
  String get a10Mire2;

  /// No description provided for @a10Mire3.
  ///
  /// In en, this message translates to:
  /// **'Pequeños hilos de color amarillo, rojo, verde y azul, que se encuentran en ambos lados del billete.'**
  String get a10Mire3;

  /// No description provided for @a10Toque1.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. El corte de Bs10 lleva dos barras en alto relieve en posición horizontal.'**
  String get a10Toque1;

  /// No description provided for @a10Toque2.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de Cecilio Guzman de Rojas está impresa en alto relieve.'**
  String get a10Toque2;

  /// No description provided for @a10Incline1.
  ///
  /// In en, this message translates to:
  /// **'Ubicada en el anverso del billete, al inclinarse se observa la sigla BCB.\n'**
  String get a10Incline1;

  /// No description provided for @a10Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el anverso del billete:\n\ni)  Escudo del Estado Plurinacional de Bolivia.\n\nii) Valor del corte del billete.\n\niii) Firmas y números de serie.\n\niv) Figuras geométricas propias del corte.\n\nv)  Fibrillas de seguridad.\n\n'**
  String get a10Mireuv1;

  /// No description provided for @a10Arte1.
  ///
  /// In en, this message translates to:
  /// **'Destacado pintor Potosino nació en 1899 y falleció en 1950. Es considerado iniciador de una corriente pictórica de marcada inclinación indigenista. Sus pinturas valoran de sobremanera las raíces de Bolivia, por ello pinta rostros y escenas aymaras en paisajes altiplánicos. También sobresalió por su tenaz tarea en defensa del patrimonio artístico boliviano, la catalogación y la restauración de obras de arte.'**
  String get a10Arte1;

  /// No description provided for @r10Toque1.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de las Heroínas de la Coronilla y el paisaje de Cochabamba está impresa en alto relieve.'**
  String get r10Toque1;

  /// No description provided for @r10Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el reverso del billete:\n\ni) Fibrillas de seguridad.'**
  String get r10Mireuv1;

  /// No description provided for @r10Arte1.
  ///
  /// In en, this message translates to:
  /// **'Se aprecia un paisaje de la ciudad de Cochabamba con el monumento de las Heroínas de la Coronilla en el frente que fue Declarado declarado Monumento Nacional en 1926; se encuentra en la Colina de San Sebastián de la ciudad de Cochabamba.'**
  String get r10Arte1;

  /// No description provided for @a10Mire1T.
  ///
  /// In en, this message translates to:
  /// **'MARCA DE AGUA'**
  String get a10Mire1T;

  /// No description provided for @a10Mire2T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get a10Mire2T;

  /// No description provided for @a10Mire3T.
  ///
  /// In en, this message translates to:
  /// **'FIBRILLAS'**
  String get a10Mire3T;

  /// No description provided for @a10Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get a10Toque1T;

  /// No description provided for @a10Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get a10Toque2T;

  /// No description provided for @a10Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN LATENTE'**
  String get a10Incline1T;

  /// No description provided for @a10Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA ANVERSO'**
  String get a10Mireuv1T;

  /// No description provided for @a10Arte1T.
  ///
  /// In en, this message translates to:
  /// **'CECILIO GUZMAN DE ROJAS'**
  String get a10Arte1T;

  /// No description provided for @r10Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get r10Toque1T;

  /// No description provided for @r10Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA REVERSO'**
  String get r10Mireuv1T;

  /// No description provided for @r10Arte1T.
  ///
  /// In en, this message translates to:
  /// **'HEROINAS DE LA CORONILLA'**
  String get r10Arte1T;

  /// No description provided for @a20Mire1.
  ///
  /// In en, this message translates to:
  /// **'Pequeños hilos de color amarillo, rojo, verde y azul, que se encuentran en ambos lados del billete.'**
  String get a20Mire1;

  /// No description provided for @a20Mire2.
  ///
  /// In en, this message translates to:
  /// **'La marca de agua incluye tres elementos: la imagen del personaje histórico (Pantaleón Dalence), el cuadro de puntos ubicados al lado del personaje histórico y el valor del billete escrito en sentido vertical.'**
  String get a20Mire2;

  /// No description provided for @a20Mire3.
  ///
  /// In en, this message translates to:
  /// **'Figura geométrica impresa en el anverso y reverso del billete, que vista a contraluz encaja exactamente.'**
  String get a20Mire3;

  /// No description provided for @a20Toque1.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. El corte de Bs20 lleva tres barras en alto relieve en posición horizontal.'**
  String get a20Toque1;

  /// No description provided for @a20Toque2.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de Pantaleón Dalence está impresa en alto relieve.'**
  String get a20Toque2;

  /// No description provided for @a20Incline1.
  ///
  /// In en, this message translates to:
  /// **'Ubicada en el anverso del billete, al inclinarse se observa la sigla BCB.\n'**
  String get a20Incline1;

  /// No description provided for @a20Incline2.
  ///
  /// In en, this message translates to:
  /// **'El hilo de seguridad es de 3 milímetros de ancho y sobresale nítidamente en el anverso del billete, lleva la sigla BCB y el valor del billete; tiene un efecto de cambio de color  de verde a magenta que se observa  al inclinarlo.'**
  String get a20Incline2;

  /// No description provided for @a20Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el anverso del billete:\n\ni)  Escudo del Estado Plurinacional de Bolivia.\n\nii) Valor del corte del billete.\n\niii) Firmas y números de serie.\n\niv) Figuras geométricas propias del corte.\n\nv)  Fibrillas de seguridad.\n\nvi) Hilo de seguridad.\n\nvii) Motivo coincidente.'**
  String get a20Mireuv1;

  /// No description provided for @a20Arte1.
  ///
  /// In en, this message translates to:
  /// **'El billete de 20 bolivianos muestra, en el anverso la efigie del abogado Don Pantaleón Dalence (1815 – 1892), es considerado “padre de la justicia boliviana” por su constante lucha contra la corrupción, fue profesor de matemáticas, Munícipe, Prefecto, Oficial Mayor de Instrucción Pública, Fiscal General de la República y Ministro de Hacienda, su mayor contribución al derecho boliviano fue haber delimitado las atribuciones de los tres poderes del Estado y haber sido un “guardián celoso” de la Constitución.'**
  String get a20Arte1;

  /// No description provided for @r20Toque1.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de la Casa Dorada Tarija está impresa en alto relieve.'**
  String get r20Toque1;

  /// No description provided for @r20Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el reverso del billete:\n\ni)  Hilo de seguridad.\n\nii) Fibrillas de seguridad.\n'**
  String get r20Mireuv1;

  /// No description provided for @r20Arte1.
  ///
  /// In en, this message translates to:
  /// **'La Casa Dorada de Tarija, hogar del magnate Moisés Navajas, hoy convertida en la Casa de la Cultura de esa capital y que constituye una de las más bellas muestras arquitectónicas de Bolivia, fue diseñada por el arquitecto Antonio Camponovo.'**
  String get r20Arte1;

  /// No description provided for @a20Mire2T.
  ///
  /// In en, this message translates to:
  /// **'MARCA DE AGUA'**
  String get a20Mire2T;

  /// No description provided for @a20Mire3T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get a20Mire3T;

  /// No description provided for @a20Mire1T.
  ///
  /// In en, this message translates to:
  /// **'FIBRILLAS'**
  String get a20Mire1T;

  /// No description provided for @a20Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get a20Toque1T;

  /// No description provided for @a20Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get a20Toque2T;

  /// No description provided for @a20Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN LATENTE'**
  String get a20Incline1T;

  /// No description provided for @a20Incline2T.
  ///
  /// In en, this message translates to:
  /// **'HILO DE SEGURIDAD'**
  String get a20Incline2T;

  /// No description provided for @a20Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA ANVERSO'**
  String get a20Mireuv1T;

  /// No description provided for @a20Arte1T.
  ///
  /// In en, this message translates to:
  /// **'PANTALEON DALENCE'**
  String get a20Arte1T;

  /// No description provided for @r20Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get r20Toque1T;

  /// No description provided for @r20Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA REVERSO'**
  String get r20Mireuv1T;

  /// No description provided for @r20Arte1T.
  ///
  /// In en, this message translates to:
  /// **'CASA DORADA TARIJA'**
  String get r20Arte1T;

  /// No description provided for @a50Mire1.
  ///
  /// In en, this message translates to:
  /// **'Pequeños hilos de color amarillo, rojo, verde y azul, que se encuentran en ambos lados del billete.'**
  String get a50Mire1;

  /// No description provided for @a50Mire2.
  ///
  /// In en, this message translates to:
  /// **'La marca de agua incluye tres elementos: la imagen del personaje histórico (Melchor Perez de Holguín), el cuadro de puntos ubicados al lado del personaje histórico y el valor del billete escrito en sentido vertical.'**
  String get a50Mire2;

  /// No description provided for @a50Mire3.
  ///
  /// In en, this message translates to:
  /// **'Figura geométrica impresa en el anverso y reverso del billete, que vista a contraluz encaja exactamente.'**
  String get a50Mire3;

  /// No description provided for @a50Toque1.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. El corte de Bs50 lleva una barra en alto relieve en posición vertical.'**
  String get a50Toque1;

  /// No description provided for @a50Toque2.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de Melchor Perez de Holguin está impresa en alto relieve.'**
  String get a50Toque2;

  /// No description provided for @a50Incline1.
  ///
  /// In en, this message translates to:
  /// **'El hilo de seguridad es de 3 milímetros de ancho y sobresale nítidamente en el anverso del billete, lleva la sigla BCB y el valor del billete; tiene un efecto de cambio de color  de magenta a verde que se observa  al inclinarlo.'**
  String get a50Incline1;

  /// No description provided for @a50Incline2.
  ///
  /// In en, this message translates to:
  /// **'Ubicada en el anverso del billete, al inclinarse se observa la sigla BCB.\n'**
  String get a50Incline2;

  /// No description provided for @a50Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el anverso del billete:\n\ni)  Escudo del Estado Plurinacional de Bolivia.\n\nii) Valor del corte del billete.\n\niii) Firmas y números de serie.\n\niv) Figuras geométricas propias del corte.\n\nv)  Fibrillas de seguridad.\n\nvi) Hilo de seguridad.\n'**
  String get a50Mireuv1;

  /// No description provided for @a50Arte1.
  ///
  /// In en, this message translates to:
  /// **'Pintor Cochabambino de la época colonial, nace en 1660 y fallece en 1732. Es considerado el pintor más representativo del período colonial del Alto Perú.'**
  String get a50Arte1;

  /// No description provided for @r50Toque1.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de la Torre de la Compañía está impresa en alto relieve.'**
  String get r50Toque1;

  /// No description provided for @r50Incline1.
  ///
  /// In en, this message translates to:
  /// **'De color dorado, se encuentra presente en el reverso del billete a partir de la serie “H”. Lleva sobreimpreso el valor del corte “50” y la sigla BCB, que son fácilmente reconocibles al inclinar el billete.'**
  String get r50Incline1;

  /// No description provided for @r50Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el reverso del billete:\n\ni)  Hilo de seguridad.\n\nii) Fibrillas de seguridad.'**
  String get r50Mireuv1;

  /// No description provided for @r50Arte1.
  ///
  /// In en, this message translates to:
  /// **'La Torre de la Compañía, es un convento ubicado en la ciudad de Potosí, junto al Cerro Rico y la Casa de la Moneda, fue trabajada durante siete años por el artífice Sebastián de la Cruz.'**
  String get r50Arte1;

  /// No description provided for @a50Mire1T.
  ///
  /// In en, this message translates to:
  /// **'FIBRILLAS'**
  String get a50Mire1T;

  /// No description provided for @a50Mire2T.
  ///
  /// In en, this message translates to:
  /// **'MARCA DE AGUA'**
  String get a50Mire2T;

  /// No description provided for @a50Mire3T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get a50Mire3T;

  /// No description provided for @a50Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get a50Toque1T;

  /// No description provided for @a50Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get a50Toque2T;

  /// No description provided for @a50Incline1T.
  ///
  /// In en, this message translates to:
  /// **'HILO DE SEGURIDAD'**
  String get a50Incline1T;

  /// No description provided for @a50Incline2T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN LATENTE'**
  String get a50Incline2T;

  /// No description provided for @a50Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA ANVERSO'**
  String get a50Mireuv1T;

  /// No description provided for @a50Arte1T.
  ///
  /// In en, this message translates to:
  /// **'MELCHOR PEREZ DE HOLGUIN'**
  String get a50Arte1T;

  /// No description provided for @r50Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get r50Toque1T;

  /// No description provided for @r50Incline1T.
  ///
  /// In en, this message translates to:
  /// **'BANDA IRIDISCENTE'**
  String get r50Incline1T;

  /// No description provided for @r50Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA REVERSO'**
  String get r50Mireuv1T;

  /// No description provided for @r50Arte1T.
  ///
  /// In en, this message translates to:
  /// **'TORRE DE LA COMPAÑIA'**
  String get r50Arte1T;

  /// No description provided for @a100Mire1.
  ///
  /// In en, this message translates to:
  /// **'Pequeños hilos de color amarillo, rojo, verde y azul, que se encuentran en ambos lados del billete.'**
  String get a100Mire1;

  /// No description provided for @a100Mire2.
  ///
  /// In en, this message translates to:
  /// **'La marca de agua incluye tres elementos: la imagen del personaje histórico (Gabriel René Moreno), el cuadro de puntos ubicados al lado del personaje histórico y el valor del billete escrito en sentido vertical.'**
  String get a100Mire2;

  /// No description provided for @a100Mire3.
  ///
  /// In en, this message translates to:
  /// **'Figura geométrica impresa en el anverso y reverso del billete, que vista a contraluz encaja exactamente.'**
  String get a100Mire3;

  /// No description provided for @a100Toque1.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. El corte de Bs100 lleva dos barras en alto relieve en posición vertical.'**
  String get a100Toque1;

  /// No description provided for @a100Toque2.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de Gabriel René Moreno está impresa en alto relieve.'**
  String get a100Toque2;

  /// No description provided for @a100Incline1.
  ///
  /// In en, this message translates to:
  /// **'El hilo de seguridad es de 4 milímetros de ancho y sobresale nítidamente en el anverso del billete, lleva la sigla BCB y el valor del billete; tiene un efecto de cambio de color  de verde a azul que se observa  al inclinarlo.'**
  String get a100Incline1;

  /// No description provided for @a100Incline2.
  ///
  /// In en, this message translates to:
  /// **'Ubicada en el anverso del billete, al inclinarse se observa la sigla BCB.\n'**
  String get a100Incline2;

  /// No description provided for @a100Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el anverso del billete:\n\ni)  Escudo del Estado Plurinacional de Bolivia.\n\nii) Valor del corte del billete.\n\niii) Firmas y números de serie.\n\niv) Figuras geométricas propias del corte.\n\nv)  Fibrillas de seguridad.\n\nvi) Hilo de seguridad.\n'**
  String get a100Mireuv1;

  /// No description provided for @a100Arte1.
  ///
  /// In en, this message translates to:
  /// **'Destacado historiador y educador, nació en la ciudad de Santa Cruz el año 1836 y falleció en 1908, documentó la historia de Bolivia y creó una metodología de investigación histórica. En reconocimiento a su trayectoria la universidad estatal de la ciudad de Santa Cruz lleva su nombre.'**
  String get a100Arte1;

  /// No description provided for @r100Toque1.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de la Universidad San Francisco Xavier está impresa en alto relieve.'**
  String get r100Toque1;

  /// No description provided for @r100Incline1.
  ///
  /// In en, this message translates to:
  /// **'De color dorado, se encuentra presente en el reverso del billete, a partir de la serie “H”. Lleva sobreimpreso el valor del billete “100” y la sigla BCB, que son fácilmente reconocibles al inclinar el billete.'**
  String get r100Incline1;

  /// No description provided for @r100Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el reverso del billete:\n\ni)  Hilo de seguridad.\n\nii) Fibrillas de seguridad.'**
  String get r100Mireuv1;

  /// No description provided for @r100Arte1.
  ///
  /// In en, this message translates to:
  /// **'Fue fundada el 27 de marzo de 1624, por el padre Jesuita Juan Frías de Herrán está ubicada en la ciudad de Sucre.'**
  String get r100Arte1;

  /// No description provided for @a100Mire1T.
  ///
  /// In en, this message translates to:
  /// **'FIBRILLAS'**
  String get a100Mire1T;

  /// No description provided for @a100Mire2T.
  ///
  /// In en, this message translates to:
  /// **'MARCA DE AGUA'**
  String get a100Mire2T;

  /// No description provided for @a100Mire3T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get a100Mire3T;

  /// No description provided for @a100Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get a100Toque1T;

  /// No description provided for @a100Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get a100Toque2T;

  /// No description provided for @a100Incline1T.
  ///
  /// In en, this message translates to:
  /// **'HILO DE SEGURIDAD'**
  String get a100Incline1T;

  /// No description provided for @a100Incline2T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN LATENTE'**
  String get a100Incline2T;

  /// No description provided for @a100Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA ANVERSO'**
  String get a100Mireuv1T;

  /// No description provided for @a100Arte1T.
  ///
  /// In en, this message translates to:
  /// **'GABRIEL RENE MORENO'**
  String get a100Arte1T;

  /// No description provided for @r100Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get r100Toque1T;

  /// No description provided for @r100Incline1T.
  ///
  /// In en, this message translates to:
  /// **'BANDA IRIDISCENTE'**
  String get r100Incline1T;

  /// No description provided for @r100Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA REVERSO'**
  String get r100Mireuv1T;

  /// No description provided for @r100Arte1T.
  ///
  /// In en, this message translates to:
  /// **'UNIVERSIDAD SAN FRANCISCO XAVIER DE CHUQUISACA'**
  String get r100Arte1T;

  /// No description provided for @a200Mire1.
  ///
  /// In en, this message translates to:
  /// **'Pequeños hilos de color amarillo, rojo, verde y azul, que se encuentran en ambos lados del billete.'**
  String get a200Mire1;

  /// No description provided for @a200Mire2.
  ///
  /// In en, this message translates to:
  /// **'La marca de agua incluye tres elementos: la imagen del personaje histórico (Franz Tamayo), el cuadro de puntos ubicados al lado del personaje histórico y el valor del billete escrito en sentido vertical.'**
  String get a200Mire2;

  /// No description provided for @a200Mire3.
  ///
  /// In en, this message translates to:
  /// **'Figura geométrica impresa en el anverso y reverso del billete, que vista a contraluz encaja exactamente.'**
  String get a200Mire3;

  /// No description provided for @a200Toque1.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. El corte de Bs200 lleva tres barras en alto relieve en posición vertical.'**
  String get a200Toque1;

  /// No description provided for @a200Toque2.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de Franz Tamayo está impresa en alto relieve.'**
  String get a200Toque2;

  /// No description provided for @a200Incline1.
  ///
  /// In en, this message translates to:
  /// **'El hilo de seguridad es de 4 milímetros de ancho y sobresale nítidamente en el anverso del billete, lleva la sigla BCB y el valor del billete; tiene un efecto de cambio de color  de oro a verde que se observa  al inclinarlo.'**
  String get a200Incline1;

  /// No description provided for @a200Incline2.
  ///
  /// In en, this message translates to:
  /// **'Ubicada en el anverso del billete, al inclinarse se observa la sigla BCB.\n'**
  String get a200Incline2;

  /// No description provided for @a200Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el anverso del billete:\n\ni)  Escudo del Estado Plurinacional de Bolivia.\n\nii) Valor del corte del billete.\n\niii) Firmas y números de serie.\n\niv) Figuras geométricas propias del corte.\n\nv)  Fibrillas de seguridad.\n\nvi) Hilo de seguridad.\n\nvii) Motivo coincidente.'**
  String get a200Mireuv1;

  /// No description provided for @a200Arte1.
  ///
  /// In en, this message translates to:
  /// **'Poeta, político y diplomático boliviano, nace en La Paz en 1879 y fallece en 1956. Franz Tamayo Escribió virtuosas poesías que se convirtieron en las más representativas de Iberoamérica, como la “Prometheida” y “Odas”.'**
  String get a200Arte1;

  /// No description provided for @r200Toque1.
  ///
  /// In en, this message translates to:
  /// **'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de la cultura Tiahuanacota  está impresa en alto relieve.'**
  String get r200Toque1;

  /// No description provided for @r200Incline1.
  ///
  /// In en, this message translates to:
  /// **'De color dorado, se encuentra presente en el reverso del billete de Bs200 a partir de la serie “H”. Lleva sobreimpreso el valor del corte “200” y la sigla BCB, que son fácilmente reconocibles al inclinar el billete. '**
  String get r200Incline1;

  /// No description provided for @r200Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el reverso del billete:\n\ni)  Hilo de seguridad.\n\nii) Fibrillas de seguridad.'**
  String get r200Mireuv1;

  /// No description provided for @r200Arte1.
  ///
  /// In en, this message translates to:
  /// **'Se muestra las milenarias ruinas pre-incaicas de Tiahuanaco, ubicadas en las cercanías del Lago Titicaca.'**
  String get r200Arte1;

  /// No description provided for @a200Mire1T.
  ///
  /// In en, this message translates to:
  /// **'FIBRILLAS'**
  String get a200Mire1T;

  /// No description provided for @a200Mire2T.
  ///
  /// In en, this message translates to:
  /// **'MARCA DE AGUA'**
  String get a200Mire2T;

  /// No description provided for @a200Mire3T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get a200Mire3T;

  /// No description provided for @a200Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get a200Toque1T;

  /// No description provided for @a200Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get a200Toque2T;

  /// No description provided for @a200Incline1T.
  ///
  /// In en, this message translates to:
  /// **'HILO DE SEGURIDAD'**
  String get a200Incline1T;

  /// No description provided for @a200Incline2T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN LATENTE'**
  String get a200Incline2T;

  /// No description provided for @a200Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA ANVERSO'**
  String get a200Mireuv1T;

  /// No description provided for @a200Arte1T.
  ///
  /// In en, this message translates to:
  /// **'FRANZ TAMAYO'**
  String get a200Arte1T;

  /// No description provided for @r200Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get r200Toque1T;

  /// No description provided for @r200Incline1T.
  ///
  /// In en, this message translates to:
  /// **'BANDA IRIDISCENTE'**
  String get r200Incline1T;

  /// No description provided for @r200Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA REVERSO'**
  String get r200Mireuv1T;

  /// No description provided for @r200Arte1T.
  ///
  /// In en, this message translates to:
  /// **'CULTURA TIAHUANACOTA'**
  String get r200Arte1T;

  /// No description provided for @na10Mire1.
  ///
  /// In en, this message translates to:
  /// **'Compuesta por tres elementos que vistos a contraluz reproducen:\n\ni) La imagen de José Santos Vargas.\n\nii) Un tambor al lado del personaje formado por puntos.\n\niii) El valor del billete “10” en la parte inferior.'**
  String get na10Mire1;

  /// No description provided for @na10Mire2.
  ///
  /// In en, this message translates to:
  /// **'Pequeños y delgados hilos de color rojo, amarillo, verde y azul que se encuentran inmersos y distribuidos al azar en todo el billete.'**
  String get na10Mire2;

  /// No description provided for @na10Mire3.
  ///
  /// In en, this message translates to:
  /// **'Impresiones en ambos lados del billete, en la parte inferior izquierda del anverso y derecha del reverso, que vistas a contraluz completan exactamente el número “10” entre el color azul y naranja.'**
  String get na10Mire3;

  /// No description provided for @na10Toque1.
  ///
  /// In en, this message translates to:
  /// **'En la parte superior izquierda debajo del número “10”, al igual que en la familia anterior, aparecen dos barras en alto relieve.'**
  String get na10Toque1;

  /// No description provided for @na10Toque2.
  ///
  /// In en, this message translates to:
  /// **'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.'**
  String get na10Toque2;

  /// No description provided for @na10Toque3.
  ///
  /// In en, this message translates to:
  /// **'En los bordes izquierdo y derecho del anverso del billete se sienten al tacto un bloque de 16 líneas cortas diagonales en alto relieve.'**
  String get na10Toque3;

  /// No description provided for @na10Toque4.
  ///
  /// In en, this message translates to:
  /// **'Es una impresión con relieve perceptible al tacto que se encuentra en los personajes, textos y valores del corte, “10”.'**
  String get na10Toque4;

  /// No description provided for @na10Toque5.
  ///
  /// In en, this message translates to:
  /// **'Los billetes están impresos en un papel especial de 100% algodón, cuyo grosor, calidad y textura son fáciles de sentir al tacto.'**
  String get na10Toque5;

  /// No description provided for @na10Incline1.
  ///
  /// In en, this message translates to:
  /// **'Imagen del valor del corte del billete “10”, ubicada sobre un cuadro azul en la parte inferior derecha del anverso, visible al inclinarlo.\n\n\n'**
  String get na10Incline1;

  /// No description provided for @na10Incline2.
  ///
  /// In en, this message translates to:
  /// **'Está ubicado en el anverso del billete, tiene 4 milímetros de ancho, lleva la imagen de José Santos Vargas y el valor del corte “10”. Al inclinarlo, cambia del color turquesa al azul.\n\n\n'**
  String get na10Incline2;

  /// No description provided for @na10Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'En el anverso de los billetes se pueden observar los siguientes elementos:\n\ni)  El hilo de seguridad con fluorescencia roja, amarilla y verde.\n\nii) El Escudo del Estado Plurinacional de Bolivia, valor del corte, números de serie y firmas de las autoridades del BCB, con fluorescencia.\n\niii)Las fibrillas con fluorescencia roja, amarilla y azul'**
  String get na10Mireuv1;

  /// No description provided for @na10Arte1.
  ///
  /// In en, this message translates to:
  /// **'(Oruro, 1796-s/f).\n\nGuerrillero que combatió alrededor de 10 años en la Guerra de la Independencia, hasta adquirir el rango de Comandante de Mohosa. Escribió un Diario que es considerado uno de los documentos más fascinantes de esa lucha.'**
  String get na10Arte1;

  /// No description provided for @na10Arte2.
  ///
  /// In en, this message translates to:
  /// **'(Región Guaraní, 1863-1892).\n\nLíder indígena guaraní que luchó contra el avasallamiento de las tierras de su pueblo y el abuso de poder de las autoridades de la época. Logró sobrevivir a la matanza de Kuruyuki (1892), pero luego fue apresado y ejecutado.'**
  String get na10Arte2;

  /// No description provided for @na10Arte3.
  ///
  /// In en, this message translates to:
  /// **'(Tarija, 1784-1849).\n\nLíder guerrillero que durante la Guerra de la Independencia participó en las batallas de Tucumán (1812), Salta (1813) y la Tablada (1817). Promovió la incorporación de Tarija a la República de Bolivia, a pesar de los fuertes vínculos que mantenía con sus compañeros de lucha de Salta.'**
  String get na10Arte3;

  /// No description provided for @na10Arte4.
  ///
  /// In en, this message translates to:
  /// **'Gruta natural de múltiples galerías de roca caliza, en las cuales se formaron llamativas figuras, entre ellas un escenario teatral.\n\nSe constituye en la caverna más extensa (7.000 metros) y profunda (164 metros) de Bolivia. Es uno de los sitios turísticos más visitados del país.\n'**
  String get na10Arte4;

  /// No description provided for @nr10Mire1.
  ///
  /// In en, this message translates to:
  /// **'Consiste en formar exactamente el número “10” al unir los bordes izquierdo y derecho del reverso del billete.'**
  String get nr10Mire1;

  /// No description provided for @nr10Mire2.
  ///
  /// In en, this message translates to:
  /// **'Impresiones en ambos lados del billete, en la parte inferior derecha del reverso e izquierda del anverso, que vistas a contraluz completan exactamente el número “10” entre el color naranja y azul.'**
  String get nr10Mire2;

  /// No description provided for @nr10Toque1.
  ///
  /// In en, this message translates to:
  /// **'El número “10” y el texto “DIEZ BOLIVIANOS” están impresos en alto relieve.'**
  String get nr10Toque1;

  /// No description provided for @nr10Toque2.
  ///
  /// In en, this message translates to:
  /// **'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.'**
  String get nr10Toque2;

  /// No description provided for @nr10Toque3.
  ///
  /// In en, this message translates to:
  /// **'Las líneas horizontales en los bordes superior e inferior del billete están impresas en alto relieve.'**
  String get nr10Toque3;

  /// No description provided for @nr10Incline1.
  ///
  /// In en, this message translates to:
  /// **'En el reverso del billete está impreso, con tinta especial, un Picaflor Gigante. Al inclinarlo muestra un efecto con movimiento de arriba hacia abajo, con cambio de color de oro a verde.\n'**
  String get nr10Incline1;

  /// No description provided for @nr10Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'En el reverso de los billetes se pueden observar con luz ultravioleta:\n\n i) La Puya Raimondi y el valor del corte con fluorescencia roja.\n\nii)Las fibrillas con fluorescencia roja, amarilla y azul.'**
  String get nr10Mireuv1;

  /// No description provided for @nr10Arte1.
  ///
  /// In en, this message translates to:
  /// **'Atractivo turístico ubicado en medio del Salar de Uyuni, que a la distancia se asemeja a la figura de un pez.\n\nDesde su cumbre se observa el volcán Tunupa y el Salar de Uyuni, una de las maravillas naturales del mundo.\n'**
  String get nr10Arte1;

  /// No description provided for @nr10Arte2.
  ///
  /// In en, this message translates to:
  /// **'Ave de la región andina que se caracteriza por su gran tamaño (hasta 22 centímetros) con relación a otras de su especie.\n\nTiene la habilidad de cambiar fácilmente de dirección mientras vuela, incluso en reversa. Se mantiene suspendida en el aire para alimentarse del néctar de la flora del lugar.\n'**
  String get nr10Arte2;

  /// No description provided for @nr10Arte3.
  ///
  /// In en, this message translates to:
  /// **'Planta de gran tamaño que supera los 10 metros, propia de la zona andina, cuya floración ocurre una sola vez cuando llega a una edad aproximada de 80 años, para luego morir.\n\nPor la constante disminución de su población, se encuentra en peligro de extinción.\n'**
  String get nr10Arte3;

  /// No description provided for @na10Mire1T.
  ///
  /// In en, this message translates to:
  /// **'MARCA DE AGUA'**
  String get na10Mire1T;

  /// No description provided for @na10Mire2T.
  ///
  /// In en, this message translates to:
  /// **'FIBRILLAS'**
  String get na10Mire2T;

  /// No description provided for @na10Mire3T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get na10Mire3T;

  /// No description provided for @na10Toque1T.
  ///
  /// In en, this message translates to:
  /// **'BARRAS EN ALTO RELIEVE'**
  String get na10Toque1T;

  /// No description provided for @na10Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get na10Toque2T;

  /// No description provided for @na10Toque3T.
  ///
  /// In en, this message translates to:
  /// **'LINEAS EN ALTO RELIEVE'**
  String get na10Toque3T;

  /// No description provided for @na10Toque4T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get na10Toque4T;

  /// No description provided for @na10Toque5T.
  ///
  /// In en, this message translates to:
  /// **'CALIDAD DEL PAPEL'**
  String get na10Toque5T;

  /// No description provided for @na10Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN LATENTE'**
  String get na10Incline1T;

  /// No description provided for @na10Incline2T.
  ///
  /// In en, this message translates to:
  /// **'HILO DE SEGURIDAD'**
  String get na10Incline2T;

  /// No description provided for @na10Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA ANVERSO'**
  String get na10Mireuv1T;

  /// No description provided for @na10Arte1T.
  ///
  /// In en, this message translates to:
  /// **'JOSÉ SANTOS VARGAS “EL TAMBOR VARGAS”'**
  String get na10Arte1T;

  /// No description provided for @na10Arte2T.
  ///
  /// In en, this message translates to:
  /// **'APIAGUAIKI TÜPA'**
  String get na10Arte2T;

  /// No description provided for @na10Arte3T.
  ///
  /// In en, this message translates to:
  /// **'EUSTAQUIO MÉNDEZ “EL MOTO MÉNDEZ”'**
  String get na10Arte3T;

  /// No description provided for @na10Arte4T.
  ///
  /// In en, this message translates to:
  /// **'CAVERNA DE UMAJALANTA, TOROTORO'**
  String get na10Arte4T;

  /// No description provided for @nr10Mire1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION CONTINUA'**
  String get nr10Mire1T;

  /// No description provided for @nr10Mire2T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get nr10Mire2T;

  /// No description provided for @nr10Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr10Toque1T;

  /// No description provided for @nr10Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr10Toque2T;

  /// No description provided for @nr10Toque3T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr10Toque3T;

  /// No description provided for @nr10Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN CON CAMBIO DE COLOR Y MOVIMIENTO'**
  String get nr10Incline1T;

  /// No description provided for @nr10Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA REVERSO'**
  String get nr10Mireuv1T;

  /// No description provided for @nr10Arte1T.
  ///
  /// In en, this message translates to:
  /// **'ISLA DEL PESCADO, SALAR DE UYUNI'**
  String get nr10Arte1T;

  /// No description provided for @nr10Arte2T.
  ///
  /// In en, this message translates to:
  /// **'PICAFLOR GIGANTE'**
  String get nr10Arte2T;

  /// No description provided for @nr10Arte3T.
  ///
  /// In en, this message translates to:
  /// **'PUYA RAIMONDI'**
  String get nr10Arte3T;

  /// No description provided for @na20Mire1.
  ///
  /// In en, this message translates to:
  /// **'Compuesta por tres elementos que vistos a contraluz reproducen:\n\ni) La imagen de Genoveva Ríos.\n\nii) Una bandera al lado del personaje formada por puntos.\n\niii) El número “20” en la parte inferior.'**
  String get na20Mire1;

  /// No description provided for @na20Mire2.
  ///
  /// In en, this message translates to:
  /// **'Pequeños y delgados hilos de color rojo, amarillo, verde y azul que se encuentran inmersos y distribuidos al azar en todo el billete.'**
  String get na20Mire2;

  /// No description provided for @na20Mire3.
  ///
  /// In en, this message translates to:
  /// **'Impresiones en ambos lados del billete, en la parte inferior izquierda del anverso y derecha del reverso, que vistas a contraluz completan exactamente el número “20” entre el color naranja y azul.'**
  String get na20Mire3;

  /// No description provided for @na20Toque1.
  ///
  /// In en, this message translates to:
  /// **'En la parte superior izquierda debajo del número “20”, al igual que en la familia anterior, aparecen tres barras en alto relieve.'**
  String get na20Toque1;

  /// No description provided for @na20Toque2.
  ///
  /// In en, this message translates to:
  /// **'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.'**
  String get na20Toque2;

  /// No description provided for @na20Toque3.
  ///
  /// In en, this message translates to:
  /// **'En los bordes izquierdo y derecho del anverso del billete se sienten al tacto 2 bloques de 6 líneas cortas diagonales en alto relieve.'**
  String get na20Toque3;

  /// No description provided for @na20Toque4.
  ///
  /// In en, this message translates to:
  /// **'Es una impresión con relieve que se siente al tacto y se encuentra en los personajes, textos y el número “20”.'**
  String get na20Toque4;

  /// No description provided for @na20Toque5.
  ///
  /// In en, this message translates to:
  /// **'Los billetes están impresos en un papel especial de 100% algodón, cuyo grosor, calidad y textura son fáciles de sentir al tacto.'**
  String get na20Toque5;

  /// No description provided for @na20Incline1.
  ///
  /// In en, this message translates to:
  /// **'Imagen del número “20”, ubicada sobre un cuadro naranja en la parte inferior derecha del anverso, visible al inclinarlo.\n\n\n'**
  String get na20Incline1;

  /// No description provided for @na20Incline2.
  ///
  /// In en, this message translates to:
  /// **'Está ubicado en el anverso del billete, tiene 4 milímetros de ancho, lleva la imagen de Genoveva Ríos y el número “20”. Al inclinarlo cambia de color de naranja a verde.\n\n\n'**
  String get na20Incline2;

  /// No description provided for @na20Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'En el anverso de los billetes se pueden observar los siguientes elementos:\n\ni)  El hilo de seguridad con fluorescencia roja, amarilla y verde.\n\nii) El Escudo del Estado Plurinacional de Bolivia, valor del corte, números de serie y firmas de las autoridades del BCB, con fluorescencia.\n\niii) Las fibrillas con fluorescencia roja, amarilla y azul'**
  String get na20Mireuv1;

  /// No description provided for @na20Arte1.
  ///
  /// In en, this message translates to:
  /// **'(Litoral, 1865 - s/f) .\n\nNiña que rescató la bandera boliviana que flameaba en la Intendencia de Policía de Antofagasta, resguardándola debajo de su ropa para evitar el ultraje del símbolo patrio por los invasores chilenos. En 1904 la bandera fue entregada al cónsul de Bolivia en Iquique y retornó al país 10 años después.'**
  String get na20Arte1;

  /// No description provided for @na20Arte2.
  ///
  /// In en, this message translates to:
  /// **'(Potosí, 1740-1781).\n\nLíder indígena potosino que denunció ante el Virrey del Río de la Plata, la extorsión económica y abusos de las autoridades coloniales. Su encarcelamiento motivó la rebelión de Pocoata (Chayanta, 1780). Una vez libre, como autoridad impartió justicia hasta que fue capturado y asesinado por los españoles. La sublevación continuó con su esposa y hermanos.'**
  String get na20Arte2;

  /// No description provided for @na20Arte3.
  ///
  /// In en, this message translates to:
  /// **'(Beni, s/f-1811).\n\nPrócer mojeño-trinitario que encabezó y motivó las rebeliones de los pueblos de la región en contra de la opresión de las instituciones coloniales. Sobrevivió a la masacre de Trinidad (1811), posteriormente fue apresado y asesinado. Este sacrificio   permitió instaurar un gobierno indígena hasta 1822.'**
  String get na20Arte3;

  /// No description provided for @na20Arte4.
  ///
  /// In en, this message translates to:
  /// **'Monumento arqueológico que fue un centro ceremonial, administrativo y habitacional precolombino, situado en Santa Cruz y declarado Patrimonio Cultural de la Humanidad por la UNESCO en 1998: “La gigantesca roca esculpida que domina la ciudad desde lo alto, es un testimonio único en su género de las tradiciones prehispánicas y no tiene comparación en toda América”.\n'**
  String get na20Arte4;

  /// No description provided for @nr20Mire1.
  ///
  /// In en, this message translates to:
  /// **'Consiste en formar exactamente el número “20” al unir los bordes izquierdo y derecho del reverso del billete.'**
  String get nr20Mire1;

  /// No description provided for @nr20Mire2.
  ///
  /// In en, this message translates to:
  /// **'Impresiones en ambos lados del billete, en la parte inferior derecha del reverso e izquierda del anverso, que vistas a contraluz completan exactamente el número “20” entre el color azul y naranja.'**
  String get nr20Mire2;

  /// No description provided for @nr20Toque1.
  ///
  /// In en, this message translates to:
  /// **'El número “20” y el texto “VEINTE BOLIVIANOS” están impresos en alto relieve.'**
  String get nr20Toque1;

  /// No description provided for @nr20Toque2.
  ///
  /// In en, this message translates to:
  /// **'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.'**
  String get nr20Toque2;

  /// No description provided for @nr20Toque3.
  ///
  /// In en, this message translates to:
  /// **'Las líneas horizontales en los bordes superior e inferior del billete están impresas en alto relieve.'**
  String get nr20Toque3;

  /// No description provided for @nr20Incline1.
  ///
  /// In en, this message translates to:
  /// **'En el reverso del billete está impreso, con tinta especial, un Caimán Negro. Al inclinarlo muestra un efecto con movimiento de izquierda a derecha y cambio de color de oro a verde.\n\n'**
  String get nr20Incline1;

  /// No description provided for @nr20Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'En el reverso de los billetes se pueden observar con luz ultravioleta:\n\ni)El Árbol Toborochi y el valor del corte con fluorescencia roja.\n\nii)Las fibrillas con fluorescencia roja, amarilla y azul.'**
  String get nr20Mireuv1;

  /// No description provided for @nr20Arte1.
  ///
  /// In en, this message translates to:
  /// **'Es uno de los principales atractivos turísticos de la Reserva Nacional de Vida Silvestre Amazónica Manuripi (Pando), conocido como el “acuario de Bolivia” por sus aguas cristalinas y la variedad de peces que pueden ser observados. Está rodeada de un exuberante paisaje de bosque que alberga gran biodiversidad en flora y fauna.'**
  String get nr20Arte1;

  /// No description provided for @nr20Arte2.
  ///
  /// In en, this message translates to:
  /// **'Es uno de los reptiles más grandes de la Amazonía y puede sobrepasar los 6 metros de largo. Tiene el dorso oscuro y vientre claro, conformación robusta y su cola le permite nadar en ríos y lagunas.\n\nSu caza está prohibida por ser una especie vulnerable (Libro Rojo de la Fauna Silvestre de Vertebrados de Bolivia).\n'**
  String get nr20Arte2;

  /// No description provided for @nr20Arte3.
  ///
  /// In en, this message translates to:
  /// **'Especie tradicional del oriente y sudeste del país, de gran altura (6 a 12 metros) que se caracteriza por tener un tronco abultado y con aguijones que almacena agua para la época seca. Florece en otoño y es popular por las leyendas religiosas y tradicionales de varios pueblos indígenas.'**
  String get nr20Arte3;

  /// No description provided for @na20Mire1T.
  ///
  /// In en, this message translates to:
  /// **'MARCA DE AGUA'**
  String get na20Mire1T;

  /// No description provided for @na20Mire2T.
  ///
  /// In en, this message translates to:
  /// **'FIBRILLAS'**
  String get na20Mire2T;

  /// No description provided for @na20Mire3T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get na20Mire3T;

  /// No description provided for @na20Toque1T.
  ///
  /// In en, this message translates to:
  /// **'BARRAS EN ALTO RELIEVE'**
  String get na20Toque1T;

  /// No description provided for @na20Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get na20Toque2T;

  /// No description provided for @na20Toque3T.
  ///
  /// In en, this message translates to:
  /// **'LINEAS EN ALTO RELIEVE'**
  String get na20Toque3T;

  /// No description provided for @na20Toque4T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get na20Toque4T;

  /// No description provided for @na20Toque5T.
  ///
  /// In en, this message translates to:
  /// **'CALIDAD DEL PAPEL'**
  String get na20Toque5T;

  /// No description provided for @na20Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN LATENTE'**
  String get na20Incline1T;

  /// No description provided for @na20Incline2T.
  ///
  /// In en, this message translates to:
  /// **'HILO DE SEGURIDAD'**
  String get na20Incline2T;

  /// No description provided for @na20Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA ANVERSO'**
  String get na20Mireuv1T;

  /// No description provided for @na20Arte1T.
  ///
  /// In en, this message translates to:
  /// **'GENOVEVA RÍOS'**
  String get na20Arte1T;

  /// No description provided for @na20Arte2T.
  ///
  /// In en, this message translates to:
  /// **'TOMÁS KATARI'**
  String get na20Arte2T;

  /// No description provided for @na20Arte3T.
  ///
  /// In en, this message translates to:
  /// **'PEDRO IGNACIO MUIBA'**
  String get na20Arte3T;

  /// No description provided for @na20Arte4T.
  ///
  /// In en, this message translates to:
  /// **'FUERTE DE SAMAYPATA'**
  String get na20Arte4T;

  /// No description provided for @nr20Mire1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION CONTINUA'**
  String get nr20Mire1T;

  /// No description provided for @nr20Mire2T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get nr20Mire2T;

  /// No description provided for @nr20Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr20Toque1T;

  /// No description provided for @nr20Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr20Toque2T;

  /// No description provided for @nr20Toque3T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr20Toque3T;

  /// No description provided for @nr20Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN CON CAMBIO DE COLOR Y MOVIMIENTO'**
  String get nr20Incline1T;

  /// No description provided for @nr20Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA REVERSO'**
  String get nr20Mireuv1T;

  /// No description provided for @nr20Arte1T.
  ///
  /// In en, this message translates to:
  /// **'LAGUNA BAY'**
  String get nr20Arte1T;

  /// No description provided for @nr20Arte2T.
  ///
  /// In en, this message translates to:
  /// **'CAIMÁN NEGRO'**
  String get nr20Arte2T;

  /// No description provided for @nr20Arte3T.
  ///
  /// In en, this message translates to:
  /// **'ÁRBOL TOBOROCHI'**
  String get nr20Arte3T;

  /// No description provided for @na50Mire1.
  ///
  /// In en, this message translates to:
  /// **'Compuesta por tres elementos que vistos a contraluz reproducen:\n\ni) La imagen de José Manuel Baca “Cañoto”.\n\nii) Una guitarra al lado del personaje formada por puntos.\n\niii) El número “50” en la parte inferior.'**
  String get na50Mire1;

  /// No description provided for @na50Mire2.
  ///
  /// In en, this message translates to:
  /// **'Pequeños y delgados hilos de color rojo, amarillo, verde y azul que se encuentran inmersos y distribuidos al azar en todo el billete.'**
  String get na50Mire2;

  /// No description provided for @na50Mire3.
  ///
  /// In en, this message translates to:
  /// **'Impresiones en ambos lados del billete, en la parte inferior izquierda del anverso y derecha del reverso, que vistas a contraluz completan exactamente el número “50” entre el color violeta y naranja.'**
  String get na50Mire3;

  /// No description provided for @na50Toque1.
  ///
  /// In en, this message translates to:
  /// **'En la parte superior izquierda debajo del número “50”, al igual que en la familia anterior, aparece una barra vertical en alto relieve.'**
  String get na50Toque1;

  /// No description provided for @na50Toque2.
  ///
  /// In en, this message translates to:
  /// **'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.'**
  String get na50Toque2;

  /// No description provided for @na50Toque3.
  ///
  /// In en, this message translates to:
  /// **'En los bordes izquierdo y derecho del anverso del billete se sienten al tacto tres bloques de cuatro líneas cortas diagonales en alto relieve.'**
  String get na50Toque3;

  /// No description provided for @na50Toque4.
  ///
  /// In en, this message translates to:
  /// **'Es una impresión con relieve que se siente al tacto y se encuentra en los personajes, textos y el número “50”.'**
  String get na50Toque4;

  /// No description provided for @na50Toque5.
  ///
  /// In en, this message translates to:
  /// **'Los billetes están impresos en un papel especial de 100% algodón, cuyo grosor, calidad y textura son fáciles de sentir al tacto.'**
  String get na50Toque5;

  /// No description provided for @na50Incline1.
  ///
  /// In en, this message translates to:
  /// **'Imagen del número “50”, ubicada sobre un cuadro violeta con espiral en la parte inferior derecha del anverso, visible al inclinarlo.\n\n\n'**
  String get na50Incline1;

  /// No description provided for @na50Incline2.
  ///
  /// In en, this message translates to:
  /// **'Está ubicado en el anverso del billete, tiene 4 milímetros de ancho, lleva la imagen de José Manuel Baca “Cañoto” y el número “50”. Al inclinarlo cambia de color de verde al azul.\n\n\n'**
  String get na50Incline2;

  /// No description provided for @na50Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'En el anverso de los billetes se pueden observar los siguientes elementos:\n\ni)  El hilo de seguridad con fluorescencia roja, amarilla y verde.\n\nii) El Escudo del Estado Plurinacional de Bolivia, valor del corte, números de serie y firmas de las autoridades del BCB, con fluorescencia.\n\niii) Las fibrillas con fluorescencia roja, amarilla y azul'**
  String get na50Mireuv1;

  /// No description provided for @na50Arte1.
  ///
  /// In en, this message translates to:
  /// **'(Santa Cruz, 1790-1854).\n\nGuerrillero, cantor y poeta que participó del primer levantamiento libertario en suelo cruceño y en las batallas de La Florida, Santa Bárbara y El Pari. Audaz e ingenioso, hostigaba constantemente a los realistas. Exiliado en las Provincias Unidas del Río de la Plata, fue capitán de la tropa de gauchos de Güemes y a su retorno, junto con otros patriotas, luchó hasta alcanzar la independencia.'**
  String get na50Arte1;

  /// No description provided for @na50Arte2.
  ///
  /// In en, this message translates to:
  /// **'(Ixiamas, actualmente norte de La Paz, s/f).\n\nHéroe indígena tacana, trabajador siringuero que formó parte de la Columna Porvenir en la Batalla de Bahía (1902), durante la Guerra del Acre. Con un grupo de flecheros atacó e incendió los depósitos de municiones del enemigo, acción  que detuvo el avance de grupos separatistas y consolidó la soberanía boliviana sobre lo que hoy es Pando.'**
  String get na50Arte2;

  /// No description provided for @na50Arte3.
  ///
  /// In en, this message translates to:
  /// **'(La Paz, s/f - 1905).\n\nLíder aymara que luchó contra los abusos hacia los indígenas y por la recuperación de las tierras comunales. Encabezó un ejército de indígenas originarios y fue un notable luchador social. Su proyecto político, con mayor participación indígena, fue visto como amenaza por la oligarquía que lo apresó y asesinó.\n'**
  String get na50Arte3;

  /// No description provided for @na50Arte4.
  ///
  /// In en, this message translates to:
  /// **'Monumento arqueológico ubicado en el municipio de Pocona, Cochabamba, construido por los incas. Tiene sectores defensivos, administrativos-públicos, ceremoniales, de resguardo, almacenaje y habitacionales. Entre sus construcciones en piedra y barro destaca la enorme Kallanka o galpón rectangular de una sola nave (2.020 m(sup)2(/sup)), única en América precolombina.\n'**
  String get na50Arte4;

  /// No description provided for @nr50Mire1.
  ///
  /// In en, this message translates to:
  /// **'Consiste en formar exactamente el número “50” al unir los bordes izquierdo y derecho del reverso del billete.'**
  String get nr50Mire1;

  /// No description provided for @nr50Mire2.
  ///
  /// In en, this message translates to:
  /// **'Impresiones en ambos lados del billete, en la parte inferior derecha del reverso e izquierda del anverso, que vistas a contraluz completan exactamente el número “50” entre el color violeta y naranja.'**
  String get nr50Mire2;

  /// No description provided for @nr50Toque1.
  ///
  /// In en, this message translates to:
  /// **'El número “50” y el texto “CINCUENTA BOLIVIANOS” están impresos en alto relieve.'**
  String get nr50Toque1;

  /// No description provided for @nr50Toque2.
  ///
  /// In en, this message translates to:
  /// **'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.'**
  String get nr50Toque2;

  /// No description provided for @nr50Toque3.
  ///
  /// In en, this message translates to:
  /// **'Las líneas horizontales en los bordes superior e inferior del billete están impresas en alto relieve.'**
  String get nr50Toque3;

  /// No description provided for @nr50Incline1.
  ///
  /// In en, this message translates to:
  /// **'En el reverso del billete está impreso, con tinta especial y aspecto de abanico, un Flamenco Andino. Al inclinarlo de arriba hacia abajo muestra un efecto de movimiento radial que cambia de color de oro a verde.\n\n'**
  String get nr50Incline1;

  /// No description provided for @nr50Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'En el reverso de los billetes se pueden observar con luz ultravioleta:\n\ni) La Quinua Real y el valor del corte con fluorescencia roja.\n\nii) Las fibrillas con fluorescencia roja, amarilla y azul.'**
  String get nr50Mireuv1;

  /// No description provided for @nr50Arte1.
  ///
  /// In en, this message translates to:
  /// **'Montaña más alta de Bolivia (6.542 m s.n.m.) que se encuentra en la Cordillera Occidental y es el principal atractivo del Parque Nacional Sajama, Oruro. \nTiene una forma cónica y simétrica de gran belleza paisajística. \nEn sus alrededores existen ecosistemas únicos como bofedales, tholares, bosques de Queñua y fauna en peligro de extinción como el Quirquincho, Puma, Suri, Gato Andino, entre otros.'**
  String get nr50Arte1;

  /// No description provided for @nr50Arte2.
  ///
  /// In en, this message translates to:
  /// **'Ave que habita en lagos y lagunas poco profundas del altiplano, con un plumaje de color predominantemente rosa. Tiene un pico con adaptaciones que le permiten alimentarse de microorganismos acuáticos. Es el flamenco más grande de Bolivia (105 cm de altura), muy vulnerable a predadores y recolectores de huevos, por lo que es una especie amenazada.\n'**
  String get nr50Arte2;

  /// No description provided for @nr50Arte3.
  ///
  /// In en, this message translates to:
  /// **'Planta milenaria con flores de varios colores, de interés mundial para la seguridad alimentaria, es cultivada en condiciones extremas de altura, temperatura, humedad y salinidad de los suelos de la región sur andina. Su grano, de hasta 2,5 milímetros, es reconocido internacionalmente por ser un alimento rico en proteínas de alto valor nutricional y su producción orgánica certificada.'**
  String get nr50Arte3;

  /// No description provided for @na50Mire1T.
  ///
  /// In en, this message translates to:
  /// **'MARCA DE AGUA'**
  String get na50Mire1T;

  /// No description provided for @na50Mire2T.
  ///
  /// In en, this message translates to:
  /// **'FIBRILLAS'**
  String get na50Mire2T;

  /// No description provided for @na50Mire3T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get na50Mire3T;

  /// No description provided for @na50Toque1T.
  ///
  /// In en, this message translates to:
  /// **'BARRAS EN ALTO RELIEVE'**
  String get na50Toque1T;

  /// No description provided for @na50Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get na50Toque2T;

  /// No description provided for @na50Toque3T.
  ///
  /// In en, this message translates to:
  /// **'LINEAS EN ALTO RELIEVE'**
  String get na50Toque3T;

  /// No description provided for @na50Toque4T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get na50Toque4T;

  /// No description provided for @na50Toque5T.
  ///
  /// In en, this message translates to:
  /// **'CALIDAD DEL PAPEL'**
  String get na50Toque5T;

  /// No description provided for @na50Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN LATENTE'**
  String get na50Incline1T;

  /// No description provided for @na50Incline2T.
  ///
  /// In en, this message translates to:
  /// **'HILO DE SEGURIDAD'**
  String get na50Incline2T;

  /// No description provided for @na50Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA ANVERSO'**
  String get na50Mireuv1T;

  /// No description provided for @na50Arte1T.
  ///
  /// In en, this message translates to:
  /// **'JOSÉ MANUEL BACA “CAÑOTO”'**
  String get na50Arte1T;

  /// No description provided for @na50Arte2T.
  ///
  /// In en, this message translates to:
  /// **'BRUNO RACUA'**
  String get na50Arte2T;

  /// No description provided for @na50Arte3T.
  ///
  /// In en, this message translates to:
  /// **'PABLO ZÁRATE WILLKA'**
  String get na50Arte3T;

  /// No description provided for @na50Arte4T.
  ///
  /// In en, this message translates to:
  /// **'FORTALEZA DE INKALLAJTA'**
  String get na50Arte4T;

  /// No description provided for @nr50Mire1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION CONTINUA'**
  String get nr50Mire1T;

  /// No description provided for @nr50Mire2T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get nr50Mire2T;

  /// No description provided for @nr50Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr50Toque1T;

  /// No description provided for @nr50Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr50Toque2T;

  /// No description provided for @nr50Toque3T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr50Toque3T;

  /// No description provided for @nr50Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN CON CAMBIO DE COLOR Y MOVIMIENTO'**
  String get nr50Incline1T;

  /// No description provided for @nr50Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA REVERSO'**
  String get nr50Mireuv1T;

  /// No description provided for @nr50Arte1T.
  ///
  /// In en, this message translates to:
  /// **'NEVADO SAJAMA'**
  String get nr50Arte1T;

  /// No description provided for @nr50Arte2T.
  ///
  /// In en, this message translates to:
  /// **'FLAMENCO ANDINO'**
  String get nr50Arte2T;

  /// No description provided for @nr50Arte3T.
  ///
  /// In en, this message translates to:
  /// **'QUINUA REAL'**
  String get nr50Arte3T;

  /// No description provided for @na100Mire1.
  ///
  /// In en, this message translates to:
  /// **'Compuesta por tres elementos que vistos a contraluz reproducen:\n\ni) La imagen de Juana Azurduy de Padilla.\n\nii) Un caballo al lado del personaje formado por puntos.\n\niii) El número “100” en la parte inferior.'**
  String get na100Mire1;

  /// No description provided for @na100Mire2.
  ///
  /// In en, this message translates to:
  /// **'Pequeños y delgados hilos de color rojo, amarillo, verde y azul que se encuentran inmersos y distribuidos al azar en todo el billete.'**
  String get na100Mire2;

  /// No description provided for @na100Mire3.
  ///
  /// In en, this message translates to:
  /// **'Impresiones en ambos lados del billete, en la parte inferior izquierda del anverso y derecha del reverso, que vistas a contraluz completan exactamente el número “100” entre el color rojo y azul.'**
  String get na100Mire3;

  /// No description provided for @na100Toque1.
  ///
  /// In en, this message translates to:
  /// **'En la parte superior izquierda debajo del número “100”, al igual que en la familia anterior, aparece dos barras verticales en alto relieve.'**
  String get na100Toque1;

  /// No description provided for @na100Toque2.
  ///
  /// In en, this message translates to:
  /// **'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.'**
  String get na100Toque2;

  /// No description provided for @na100Toque3.
  ///
  /// In en, this message translates to:
  /// **'En los bordes izquierdo y derecho del anverso del billete se sienten al tacto 4 bloques, cada uno de 3 líneas cortas diagonales en alto relieve.'**
  String get na100Toque3;

  /// No description provided for @na100Toque4.
  ///
  /// In en, this message translates to:
  /// **'Es una impresión con relieve que se siente al tacto y se encuentra en los personajes, textos y el número “100”.'**
  String get na100Toque4;

  /// No description provided for @na100Toque5.
  ///
  /// In en, this message translates to:
  /// **'Los billetes están impresos en un papel especial de 100% algodón, cuyo grosor, calidad y textura son fáciles de sentir al tacto.'**
  String get na100Toque5;

  /// No description provided for @na100Incline1.
  ///
  /// In en, this message translates to:
  /// **'Imagen del número “100”, ubicada sobre un cuadro rojo con arcos en la parte inferior derecha del anverso, visible al inclinarlo.\n\n\n'**
  String get na100Incline1;

  /// No description provided for @na100Incline2.
  ///
  /// In en, this message translates to:
  /// **'Está ubicado en el anverso del billete, tiene 4 milímetros de ancho, lleva la imagen de Juana Azurduy de Padilla y el número “100”. Al inclinarlo cambia de color de rojo a dorado.\n\n\n'**
  String get na100Incline2;

  /// No description provided for @na100Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'En el anverso de los billetes se pueden observar los siguientes elementos:\n\ni)  El hilo de seguridad con fluorescencia roja, amarilla y verde.\n\nii) El Escudo del Estado Plurinacional de Bolivia, valor del corte, números de serie y firmas de las autoridades del BCB, con fluorescencia.\n\niii) Las fibrillas con fluorescencia roja, amarilla y azul'**
  String get na100Mireuv1;

  /// No description provided for @na100Arte1.
  ///
  /// In en, this message translates to:
  /// **'(Chuquisaca, 1780 - 1862).\n\nMujer, madre y guerrillera valiente de América del Sur que en la lucha por la libertad perdió su tierra, a su esposo, Manuel Ascencio Padilla, y a cuatro de sus hijos. Organizó y lideró los batallones “Leales” y “Húsares” con indígenas y mestizos, apoyó la campaña de los ejércitos auxiliares argentinos y participó en las batallas de Tarvita, El Villar y La Laguna, entre otras.\n\nEn reconocimiento póstumo a su heroica lucha, el Ejército Argentino, del cual formó parte, le otorgó el grado de Generala (2009) y el Ejército Boliviano, de Mariscal (2011).'**
  String get na100Arte1;

  /// No description provided for @na100Arte2.
  ///
  /// In en, this message translates to:
  /// **'(Cochabamba,  1705 - 1731).\n\nArtesano platero que encabezó la primera y más importante rebelión mestiza frente a las autoridades coloniales, particularmente contra los abusos y el corrupto régimen tributario, en la Villa de Oropesa, hoy Cochabamba (1730).\n\nEn ese levantamiento derrotó a las fuerzas realistas en la colina de San Sebastián, para instaurar un gobierno de criollos y conservar sus derechos. Fue detenido, torturado y ejecutado.'**
  String get na100Arte2;

  /// No description provided for @na100Arte3.
  ///
  /// In en, this message translates to:
  /// **'(Cumaná - Venezuela, 1795-1830).\n\nEstratega militar, político y prócer de la independencia sudamericana que venció a los españoles en las batallas de Pichincha (1822) y Ayacucho (1824), logrando la libertad de varios países.\n\nFue el segundo Presidente de Bolivia que adoptó medidas administrativas para la organización del Estado. Puso en vigencia la primera Constitución del país y reivindicó los derechos de los indígenas con reformas de impacto social.\n'**
  String get na100Arte3;

  /// No description provided for @na100Arte4.
  ///
  /// In en, this message translates to:
  /// **'Construida en Potosí entre 1759 y 1773, es la mayor obra de arquitectura civil colonial en el territorio boliviano.\n\nPreserva y exhibe tecnologías de acuñación de monedas de distintas épocas; y una valiosa colección de numismática propia que incluye piezas que circularon en todo el mundo. Se constituye en uno de los repositorios históricos más importantes de la región.\n'**
  String get na100Arte4;

  /// No description provided for @nr100Mire1.
  ///
  /// In en, this message translates to:
  /// **'Consiste en formar exactamente el número “100” al unir los bordes izquierdo y derecho del reverso del billete.'**
  String get nr100Mire1;

  /// No description provided for @nr100Mire2.
  ///
  /// In en, this message translates to:
  /// **'Impresiones en ambos lados del billete, en la parte inferior derecha del reverso e izquierda del anverso, que vistas a contraluz completan exactamente el número “100” entre el color violeta y naranja.'**
  String get nr100Mire2;

  /// No description provided for @nr100Toque1.
  ///
  /// In en, this message translates to:
  /// **'El número “100” y el texto “CIEN BOLIVIANOS” están impresos en alto relieve.'**
  String get nr100Toque1;

  /// No description provided for @nr100Toque2.
  ///
  /// In en, this message translates to:
  /// **'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.'**
  String get nr100Toque2;

  /// No description provided for @nr100Toque3.
  ///
  /// In en, this message translates to:
  /// **'Las líneas horizontales en los bordes superior e inferior del billete están impresas en alto relieve.'**
  String get nr100Toque3;

  /// No description provided for @nr100Incline1.
  ///
  /// In en, this message translates to:
  /// **'En el reverso del billete está impresa con tinta especial una Paraba Azul. Al inclinar el billete de izquierda a derecha o de arriba hacia abajo, muestra círculos que se mueven y cambian de color, del verde al azul.\n\n'**
  String get nr100Incline1;

  /// No description provided for @nr100Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'En el reverso de los billetes se pueden observar con luz ultravioleta:\n\ni) La Flor Patujú y el valor del corte con fluorescencia roja.\n\nii) Las fibrillas con fluorescencia roja, amarilla y azul.'**
  String get nr100Mireuv1;

  /// No description provided for @nr100Arte1.
  ///
  /// In en, this message translates to:
  /// **'Es uno de los principales atractivos turísticos del Parque Nacional Noel Kempff Mercado, ubicado en Santa Cruz, declarado Patrimonio Natural de la Humanidad por la UNESCO (2002).\n\nEstas cataratas constituyen un salto ininterrumpido de agua del río Paucerna, que se destacan por su gran altura (88 metros).'**
  String get nr100Arte1;

  /// No description provided for @nr100Arte2.
  ///
  /// In en, this message translates to:
  /// **'Paraba del oriente boliviano que se caracteriza por su gran tamaño (100 cm), plumaje azul, anillos oculares y mandíbula inferior amarillos, además de su pico fuerte de color negro.\n\nEl tráfico ilegal y la pérdida de su hábitat la ubican en la categoría de especie vulnerable a nivel internacional.\n'**
  String get nr100Arte2;

  /// No description provided for @nr100Arte3.
  ///
  /// In en, this message translates to:
  /// **'Es un símbolo patrio cuyos pétalos en forma de espadines, matizados con los colores de la bandera de Bolivia, encarna la identidad del país.\n\nEsta flor, originaria de los llanos orientales, entrelazada con la Kantuta, representan la unión e interculturalidad de las regiones del Estado Plurinacional.\n'**
  String get nr100Arte3;

  /// No description provided for @na100Mire1T.
  ///
  /// In en, this message translates to:
  /// **'MARCA DE AGUA'**
  String get na100Mire1T;

  /// No description provided for @na100Mire2T.
  ///
  /// In en, this message translates to:
  /// **'FIBRILLAS'**
  String get na100Mire2T;

  /// No description provided for @na100Mire3T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get na100Mire3T;

  /// No description provided for @na100Toque1T.
  ///
  /// In en, this message translates to:
  /// **'BARRAS EN ALTO RELIEVE'**
  String get na100Toque1T;

  /// No description provided for @na100Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get na100Toque2T;

  /// No description provided for @na100Toque3T.
  ///
  /// In en, this message translates to:
  /// **'LINEAS EN ALTO RELIEVE'**
  String get na100Toque3T;

  /// No description provided for @na100Toque4T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get na100Toque4T;

  /// No description provided for @na100Toque5T.
  ///
  /// In en, this message translates to:
  /// **'CALIDAD DEL PAPEL'**
  String get na100Toque5T;

  /// No description provided for @na100Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN LATENTE'**
  String get na100Incline1T;

  /// No description provided for @na100Incline2T.
  ///
  /// In en, this message translates to:
  /// **'HILO DE SEGURIDAD'**
  String get na100Incline2T;

  /// No description provided for @na100Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA ANVERSO'**
  String get na100Mireuv1T;

  /// No description provided for @na100Arte1T.
  ///
  /// In en, this message translates to:
  /// **'JUANA AZURDUY DE PADILLA'**
  String get na100Arte1T;

  /// No description provided for @na100Arte2T.
  ///
  /// In en, this message translates to:
  /// **'ALEJO CALATAYUD'**
  String get na100Arte2T;

  /// No description provided for @na100Arte3T.
  ///
  /// In en, this message translates to:
  /// **'ANTONIO JOSÉ DE SUCRE'**
  String get na100Arte3T;

  /// No description provided for @na100Arte4T.
  ///
  /// In en, this message translates to:
  /// **'CASA DE LA MONEDA'**
  String get na100Arte4T;

  /// No description provided for @nr100Mire1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION CONTINUA'**
  String get nr100Mire1T;

  /// No description provided for @nr100Mire2T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get nr100Mire2T;

  /// No description provided for @nr100Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr100Toque1T;

  /// No description provided for @nr100Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr100Toque2T;

  /// No description provided for @nr100Toque3T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr100Toque3T;

  /// No description provided for @nr100Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN CON CAMBIO DE COLOR Y MOVIMIENTO'**
  String get nr100Incline1T;

  /// No description provided for @nr100Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA REVERSO'**
  String get nr100Mireuv1T;

  /// No description provided for @nr100Arte1T.
  ///
  /// In en, this message translates to:
  /// **'CATARATAS ARCO IRIS'**
  String get nr100Arte1T;

  /// No description provided for @nr100Arte2T.
  ///
  /// In en, this message translates to:
  /// **'PARABA AZUL'**
  String get nr100Arte2T;

  /// No description provided for @nr100Arte3T.
  ///
  /// In en, this message translates to:
  /// **'FLOR PATUJÚ'**
  String get nr100Arte3T;

  /// No description provided for @na200Mire1.
  ///
  /// In en, this message translates to:
  /// **'Compuesta por tres elementos que vistos a contraluz reproducen:\n\ni) La imagen de Tupak Katari.\n\nii) Un pututu (cuerno de toro) al lado del personaje formado por puntos.\n\niii) El número “200” en la parte inferior.'**
  String get na200Mire1;

  /// No description provided for @na200Mire2.
  ///
  /// In en, this message translates to:
  /// **'Pequeños y delgados hilos de color rojo, amarillo, verde y azul que se encuentran inmersos y distribuidos al azar en todo el billete.'**
  String get na200Mire2;

  /// No description provided for @na200Mire3.
  ///
  /// In en, this message translates to:
  /// **'Impresiones en ambos lados del billete, en la parte inferior izquierda del anverso y derecha del reverso, que vistas a contraluz completan exactamente el número “200” entre el color café y verde.\n'**
  String get na200Mire3;

  /// No description provided for @na200Toque1.
  ///
  /// In en, this message translates to:
  /// **'En la parte superior izquierda debajo del número “200”, al igual que en la familia anterior, aparece tres barras verticales en alto relieve.'**
  String get na200Toque1;

  /// No description provided for @na200Toque2.
  ///
  /// In en, this message translates to:
  /// **'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.'**
  String get na200Toque2;

  /// No description provided for @na200Toque3.
  ///
  /// In en, this message translates to:
  /// **'En los bordes izquierdo y derecho del anverso del billete se sienten al tacto 5 bloques, cada uno de 2 líneas cortas diagonales en alto relieve.'**
  String get na200Toque3;

  /// No description provided for @na200Toque4.
  ///
  /// In en, this message translates to:
  /// **'Es una impresión con relieve que se siente al tacto y se encuentra en los personajes, textos y los números “200”.'**
  String get na200Toque4;

  /// No description provided for @na200Toque5.
  ///
  /// In en, this message translates to:
  /// **'Los billetes están impresos en un papel especial de 100% algodón, cuyo grosor, calidad y textura son fáciles de sentir al tacto.'**
  String get na200Toque5;

  /// No description provided for @na200Incline1.
  ///
  /// In en, this message translates to:
  /// **'Imagen del número “200”, sobre un cuadro café que incluye una estrella. Está ubicada en la parte inferior derecha del anverso, es visible al inclinar el billete.\n\n\n'**
  String get na200Incline1;

  /// No description provided for @na200Incline2.
  ///
  /// In en, this message translates to:
  /// **'Ubicado en el anverso del billete, tiene 3 milímetros de ancho, muestra el número \'200\' dentro de un rombo que se intercala con otros de menor tamaño. Al inclinar el billete de arriba hacia abajo, los bordes de los rombos se mueven de adentro hacia afuera.\n\n\n'**
  String get na200Incline2;

  /// No description provided for @na200Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'En el anverso de los billetes se pueden observar los siguientes elementos:\n\ni)  El hilo de seguridad con fluorescencia amarilla.\n\nii) El Escudo del Estado Plurinacional de Bolivia, valor del corte, números de serie y firmas de las autoridades del BCB, con fluorescencia.\n\niii) Las fibrillas con fluorescencia roja, amarilla y azul'**
  String get na200Mireuv1;

  /// No description provided for @na200Arte1.
  ///
  /// In en, this message translates to:
  /// **'(Julián Apaza, La Paz, 1750 - 1781).\n\nLíder de la lucha descolonizadora, que combatió junto a su esposa, Bartolina Sisa, y sus hermanos, Gregoria y Martín Apaza, en contra del dominio y opresión español.\n\nAliado de Túpac Amaru (José Gabriel Condorcanqui) en la gran rebelión indígena (1780 – 1782), logró cercar la ciudad de La Paz en dos oportunidades, extender su insurrección al Altiplano y Yungas e incorporar a sus filas al pueblo afro.\n\nFue traicionado, apresado y sentenciado a morir descuartizado por cuatro caballos en la plaza del Santuario de Peñas. Declarado en 2005 “Héroe Nacional Aymara”.\n'**
  String get na200Arte1;

  /// No description provided for @na200Arte2.
  ///
  /// In en, this message translates to:
  /// **'(La Paz,  1750 - 1782).\n\nLuchadora aymara que protagonizó junto a su esposo, Julián Apaza (Tupak Katari), la gran rebelión indígena (1780 -1782). Se consideran defensores de las 36 naciones indígenas-originarias de Bolivia.\n\nDirigió a sus tropas en varias batallas, incluso en ausencia del gran líder durante el Primer Cerco a La Paz, y organizó la logística para el abastecimiento de los campamentos insurgentes.\n\nFue traicionada y encarcelada por más de un año. Enfrentó un juicio donde dignamente reivindicó la justicia de la causa indígena, hasta que fue sentenciada a muerte. Declarada “Heroína Nacional Aymara” en 2005.\n'**
  String get na200Arte2;

  /// No description provided for @na200Arte3.
  ///
  /// In en, this message translates to:
  /// **'(Caracas - Venezuela, 1783-1830).\n\nLibertador de América que al mando de sus gloriosas tropas enfrentó al ejército español en cerca de 500 batallas y logró la independencia de Venezuela, Colombia, Ecuador, Perú y Bolivia.\n\nFue el fundador y primer Presidente de Bolivia. Organizó el país que inicialmente llevaba su nombre, adoptó medidas a favor de los indígenas, redimiéndolos de la esclavitud y explotación; les dotó de tierras, suprimió los tributos y la mita.\n\nEscribió y remitió la primera Constitución para su aprobación en 1826.\n\nTrasciende en la historia por su visión de conformar la Patria Grande y la lucha antiimperialista.\n'**
  String get na200Arte3;

  /// No description provided for @na200Arte4.
  ///
  /// In en, this message translates to:
  /// **'(Sucre – Bolivia)\n\nPrimer Monumento Nacional donde se reunió la Asamblea Deliberante que declaró la independencia de Bolivia y se aprobó la primera Constitución Política del país.\n\nFue sede de la Universidad Mayor, Real y Pontificia de San Francisco Xavier (1624), una de las más importantes de la época, que formó a los protagonistas de la lucha  libertaria.\n\nEs un importante repositorio nacional que preserva invalorables bienes históricos y culturales de la época colonial y republicana.\n'**
  String get na200Arte4;

  /// No description provided for @nr200Mire1.
  ///
  /// In en, this message translates to:
  /// **'Consiste en formar exactamente el número “200” al unir los bordes izquierdo y derecho del reverso del billete.'**
  String get nr200Mire1;

  /// No description provided for @nr200Mire2.
  ///
  /// In en, this message translates to:
  /// **'Impresiones en ambos lados del billete, en la parte inferior derecha del reverso e izquierda del anverso, que vistas a contraluz completan exactamente el número “200” entre el color café y verde.'**
  String get nr200Mire2;

  /// No description provided for @nr200Toque1.
  ///
  /// In en, this message translates to:
  /// **'El número “200” y el texto “DOSCIENTOS BOLIVIANOS” están impresos en alto relieve.'**
  String get nr200Toque1;

  /// No description provided for @nr200Toque2.
  ///
  /// In en, this message translates to:
  /// **'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.'**
  String get nr200Toque2;

  /// No description provided for @nr200Toque3.
  ///
  /// In en, this message translates to:
  /// **'Las líneas horizontales en los bordes superior e inferior del billete están impresas en alto relieve.'**
  String get nr200Toque3;

  /// No description provided for @nr200Incline1.
  ///
  /// In en, this message translates to:
  /// **'En el reverso del billete está impreso con tinta especial una Gato Andino. Al inclinar el billete de arriba hacia abajo, muestra un efecto de movimiento con cambio de color de azul a verde en el cuerpo del felino.\n\n'**
  String get nr200Incline1;

  /// No description provided for @nr200Mireuv1.
  ///
  /// In en, this message translates to:
  /// **'En el reverso de los billetes se pueden observar con luz ultravioleta:\n\ni) La Kantuta y el valor del corte con fluorescencia roja.\n\nii) Las fibrillas con fluorescencia roja, amarilla y azul.'**
  String get nr200Mireuv1;

  /// No description provided for @nr200Arte1.
  ///
  /// In en, this message translates to:
  /// **'Centro espiritual y político de la cultura de Tiwanaku, Patrimonio Cultural de la Humanidad (UNESCO - 2000) por su Valor Universal Excepcional expresado en la concepción y maestría constructiva de templos y esculturas monolíticas.\n\nEs el sitio arqueológico más importante del país, que comprende la Pirámide de Akapana, el Templete Semisubterráneo, el Templo de Kalasasaya, la Puerta del Sol, más de 200 estructuras habitacionales enterradas, canales, caminos y otros.\n\nTiwanaku testimonia la existencia y esplendor de una civilización prehispánica única y tecnológicamente avanzada.\n'**
  String get nr200Arte1;

  /// No description provided for @nr200Arte2.
  ///
  /// In en, this message translates to:
  /// **'Felino de la región alto andina que se caracteriza por su tamaño mediano y pelaje gris con manchas café rojizas-amarillentas. Su cola gruesa y larga representa más del 65% de su cuerpo.\n\nTradicionalmente es considerado símbolo de fertilidad, protección y está estrechamente ligado a los espíritus de las montañas.\n\nLa afectación negativa a su hábitat y su caza furtiva lo convierten en uno de los gatos en Peligro Crítico.\n'**
  String get nr200Arte2;

  /// No description provided for @nr200Arte3.
  ///
  /// In en, this message translates to:
  /// **'Símbolo patrio cuya flor, con forma acampanada, lleva los colores de la bandera tricolor y simboliza la identidad boliviana.\n\nEra considerada sagrada por los Incas y es originaria de la región occidental del país.\n\nEntrelazada a la Flor Patujú, representan la unión e interculturalidad de las regiones del Estado Plurinacional.\n'**
  String get nr200Arte3;

  /// No description provided for @na200Mire1T.
  ///
  /// In en, this message translates to:
  /// **'MARCA DE AGUA'**
  String get na200Mire1T;

  /// No description provided for @na200Mire2T.
  ///
  /// In en, this message translates to:
  /// **'FIBRILLAS'**
  String get na200Mire2T;

  /// No description provided for @na200Mire3T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get na200Mire3T;

  /// No description provided for @na200Toque1T.
  ///
  /// In en, this message translates to:
  /// **'BARRAS EN ALTO RELIEVE'**
  String get na200Toque1T;

  /// No description provided for @na200Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get na200Toque2T;

  /// No description provided for @na200Toque3T.
  ///
  /// In en, this message translates to:
  /// **'LINEAS EN ALTO RELIEVE'**
  String get na200Toque3T;

  /// No description provided for @na200Toque4T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get na200Toque4T;

  /// No description provided for @na200Toque5T.
  ///
  /// In en, this message translates to:
  /// **'CALIDAD DEL PAPEL'**
  String get na200Toque5T;

  /// No description provided for @na200Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN LATENTE'**
  String get na200Incline1T;

  /// No description provided for @na200Incline2T.
  ///
  /// In en, this message translates to:
  /// **'HILO DE SEGURIDAD DINAMICO'**
  String get na200Incline2T;

  /// No description provided for @na200Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA ANVERSO'**
  String get na200Mireuv1T;

  /// No description provided for @na200Arte1T.
  ///
  /// In en, this message translates to:
  /// **'TUPAK KATARI'**
  String get na200Arte1T;

  /// No description provided for @na200Arte2T.
  ///
  /// In en, this message translates to:
  /// **'BARTOLINA SISA'**
  String get na200Arte2T;

  /// No description provided for @na200Arte3T.
  ///
  /// In en, this message translates to:
  /// **'SIMÓN BOLÍVAR'**
  String get na200Arte3T;

  /// No description provided for @na200Arte4T.
  ///
  /// In en, this message translates to:
  /// **'CASA DE LA LIBERTAD'**
  String get na200Arte4T;

  /// No description provided for @nr200Mire1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION CONTINUA'**
  String get nr200Mire1T;

  /// No description provided for @nr200Mire2T.
  ///
  /// In en, this message translates to:
  /// **'MOTIVO COINCIDENTE'**
  String get nr200Mire2T;

  /// No description provided for @nr200Toque1T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr200Toque1T;

  /// No description provided for @nr200Toque2T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr200Toque2T;

  /// No description provided for @nr200Toque3T.
  ///
  /// In en, this message translates to:
  /// **'IMPRESION EN ALTO RELIEVE'**
  String get nr200Toque3T;

  /// No description provided for @nr200Incline1T.
  ///
  /// In en, this message translates to:
  /// **'IMAGEN CON CAMBIO DE COLOR Y MOVIMIENTO'**
  String get nr200Incline1T;

  /// No description provided for @nr200Mireuv1T.
  ///
  /// In en, this message translates to:
  /// **'FLUORESCENCIA REVERSO'**
  String get nr200Mireuv1T;

  /// No description provided for @nr200Arte1T.
  ///
  /// In en, this message translates to:
  /// **'TIWANAKU'**
  String get nr200Arte1T;

  /// No description provided for @nr200Arte2T.
  ///
  /// In en, this message translates to:
  /// **'GATO ANDINO “TITI”'**
  String get nr200Arte2T;

  /// No description provided for @nr200Arte3T.
  ///
  /// In en, this message translates to:
  /// **'KANTUTA'**
  String get nr200Arte3T;

  /// No description provided for @toque.
  ///
  /// In en, this message translates to:
  /// **'Toque'**
  String get toque;

  /// No description provided for @mire.
  ///
  /// In en, this message translates to:
  /// **'Mire'**
  String get mire;

  /// No description provided for @detalleArtistico.
  ///
  /// In en, this message translates to:
  /// **'Detalle artístico'**
  String get detalleArtistico;

  /// No description provided for @incline.
  ///
  /// In en, this message translates to:
  /// **'Incline'**
  String get incline;

  /// No description provided for @mireUV.
  ///
  /// In en, this message translates to:
  /// **'Mire ultravioleta'**
  String get mireUV;

  /// No description provided for @billetes.
  ///
  /// In en, this message translates to:
  /// **'Billetes'**
  String get billetes;

  /// No description provided for @lupa.
  ///
  /// In en, this message translates to:
  /// **'Lupa'**
  String get lupa;

  /// No description provided for @facebook.
  ///
  /// In en, this message translates to:
  /// **'Facebook'**
  String get facebook;

  /// No description provided for @twitter.
  ///
  /// In en, this message translates to:
  /// **'Twitter'**
  String get twitter;

  /// No description provided for @informacion.
  ///
  /// In en, this message translates to:
  /// **'Información'**
  String get informacion;

  /// No description provided for @cargando.
  ///
  /// In en, this message translates to:
  /// **'Cargando...'**
  String get cargando;

  /// No description provided for @instagram.
  ///
  /// In en, this message translates to:
  /// **'Instagram'**
  String get instagram;

  /// No description provided for @youTube.
  ///
  /// In en, this message translates to:
  /// **'YouTube'**
  String get youTube;

  /// No description provided for @tikTok.
  ///
  /// In en, this message translates to:
  /// **'TikTok'**
  String get tikTok;

  /// No description provided for @linkedIn.
  ///
  /// In en, this message translates to:
  /// **'LinkedIn'**
  String get linkedIn;

  /// No description provided for @redesociales.
  ///
  /// In en, this message translates to:
  /// **'Redes sociales'**
  String get redesociales;

  /// No description provided for @bancoCentralBolivia.
  ///
  /// In en, this message translates to:
  /// **'Banco Central de Bolivia'**
  String get bancoCentralBolivia;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['en', 'es'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en': return AppLocalizationsEn();
    case 'es': return AppLocalizationsEs();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
