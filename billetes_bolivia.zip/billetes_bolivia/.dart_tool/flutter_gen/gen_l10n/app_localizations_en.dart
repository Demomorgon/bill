


import 'app_localizations.dart';

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get app_name => 'Billetes de Bolivia';

  @override
  String get titulo => 'Nuevo Billete de Bs10';

  @override
  String get subtituloinfo => 'Primera Familia de Billetes del Estado Plurinacional de Bolivia (PFB-EPB)';

  @override
  String get subtitulosplash => 'Primera Familia de Billetes del Estado Plurinacional de Bolivia';

  @override
  String get titulon1 => 'Primera Familia de Billetes del Estado Plurinacional de Bolivia';

  @override
  String get titulon200 => 'Nuevo Billete de Bs200';

  @override
  String get titulon100 => 'Nuevo Billete de Bs100';

  @override
  String get titulon50 => 'Nuevo Billete de Bs50';

  @override
  String get titulon20 => 'Nuevo Billete de Bs20';

  @override
  String get titulon10 => 'Nuevo Billete de Bs10';

  @override
  String get tituloa1 => 'Familia Anterior de Billetes';

  @override
  String get tituloa200 => 'Bs200';

  @override
  String get tituloa100 => 'Bs100';

  @override
  String get tituloa50 => 'Bs50';

  @override
  String get tituloa20 => 'Bs20';

  @override
  String get tituloa10 => 'Bs10';

  @override
  String get web => 'www.bcb.gob.bo';

  @override
  String get version => 'Versión';

  @override
  String get email => 'primerafamiliabilletes@bcb.gob.bo';

  @override
  String get navigation_drawer_open => 'Abierto';

  @override
  String get navigation_drawer_close => 'Cerrado';

  @override
  String get menuTitulo1 => 'Billetes';

  @override
  String get menuTitulo11 => '1ra Familia de Billetes del EPB';

  @override
  String get menuTitulo111 => 'Bs10';

  @override
  String get menuTitulo112 => 'Bs20';

  @override
  String get menuTitulo113 => 'Bs50';

  @override
  String get menuTitulo114 => 'Bs100';

  @override
  String get menuTitulo115 => 'Bs200';

  @override
  String get menuTitulo12 => 'Familia Anterior';

  @override
  String get menuTitulo121 => 'Bs200';

  @override
  String get menuTitulo122 => 'Bs100';

  @override
  String get menuTitulo123 => 'Bs50';

  @override
  String get menuTitulo124 => 'Bs20';

  @override
  String get menuTitulo125 => 'Bs10';

  @override
  String get menuTitulo3 => 'Herramientas';

  @override
  String get menuTitulo31 => 'Luz Ultravioleta';

  @override
  String get menuTitulo32 => 'Lupa';

  @override
  String get menuTitulo2 => 'Enlaces';

  @override
  String get menuTitulo21 => 'Facebook';

  @override
  String get menuTitulo23 => 'Twitter';

  @override
  String get menuTitulo22 => 'www.bcb.gob.bo';

  @override
  String get menuTitulo4 => 'Ayuda';

  @override
  String get menuTitulo41 => 'Información';

  @override
  String get optionImage1 => 'Mire';

  @override
  String get optionImage2 => 'Toque';

  @override
  String get optionImage3 => 'Incline';

  @override
  String get optionImage4 => 'Mire Ultravioleta';

  @override
  String get optionImage5 => 'Detalles Artísticos';

  @override
  String get a10Mire1 => 'La marca de agua incluye tres elementos: la imagen del personaje histórico (Cecilio Guzman de Rojas), el cuadro de puntos ubicados al lado del personaje histórico y el valor del billete escrito en sentido vertical.';

  @override
  String get a10Mire2 => 'Figura geométrica impresa en el anverso y reverso del billete, que vista a contraluz encaja exactamente.';

  @override
  String get a10Mire3 => 'Pequeños hilos de color amarillo, rojo, verde y azul, que se encuentran en ambos lados del billete.';

  @override
  String get a10Toque1 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. El corte de Bs10 lleva dos barras en alto relieve en posición horizontal.';

  @override
  String get a10Toque2 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de Cecilio Guzman de Rojas está impresa en alto relieve.';

  @override
  String get a10Incline1 => 'Ubicada en el anverso del billete, al inclinarse se observa la sigla BCB.\n';

  @override
  String get a10Mireuv1 => 'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el anverso del billete:\n\ni)  Escudo del Estado Plurinacional de Bolivia.\n\nii) Valor del corte del billete.\n\niii) Firmas y números de serie.\n\niv) Figuras geométricas propias del corte.\n\nv)  Fibrillas de seguridad.\n\n';

  @override
  String get a10Arte1 => 'Destacado pintor Potosino nació en 1899 y falleció en 1950. Es considerado iniciador de una corriente pictórica de marcada inclinación indigenista. Sus pinturas valoran de sobremanera las raíces de Bolivia, por ello pinta rostros y escenas aymaras en paisajes altiplánicos. También sobresalió por su tenaz tarea en defensa del patrimonio artístico boliviano, la catalogación y la restauración de obras de arte.';

  @override
  String get r10Toque1 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de las Heroínas de la Coronilla y el paisaje de Cochabamba está impresa en alto relieve.';

  @override
  String get r10Mireuv1 => 'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el reverso del billete:\n\ni) Fibrillas de seguridad.';

  @override
  String get r10Arte1 => 'Se aprecia un paisaje de la ciudad de Cochabamba con el monumento de las Heroínas de la Coronilla en el frente que fue Declarado declarado Monumento Nacional en 1926; se encuentra en la Colina de San Sebastián de la ciudad de Cochabamba.';

  @override
  String get a10Mire1T => 'MARCA DE AGUA';

  @override
  String get a10Mire2T => 'MOTIVO COINCIDENTE';

  @override
  String get a10Mire3T => 'FIBRILLAS';

  @override
  String get a10Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get a10Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get a10Incline1T => 'IMAGEN LATENTE';

  @override
  String get a10Mireuv1T => 'FLUORESCENCIA ANVERSO';

  @override
  String get a10Arte1T => 'CECILIO GUZMAN DE ROJAS';

  @override
  String get r10Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get r10Mireuv1T => 'FLUORESCENCIA REVERSO';

  @override
  String get r10Arte1T => 'HEROINAS DE LA CORONILLA';

  @override
  String get a20Mire1 => 'Pequeños hilos de color amarillo, rojo, verde y azul, que se encuentran en ambos lados del billete.';

  @override
  String get a20Mire2 => 'La marca de agua incluye tres elementos: la imagen del personaje histórico (Pantaleón Dalence), el cuadro de puntos ubicados al lado del personaje histórico y el valor del billete escrito en sentido vertical.';

  @override
  String get a20Mire3 => 'Figura geométrica impresa en el anverso y reverso del billete, que vista a contraluz encaja exactamente.';

  @override
  String get a20Toque1 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. El corte de Bs20 lleva tres barras en alto relieve en posición horizontal.';

  @override
  String get a20Toque2 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de Pantaleón Dalence está impresa en alto relieve.';

  @override
  String get a20Incline1 => 'Ubicada en el anverso del billete, al inclinarse se observa la sigla BCB.\n';

  @override
  String get a20Incline2 => 'El hilo de seguridad es de 3 milímetros de ancho y sobresale nítidamente en el anverso del billete, lleva la sigla BCB y el valor del billete; tiene un efecto de cambio de color  de verde a magenta que se observa  al inclinarlo.';

  @override
  String get a20Mireuv1 => 'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el anverso del billete:\n\ni)  Escudo del Estado Plurinacional de Bolivia.\n\nii) Valor del corte del billete.\n\niii) Firmas y números de serie.\n\niv) Figuras geométricas propias del corte.\n\nv)  Fibrillas de seguridad.\n\nvi) Hilo de seguridad.\n\nvii) Motivo coincidente.';

  @override
  String get a20Arte1 => 'El billete de 20 bolivianos muestra, en el anverso la efigie del abogado Don Pantaleón Dalence (1815 – 1892), es considerado “padre de la justicia boliviana” por su constante lucha contra la corrupción, fue profesor de matemáticas, Munícipe, Prefecto, Oficial Mayor de Instrucción Pública, Fiscal General de la República y Ministro de Hacienda, su mayor contribución al derecho boliviano fue haber delimitado las atribuciones de los tres poderes del Estado y haber sido un “guardián celoso” de la Constitución.';

  @override
  String get r20Toque1 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de la Casa Dorada Tarija está impresa en alto relieve.';

  @override
  String get r20Mireuv1 => 'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el reverso del billete:\n\ni)  Hilo de seguridad.\n\nii) Fibrillas de seguridad.\n';

  @override
  String get r20Arte1 => 'La Casa Dorada de Tarija, hogar del magnate Moisés Navajas, hoy convertida en la Casa de la Cultura de esa capital y que constituye una de las más bellas muestras arquitectónicas de Bolivia, fue diseñada por el arquitecto Antonio Camponovo.';

  @override
  String get a20Mire2T => 'MARCA DE AGUA';

  @override
  String get a20Mire3T => 'MOTIVO COINCIDENTE';

  @override
  String get a20Mire1T => 'FIBRILLAS';

  @override
  String get a20Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get a20Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get a20Incline1T => 'IMAGEN LATENTE';

  @override
  String get a20Incline2T => 'HILO DE SEGURIDAD';

  @override
  String get a20Mireuv1T => 'FLUORESCENCIA ANVERSO';

  @override
  String get a20Arte1T => 'PANTALEON DALENCE';

  @override
  String get r20Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get r20Mireuv1T => 'FLUORESCENCIA REVERSO';

  @override
  String get r20Arte1T => 'CASA DORADA TARIJA';

  @override
  String get a50Mire1 => 'Pequeños hilos de color amarillo, rojo, verde y azul, que se encuentran en ambos lados del billete.';

  @override
  String get a50Mire2 => 'La marca de agua incluye tres elementos: la imagen del personaje histórico (Melchor Perez de Holguín), el cuadro de puntos ubicados al lado del personaje histórico y el valor del billete escrito en sentido vertical.';

  @override
  String get a50Mire3 => 'Figura geométrica impresa en el anverso y reverso del billete, que vista a contraluz encaja exactamente.';

  @override
  String get a50Toque1 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. El corte de Bs50 lleva una barra en alto relieve en posición vertical.';

  @override
  String get a50Toque2 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de Melchor Perez de Holguin está impresa en alto relieve.';

  @override
  String get a50Incline1 => 'El hilo de seguridad es de 3 milímetros de ancho y sobresale nítidamente en el anverso del billete, lleva la sigla BCB y el valor del billete; tiene un efecto de cambio de color  de magenta a verde que se observa  al inclinarlo.';

  @override
  String get a50Incline2 => 'Ubicada en el anverso del billete, al inclinarse se observa la sigla BCB.\n';

  @override
  String get a50Mireuv1 => 'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el anverso del billete:\n\ni)  Escudo del Estado Plurinacional de Bolivia.\n\nii) Valor del corte del billete.\n\niii) Firmas y números de serie.\n\niv) Figuras geométricas propias del corte.\n\nv)  Fibrillas de seguridad.\n\nvi) Hilo de seguridad.\n';

  @override
  String get a50Arte1 => 'Pintor Cochabambino de la época colonial, nace en 1660 y fallece en 1732. Es considerado el pintor más representativo del período colonial del Alto Perú.';

  @override
  String get r50Toque1 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de la Torre de la Compañía está impresa en alto relieve.';

  @override
  String get r50Incline1 => 'De color dorado, se encuentra presente en el reverso del billete a partir de la serie “H”. Lleva sobreimpreso el valor del corte “50” y la sigla BCB, que son fácilmente reconocibles al inclinar el billete.';

  @override
  String get r50Mireuv1 => 'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el reverso del billete:\n\ni)  Hilo de seguridad.\n\nii) Fibrillas de seguridad.';

  @override
  String get r50Arte1 => 'La Torre de la Compañía, es un convento ubicado en la ciudad de Potosí, junto al Cerro Rico y la Casa de la Moneda, fue trabajada durante siete años por el artífice Sebastián de la Cruz.';

  @override
  String get a50Mire1T => 'FIBRILLAS';

  @override
  String get a50Mire2T => 'MARCA DE AGUA';

  @override
  String get a50Mire3T => 'MOTIVO COINCIDENTE';

  @override
  String get a50Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get a50Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get a50Incline1T => 'HILO DE SEGURIDAD';

  @override
  String get a50Incline2T => 'IMAGEN LATENTE';

  @override
  String get a50Mireuv1T => 'FLUORESCENCIA ANVERSO';

  @override
  String get a50Arte1T => 'MELCHOR PEREZ DE HOLGUIN';

  @override
  String get r50Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get r50Incline1T => 'BANDA IRIDISCENTE';

  @override
  String get r50Mireuv1T => 'FLUORESCENCIA REVERSO';

  @override
  String get r50Arte1T => 'TORRE DE LA COMPAÑIA';

  @override
  String get a100Mire1 => 'Pequeños hilos de color amarillo, rojo, verde y azul, que se encuentran en ambos lados del billete.';

  @override
  String get a100Mire2 => 'La marca de agua incluye tres elementos: la imagen del personaje histórico (Gabriel René Moreno), el cuadro de puntos ubicados al lado del personaje histórico y el valor del billete escrito en sentido vertical.';

  @override
  String get a100Mire3 => 'Figura geométrica impresa en el anverso y reverso del billete, que vista a contraluz encaja exactamente.';

  @override
  String get a100Toque1 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. El corte de Bs100 lleva dos barras en alto relieve en posición vertical.';

  @override
  String get a100Toque2 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de Gabriel René Moreno está impresa en alto relieve.';

  @override
  String get a100Incline1 => 'El hilo de seguridad es de 4 milímetros de ancho y sobresale nítidamente en el anverso del billete, lleva la sigla BCB y el valor del billete; tiene un efecto de cambio de color  de verde a azul que se observa  al inclinarlo.';

  @override
  String get a100Incline2 => 'Ubicada en el anverso del billete, al inclinarse se observa la sigla BCB.\n';

  @override
  String get a100Mireuv1 => 'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el anverso del billete:\n\ni)  Escudo del Estado Plurinacional de Bolivia.\n\nii) Valor del corte del billete.\n\niii) Firmas y números de serie.\n\niv) Figuras geométricas propias del corte.\n\nv)  Fibrillas de seguridad.\n\nvi) Hilo de seguridad.\n';

  @override
  String get a100Arte1 => 'Destacado historiador y educador, nació en la ciudad de Santa Cruz el año 1836 y falleció en 1908, documentó la historia de Bolivia y creó una metodología de investigación histórica. En reconocimiento a su trayectoria la universidad estatal de la ciudad de Santa Cruz lleva su nombre.';

  @override
  String get r100Toque1 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de la Universidad San Francisco Xavier está impresa en alto relieve.';

  @override
  String get r100Incline1 => 'De color dorado, se encuentra presente en el reverso del billete, a partir de la serie “H”. Lleva sobreimpreso el valor del billete “100” y la sigla BCB, que son fácilmente reconocibles al inclinar el billete.';

  @override
  String get r100Mireuv1 => 'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el reverso del billete:\n\ni)  Hilo de seguridad.\n\nii) Fibrillas de seguridad.';

  @override
  String get r100Arte1 => 'Fue fundada el 27 de marzo de 1624, por el padre Jesuita Juan Frías de Herrán está ubicada en la ciudad de Sucre.';

  @override
  String get a100Mire1T => 'FIBRILLAS';

  @override
  String get a100Mire2T => 'MARCA DE AGUA';

  @override
  String get a100Mire3T => 'MOTIVO COINCIDENTE';

  @override
  String get a100Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get a100Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get a100Incline1T => 'HILO DE SEGURIDAD';

  @override
  String get a100Incline2T => 'IMAGEN LATENTE';

  @override
  String get a100Mireuv1T => 'FLUORESCENCIA ANVERSO';

  @override
  String get a100Arte1T => 'GABRIEL RENE MORENO';

  @override
  String get r100Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get r100Incline1T => 'BANDA IRIDISCENTE';

  @override
  String get r100Mireuv1T => 'FLUORESCENCIA REVERSO';

  @override
  String get r100Arte1T => 'UNIVERSIDAD SAN FRANCISCO XAVIER DE CHUQUISACA';

  @override
  String get a200Mire1 => 'Pequeños hilos de color amarillo, rojo, verde y azul, que se encuentran en ambos lados del billete.';

  @override
  String get a200Mire2 => 'La marca de agua incluye tres elementos: la imagen del personaje histórico (Franz Tamayo), el cuadro de puntos ubicados al lado del personaje histórico y el valor del billete escrito en sentido vertical.';

  @override
  String get a200Mire3 => 'Figura geométrica impresa en el anverso y reverso del billete, que vista a contraluz encaja exactamente.';

  @override
  String get a200Toque1 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. El corte de Bs200 lleva tres barras en alto relieve en posición vertical.';

  @override
  String get a200Toque2 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de Franz Tamayo está impresa en alto relieve.';

  @override
  String get a200Incline1 => 'El hilo de seguridad es de 4 milímetros de ancho y sobresale nítidamente en el anverso del billete, lleva la sigla BCB y el valor del billete; tiene un efecto de cambio de color  de oro a verde que se observa  al inclinarlo.';

  @override
  String get a200Incline2 => 'Ubicada en el anverso del billete, al inclinarse se observa la sigla BCB.\n';

  @override
  String get a200Mireuv1 => 'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el anverso del billete:\n\ni)  Escudo del Estado Plurinacional de Bolivia.\n\nii) Valor del corte del billete.\n\niii) Firmas y números de serie.\n\niv) Figuras geométricas propias del corte.\n\nv)  Fibrillas de seguridad.\n\nvi) Hilo de seguridad.\n\nvii) Motivo coincidente.';

  @override
  String get a200Arte1 => 'Poeta, político y diplomático boliviano, nace en La Paz en 1879 y fallece en 1956. Franz Tamayo Escribió virtuosas poesías que se convirtieron en las más representativas de Iberoamérica, como la “Prometheida” y “Odas”.';

  @override
  String get r200Toque1 => 'Son textos, numerales, imágenes y barras que sobresalen y son fáciles de percibir al tacto. La imagen de la cultura Tiahuanacota  está impresa en alto relieve.';

  @override
  String get r200Incline1 => 'De color dorado, se encuentra presente en el reverso del billete de Bs200 a partir de la serie “H”. Lleva sobreimpreso el valor del corte “200” y la sigla BCB, que son fácilmente reconocibles al inclinar el billete. ';

  @override
  String get r200Mireuv1 => 'Utilizando luz ultravioleta, se puede observar los siguientes elementos en el reverso del billete:\n\ni)  Hilo de seguridad.\n\nii) Fibrillas de seguridad.';

  @override
  String get r200Arte1 => 'Se muestra las milenarias ruinas pre-incaicas de Tiahuanaco, ubicadas en las cercanías del Lago Titicaca.';

  @override
  String get a200Mire1T => 'FIBRILLAS';

  @override
  String get a200Mire2T => 'MARCA DE AGUA';

  @override
  String get a200Mire3T => 'MOTIVO COINCIDENTE';

  @override
  String get a200Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get a200Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get a200Incline1T => 'HILO DE SEGURIDAD';

  @override
  String get a200Incline2T => 'IMAGEN LATENTE';

  @override
  String get a200Mireuv1T => 'FLUORESCENCIA ANVERSO';

  @override
  String get a200Arte1T => 'FRANZ TAMAYO';

  @override
  String get r200Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get r200Incline1T => 'BANDA IRIDISCENTE';

  @override
  String get r200Mireuv1T => 'FLUORESCENCIA REVERSO';

  @override
  String get r200Arte1T => 'CULTURA TIAHUANACOTA';

  @override
  String get na10Mire1 => 'Compuesta por tres elementos que vistos a contraluz reproducen:\n\ni) La imagen de José Santos Vargas.\n\nii) Un tambor al lado del personaje formado por puntos.\n\niii) El valor del billete “10” en la parte inferior.';

  @override
  String get na10Mire2 => 'Pequeños y delgados hilos de color rojo, amarillo, verde y azul que se encuentran inmersos y distribuidos al azar en todo el billete.';

  @override
  String get na10Mire3 => 'Impresiones en ambos lados del billete, en la parte inferior izquierda del anverso y derecha del reverso, que vistas a contraluz completan exactamente el número “10” entre el color azul y naranja.';

  @override
  String get na10Toque1 => 'En la parte superior izquierda debajo del número “10”, al igual que en la familia anterior, aparecen dos barras en alto relieve.';

  @override
  String get na10Toque2 => 'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.';

  @override
  String get na10Toque3 => 'En los bordes izquierdo y derecho del anverso del billete se sienten al tacto un bloque de 16 líneas cortas diagonales en alto relieve.';

  @override
  String get na10Toque4 => 'Es una impresión con relieve perceptible al tacto que se encuentra en los personajes, textos y valores del corte, “10”.';

  @override
  String get na10Toque5 => 'Los billetes están impresos en un papel especial de 100% algodón, cuyo grosor, calidad y textura son fáciles de sentir al tacto.';

  @override
  String get na10Incline1 => 'Imagen del valor del corte del billete “10”, ubicada sobre un cuadro azul en la parte inferior derecha del anverso, visible al inclinarlo.\n\n\n';

  @override
  String get na10Incline2 => 'Está ubicado en el anverso del billete, tiene 4 milímetros de ancho, lleva la imagen de José Santos Vargas y el valor del corte “10”. Al inclinarlo, cambia del color turquesa al azul.\n\n\n';

  @override
  String get na10Mireuv1 => 'En el anverso de los billetes se pueden observar los siguientes elementos:\n\ni)  El hilo de seguridad con fluorescencia roja, amarilla y verde.\n\nii) El Escudo del Estado Plurinacional de Bolivia, valor del corte, números de serie y firmas de las autoridades del BCB, con fluorescencia.\n\niii)Las fibrillas con fluorescencia roja, amarilla y azul';

  @override
  String get na10Arte1 => '(Oruro, 1796-s/f).\n\nGuerrillero que combatió alrededor de 10 años en la Guerra de la Independencia, hasta adquirir el rango de Comandante de Mohosa. Escribió un Diario que es considerado uno de los documentos más fascinantes de esa lucha.';

  @override
  String get na10Arte2 => '(Región Guaraní, 1863-1892).\n\nLíder indígena guaraní que luchó contra el avasallamiento de las tierras de su pueblo y el abuso de poder de las autoridades de la época. Logró sobrevivir a la matanza de Kuruyuki (1892), pero luego fue apresado y ejecutado.';

  @override
  String get na10Arte3 => '(Tarija, 1784-1849).\n\nLíder guerrillero que durante la Guerra de la Independencia participó en las batallas de Tucumán (1812), Salta (1813) y la Tablada (1817). Promovió la incorporación de Tarija a la República de Bolivia, a pesar de los fuertes vínculos que mantenía con sus compañeros de lucha de Salta.';

  @override
  String get na10Arte4 => 'Gruta natural de múltiples galerías de roca caliza, en las cuales se formaron llamativas figuras, entre ellas un escenario teatral.\n\nSe constituye en la caverna más extensa (7.000 metros) y profunda (164 metros) de Bolivia. Es uno de los sitios turísticos más visitados del país.\n';

  @override
  String get nr10Mire1 => 'Consiste en formar exactamente el número “10” al unir los bordes izquierdo y derecho del reverso del billete.';

  @override
  String get nr10Mire2 => 'Impresiones en ambos lados del billete, en la parte inferior derecha del reverso e izquierda del anverso, que vistas a contraluz completan exactamente el número “10” entre el color naranja y azul.';

  @override
  String get nr10Toque1 => 'El número “10” y el texto “DIEZ BOLIVIANOS” están impresos en alto relieve.';

  @override
  String get nr10Toque2 => 'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.';

  @override
  String get nr10Toque3 => 'Las líneas horizontales en los bordes superior e inferior del billete están impresas en alto relieve.';

  @override
  String get nr10Incline1 => 'En el reverso del billete está impreso, con tinta especial, un Picaflor Gigante. Al inclinarlo muestra un efecto con movimiento de arriba hacia abajo, con cambio de color de oro a verde.\n';

  @override
  String get nr10Mireuv1 => 'En el reverso de los billetes se pueden observar con luz ultravioleta:\n\n i) La Puya Raimondi y el valor del corte con fluorescencia roja.\n\nii)Las fibrillas con fluorescencia roja, amarilla y azul.';

  @override
  String get nr10Arte1 => 'Atractivo turístico ubicado en medio del Salar de Uyuni, que a la distancia se asemeja a la figura de un pez.\n\nDesde su cumbre se observa el volcán Tunupa y el Salar de Uyuni, una de las maravillas naturales del mundo.\n';

  @override
  String get nr10Arte2 => 'Ave de la región andina que se caracteriza por su gran tamaño (hasta 22 centímetros) con relación a otras de su especie.\n\nTiene la habilidad de cambiar fácilmente de dirección mientras vuela, incluso en reversa. Se mantiene suspendida en el aire para alimentarse del néctar de la flora del lugar.\n';

  @override
  String get nr10Arte3 => 'Planta de gran tamaño que supera los 10 metros, propia de la zona andina, cuya floración ocurre una sola vez cuando llega a una edad aproximada de 80 años, para luego morir.\n\nPor la constante disminución de su población, se encuentra en peligro de extinción.\n';

  @override
  String get na10Mire1T => 'MARCA DE AGUA';

  @override
  String get na10Mire2T => 'FIBRILLAS';

  @override
  String get na10Mire3T => 'MOTIVO COINCIDENTE';

  @override
  String get na10Toque1T => 'BARRAS EN ALTO RELIEVE';

  @override
  String get na10Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get na10Toque3T => 'LINEAS EN ALTO RELIEVE';

  @override
  String get na10Toque4T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get na10Toque5T => 'CALIDAD DEL PAPEL';

  @override
  String get na10Incline1T => 'IMAGEN LATENTE';

  @override
  String get na10Incline2T => 'HILO DE SEGURIDAD';

  @override
  String get na10Mireuv1T => 'FLUORESCENCIA ANVERSO';

  @override
  String get na10Arte1T => 'JOSÉ SANTOS VARGAS “EL TAMBOR VARGAS”';

  @override
  String get na10Arte2T => 'APIAGUAIKI TÜPA';

  @override
  String get na10Arte3T => 'EUSTAQUIO MÉNDEZ “EL MOTO MÉNDEZ”';

  @override
  String get na10Arte4T => 'CAVERNA DE UMAJALANTA, TOROTORO';

  @override
  String get nr10Mire1T => 'IMPRESION CONTINUA';

  @override
  String get nr10Mire2T => 'MOTIVO COINCIDENTE';

  @override
  String get nr10Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr10Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr10Toque3T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr10Incline1T => 'IMAGEN CON CAMBIO DE COLOR Y MOVIMIENTO';

  @override
  String get nr10Mireuv1T => 'FLUORESCENCIA REVERSO';

  @override
  String get nr10Arte1T => 'ISLA DEL PESCADO, SALAR DE UYUNI';

  @override
  String get nr10Arte2T => 'PICAFLOR GIGANTE';

  @override
  String get nr10Arte3T => 'PUYA RAIMONDI';

  @override
  String get na20Mire1 => 'Compuesta por tres elementos que vistos a contraluz reproducen:\n\ni) La imagen de Genoveva Ríos.\n\nii) Una bandera al lado del personaje formada por puntos.\n\niii) El número “20” en la parte inferior.';

  @override
  String get na20Mire2 => 'Pequeños y delgados hilos de color rojo, amarillo, verde y azul que se encuentran inmersos y distribuidos al azar en todo el billete.';

  @override
  String get na20Mire3 => 'Impresiones en ambos lados del billete, en la parte inferior izquierda del anverso y derecha del reverso, que vistas a contraluz completan exactamente el número “20” entre el color naranja y azul.';

  @override
  String get na20Toque1 => 'En la parte superior izquierda debajo del número “20”, al igual que en la familia anterior, aparecen tres barras en alto relieve.';

  @override
  String get na20Toque2 => 'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.';

  @override
  String get na20Toque3 => 'En los bordes izquierdo y derecho del anverso del billete se sienten al tacto 2 bloques de 6 líneas cortas diagonales en alto relieve.';

  @override
  String get na20Toque4 => 'Es una impresión con relieve que se siente al tacto y se encuentra en los personajes, textos y el número “20”.';

  @override
  String get na20Toque5 => 'Los billetes están impresos en un papel especial de 100% algodón, cuyo grosor, calidad y textura son fáciles de sentir al tacto.';

  @override
  String get na20Incline1 => 'Imagen del número “20”, ubicada sobre un cuadro naranja en la parte inferior derecha del anverso, visible al inclinarlo.\n\n\n';

  @override
  String get na20Incline2 => 'Está ubicado en el anverso del billete, tiene 4 milímetros de ancho, lleva la imagen de Genoveva Ríos y el número “20”. Al inclinarlo cambia de color de naranja a verde.\n\n\n';

  @override
  String get na20Mireuv1 => 'En el anverso de los billetes se pueden observar los siguientes elementos:\n\ni)  El hilo de seguridad con fluorescencia roja, amarilla y verde.\n\nii) El Escudo del Estado Plurinacional de Bolivia, valor del corte, números de serie y firmas de las autoridades del BCB, con fluorescencia.\n\niii) Las fibrillas con fluorescencia roja, amarilla y azul';

  @override
  String get na20Arte1 => '(Litoral, 1865 - s/f) .\n\nNiña que rescató la bandera boliviana que flameaba en la Intendencia de Policía de Antofagasta, resguardándola debajo de su ropa para evitar el ultraje del símbolo patrio por los invasores chilenos. En 1904 la bandera fue entregada al cónsul de Bolivia en Iquique y retornó al país 10 años después.';

  @override
  String get na20Arte2 => '(Potosí, 1740-1781).\n\nLíder indígena potosino que denunció ante el Virrey del Río de la Plata, la extorsión económica y abusos de las autoridades coloniales. Su encarcelamiento motivó la rebelión de Pocoata (Chayanta, 1780). Una vez libre, como autoridad impartió justicia hasta que fue capturado y asesinado por los españoles. La sublevación continuó con su esposa y hermanos.';

  @override
  String get na20Arte3 => '(Beni, s/f-1811).\n\nPrócer mojeño-trinitario que encabezó y motivó las rebeliones de los pueblos de la región en contra de la opresión de las instituciones coloniales. Sobrevivió a la masacre de Trinidad (1811), posteriormente fue apresado y asesinado. Este sacrificio   permitió instaurar un gobierno indígena hasta 1822.';

  @override
  String get na20Arte4 => 'Monumento arqueológico que fue un centro ceremonial, administrativo y habitacional precolombino, situado en Santa Cruz y declarado Patrimonio Cultural de la Humanidad por la UNESCO en 1998: “La gigantesca roca esculpida que domina la ciudad desde lo alto, es un testimonio único en su género de las tradiciones prehispánicas y no tiene comparación en toda América”.\n';

  @override
  String get nr20Mire1 => 'Consiste en formar exactamente el número “20” al unir los bordes izquierdo y derecho del reverso del billete.';

  @override
  String get nr20Mire2 => 'Impresiones en ambos lados del billete, en la parte inferior derecha del reverso e izquierda del anverso, que vistas a contraluz completan exactamente el número “20” entre el color azul y naranja.';

  @override
  String get nr20Toque1 => 'El número “20” y el texto “VEINTE BOLIVIANOS” están impresos en alto relieve.';

  @override
  String get nr20Toque2 => 'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.';

  @override
  String get nr20Toque3 => 'Las líneas horizontales en los bordes superior e inferior del billete están impresas en alto relieve.';

  @override
  String get nr20Incline1 => 'En el reverso del billete está impreso, con tinta especial, un Caimán Negro. Al inclinarlo muestra un efecto con movimiento de izquierda a derecha y cambio de color de oro a verde.\n\n';

  @override
  String get nr20Mireuv1 => 'En el reverso de los billetes se pueden observar con luz ultravioleta:\n\ni)El Árbol Toborochi y el valor del corte con fluorescencia roja.\n\nii)Las fibrillas con fluorescencia roja, amarilla y azul.';

  @override
  String get nr20Arte1 => 'Es uno de los principales atractivos turísticos de la Reserva Nacional de Vida Silvestre Amazónica Manuripi (Pando), conocido como el “acuario de Bolivia” por sus aguas cristalinas y la variedad de peces que pueden ser observados. Está rodeada de un exuberante paisaje de bosque que alberga gran biodiversidad en flora y fauna.';

  @override
  String get nr20Arte2 => 'Es uno de los reptiles más grandes de la Amazonía y puede sobrepasar los 6 metros de largo. Tiene el dorso oscuro y vientre claro, conformación robusta y su cola le permite nadar en ríos y lagunas.\n\nSu caza está prohibida por ser una especie vulnerable (Libro Rojo de la Fauna Silvestre de Vertebrados de Bolivia).\n';

  @override
  String get nr20Arte3 => 'Especie tradicional del oriente y sudeste del país, de gran altura (6 a 12 metros) que se caracteriza por tener un tronco abultado y con aguijones que almacena agua para la época seca. Florece en otoño y es popular por las leyendas religiosas y tradicionales de varios pueblos indígenas.';

  @override
  String get na20Mire1T => 'MARCA DE AGUA';

  @override
  String get na20Mire2T => 'FIBRILLAS';

  @override
  String get na20Mire3T => 'MOTIVO COINCIDENTE';

  @override
  String get na20Toque1T => 'BARRAS EN ALTO RELIEVE';

  @override
  String get na20Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get na20Toque3T => 'LINEAS EN ALTO RELIEVE';

  @override
  String get na20Toque4T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get na20Toque5T => 'CALIDAD DEL PAPEL';

  @override
  String get na20Incline1T => 'IMAGEN LATENTE';

  @override
  String get na20Incline2T => 'HILO DE SEGURIDAD';

  @override
  String get na20Mireuv1T => 'FLUORESCENCIA ANVERSO';

  @override
  String get na20Arte1T => 'GENOVEVA RÍOS';

  @override
  String get na20Arte2T => 'TOMÁS KATARI';

  @override
  String get na20Arte3T => 'PEDRO IGNACIO MUIBA';

  @override
  String get na20Arte4T => 'FUERTE DE SAMAYPATA';

  @override
  String get nr20Mire1T => 'IMPRESION CONTINUA';

  @override
  String get nr20Mire2T => 'MOTIVO COINCIDENTE';

  @override
  String get nr20Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr20Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr20Toque3T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr20Incline1T => 'IMAGEN CON CAMBIO DE COLOR Y MOVIMIENTO';

  @override
  String get nr20Mireuv1T => 'FLUORESCENCIA REVERSO';

  @override
  String get nr20Arte1T => 'LAGUNA BAY';

  @override
  String get nr20Arte2T => 'CAIMÁN NEGRO';

  @override
  String get nr20Arte3T => 'ÁRBOL TOBOROCHI';

  @override
  String get na50Mire1 => 'Compuesta por tres elementos que vistos a contraluz reproducen:\n\ni) La imagen de José Manuel Baca “Cañoto”.\n\nii) Una guitarra al lado del personaje formada por puntos.\n\niii) El número “50” en la parte inferior.';

  @override
  String get na50Mire2 => 'Pequeños y delgados hilos de color rojo, amarillo, verde y azul que se encuentran inmersos y distribuidos al azar en todo el billete.';

  @override
  String get na50Mire3 => 'Impresiones en ambos lados del billete, en la parte inferior izquierda del anverso y derecha del reverso, que vistas a contraluz completan exactamente el número “50” entre el color violeta y naranja.';

  @override
  String get na50Toque1 => 'En la parte superior izquierda debajo del número “50”, al igual que en la familia anterior, aparece una barra vertical en alto relieve.';

  @override
  String get na50Toque2 => 'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.';

  @override
  String get na50Toque3 => 'En los bordes izquierdo y derecho del anverso del billete se sienten al tacto tres bloques de cuatro líneas cortas diagonales en alto relieve.';

  @override
  String get na50Toque4 => 'Es una impresión con relieve que se siente al tacto y se encuentra en los personajes, textos y el número “50”.';

  @override
  String get na50Toque5 => 'Los billetes están impresos en un papel especial de 100% algodón, cuyo grosor, calidad y textura son fáciles de sentir al tacto.';

  @override
  String get na50Incline1 => 'Imagen del número “50”, ubicada sobre un cuadro violeta con espiral en la parte inferior derecha del anverso, visible al inclinarlo.\n\n\n';

  @override
  String get na50Incline2 => 'Está ubicado en el anverso del billete, tiene 4 milímetros de ancho, lleva la imagen de José Manuel Baca “Cañoto” y el número “50”. Al inclinarlo cambia de color de verde al azul.\n\n\n';

  @override
  String get na50Mireuv1 => 'En el anverso de los billetes se pueden observar los siguientes elementos:\n\ni)  El hilo de seguridad con fluorescencia roja, amarilla y verde.\n\nii) El Escudo del Estado Plurinacional de Bolivia, valor del corte, números de serie y firmas de las autoridades del BCB, con fluorescencia.\n\niii) Las fibrillas con fluorescencia roja, amarilla y azul';

  @override
  String get na50Arte1 => '(Santa Cruz, 1790-1854).\n\nGuerrillero, cantor y poeta que participó del primer levantamiento libertario en suelo cruceño y en las batallas de La Florida, Santa Bárbara y El Pari. Audaz e ingenioso, hostigaba constantemente a los realistas. Exiliado en las Provincias Unidas del Río de la Plata, fue capitán de la tropa de gauchos de Güemes y a su retorno, junto con otros patriotas, luchó hasta alcanzar la independencia.';

  @override
  String get na50Arte2 => '(Ixiamas, actualmente norte de La Paz, s/f).\n\nHéroe indígena tacana, trabajador siringuero que formó parte de la Columna Porvenir en la Batalla de Bahía (1902), durante la Guerra del Acre. Con un grupo de flecheros atacó e incendió los depósitos de municiones del enemigo, acción  que detuvo el avance de grupos separatistas y consolidó la soberanía boliviana sobre lo que hoy es Pando.';

  @override
  String get na50Arte3 => '(La Paz, s/f - 1905).\n\nLíder aymara que luchó contra los abusos hacia los indígenas y por la recuperación de las tierras comunales. Encabezó un ejército de indígenas originarios y fue un notable luchador social. Su proyecto político, con mayor participación indígena, fue visto como amenaza por la oligarquía que lo apresó y asesinó.\n';

  @override
  String get na50Arte4 => 'Monumento arqueológico ubicado en el municipio de Pocona, Cochabamba, construido por los incas. Tiene sectores defensivos, administrativos-públicos, ceremoniales, de resguardo, almacenaje y habitacionales. Entre sus construcciones en piedra y barro destaca la enorme Kallanka o galpón rectangular de una sola nave (2.020 m(sup)2(/sup)), única en América precolombina.\n';

  @override
  String get nr50Mire1 => 'Consiste en formar exactamente el número “50” al unir los bordes izquierdo y derecho del reverso del billete.';

  @override
  String get nr50Mire2 => 'Impresiones en ambos lados del billete, en la parte inferior derecha del reverso e izquierda del anverso, que vistas a contraluz completan exactamente el número “50” entre el color violeta y naranja.';

  @override
  String get nr50Toque1 => 'El número “50” y el texto “CINCUENTA BOLIVIANOS” están impresos en alto relieve.';

  @override
  String get nr50Toque2 => 'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.';

  @override
  String get nr50Toque3 => 'Las líneas horizontales en los bordes superior e inferior del billete están impresas en alto relieve.';

  @override
  String get nr50Incline1 => 'En el reverso del billete está impreso, con tinta especial y aspecto de abanico, un Flamenco Andino. Al inclinarlo de arriba hacia abajo muestra un efecto de movimiento radial que cambia de color de oro a verde.\n\n';

  @override
  String get nr50Mireuv1 => 'En el reverso de los billetes se pueden observar con luz ultravioleta:\n\ni) La Quinua Real y el valor del corte con fluorescencia roja.\n\nii) Las fibrillas con fluorescencia roja, amarilla y azul.';

  @override
  String get nr50Arte1 => 'Montaña más alta de Bolivia (6.542 m s.n.m.) que se encuentra en la Cordillera Occidental y es el principal atractivo del Parque Nacional Sajama, Oruro. \nTiene una forma cónica y simétrica de gran belleza paisajística. \nEn sus alrededores existen ecosistemas únicos como bofedales, tholares, bosques de Queñua y fauna en peligro de extinción como el Quirquincho, Puma, Suri, Gato Andino, entre otros.';

  @override
  String get nr50Arte2 => 'Ave que habita en lagos y lagunas poco profundas del altiplano, con un plumaje de color predominantemente rosa. Tiene un pico con adaptaciones que le permiten alimentarse de microorganismos acuáticos. Es el flamenco más grande de Bolivia (105 cm de altura), muy vulnerable a predadores y recolectores de huevos, por lo que es una especie amenazada.\n';

  @override
  String get nr50Arte3 => 'Planta milenaria con flores de varios colores, de interés mundial para la seguridad alimentaria, es cultivada en condiciones extremas de altura, temperatura, humedad y salinidad de los suelos de la región sur andina. Su grano, de hasta 2,5 milímetros, es reconocido internacionalmente por ser un alimento rico en proteínas de alto valor nutricional y su producción orgánica certificada.';

  @override
  String get na50Mire1T => 'MARCA DE AGUA';

  @override
  String get na50Mire2T => 'FIBRILLAS';

  @override
  String get na50Mire3T => 'MOTIVO COINCIDENTE';

  @override
  String get na50Toque1T => 'BARRAS EN ALTO RELIEVE';

  @override
  String get na50Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get na50Toque3T => 'LINEAS EN ALTO RELIEVE';

  @override
  String get na50Toque4T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get na50Toque5T => 'CALIDAD DEL PAPEL';

  @override
  String get na50Incline1T => 'IMAGEN LATENTE';

  @override
  String get na50Incline2T => 'HILO DE SEGURIDAD';

  @override
  String get na50Mireuv1T => 'FLUORESCENCIA ANVERSO';

  @override
  String get na50Arte1T => 'JOSÉ MANUEL BACA “CAÑOTO”';

  @override
  String get na50Arte2T => 'BRUNO RACUA';

  @override
  String get na50Arte3T => 'PABLO ZÁRATE WILLKA';

  @override
  String get na50Arte4T => 'FORTALEZA DE INKALLAJTA';

  @override
  String get nr50Mire1T => 'IMPRESION CONTINUA';

  @override
  String get nr50Mire2T => 'MOTIVO COINCIDENTE';

  @override
  String get nr50Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr50Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr50Toque3T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr50Incline1T => 'IMAGEN CON CAMBIO DE COLOR Y MOVIMIENTO';

  @override
  String get nr50Mireuv1T => 'FLUORESCENCIA REVERSO';

  @override
  String get nr50Arte1T => 'NEVADO SAJAMA';

  @override
  String get nr50Arte2T => 'FLAMENCO ANDINO';

  @override
  String get nr50Arte3T => 'QUINUA REAL';

  @override
  String get na100Mire1 => 'Compuesta por tres elementos que vistos a contraluz reproducen:\n\ni) La imagen de Juana Azurduy de Padilla.\n\nii) Un caballo al lado del personaje formado por puntos.\n\niii) El número “100” en la parte inferior.';

  @override
  String get na100Mire2 => 'Pequeños y delgados hilos de color rojo, amarillo, verde y azul que se encuentran inmersos y distribuidos al azar en todo el billete.';

  @override
  String get na100Mire3 => 'Impresiones en ambos lados del billete, en la parte inferior izquierda del anverso y derecha del reverso, que vistas a contraluz completan exactamente el número “100” entre el color rojo y azul.';

  @override
  String get na100Toque1 => 'En la parte superior izquierda debajo del número “100”, al igual que en la familia anterior, aparece dos barras verticales en alto relieve.';

  @override
  String get na100Toque2 => 'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.';

  @override
  String get na100Toque3 => 'En los bordes izquierdo y derecho del anverso del billete se sienten al tacto 4 bloques, cada uno de 3 líneas cortas diagonales en alto relieve.';

  @override
  String get na100Toque4 => 'Es una impresión con relieve que se siente al tacto y se encuentra en los personajes, textos y el número “100”.';

  @override
  String get na100Toque5 => 'Los billetes están impresos en un papel especial de 100% algodón, cuyo grosor, calidad y textura son fáciles de sentir al tacto.';

  @override
  String get na100Incline1 => 'Imagen del número “100”, ubicada sobre un cuadro rojo con arcos en la parte inferior derecha del anverso, visible al inclinarlo.\n\n\n';

  @override
  String get na100Incline2 => 'Está ubicado en el anverso del billete, tiene 4 milímetros de ancho, lleva la imagen de Juana Azurduy de Padilla y el número “100”. Al inclinarlo cambia de color de rojo a dorado.\n\n\n';

  @override
  String get na100Mireuv1 => 'En el anverso de los billetes se pueden observar los siguientes elementos:\n\ni)  El hilo de seguridad con fluorescencia roja, amarilla y verde.\n\nii) El Escudo del Estado Plurinacional de Bolivia, valor del corte, números de serie y firmas de las autoridades del BCB, con fluorescencia.\n\niii) Las fibrillas con fluorescencia roja, amarilla y azul';

  @override
  String get na100Arte1 => '(Chuquisaca, 1780 - 1862).\n\nMujer, madre y guerrillera valiente de América del Sur que en la lucha por la libertad perdió su tierra, a su esposo, Manuel Ascencio Padilla, y a cuatro de sus hijos. Organizó y lideró los batallones “Leales” y “Húsares” con indígenas y mestizos, apoyó la campaña de los ejércitos auxiliares argentinos y participó en las batallas de Tarvita, El Villar y La Laguna, entre otras.\n\nEn reconocimiento póstumo a su heroica lucha, el Ejército Argentino, del cual formó parte, le otorgó el grado de Generala (2009) y el Ejército Boliviano, de Mariscal (2011).';

  @override
  String get na100Arte2 => '(Cochabamba,  1705 - 1731).\n\nArtesano platero que encabezó la primera y más importante rebelión mestiza frente a las autoridades coloniales, particularmente contra los abusos y el corrupto régimen tributario, en la Villa de Oropesa, hoy Cochabamba (1730).\n\nEn ese levantamiento derrotó a las fuerzas realistas en la colina de San Sebastián, para instaurar un gobierno de criollos y conservar sus derechos. Fue detenido, torturado y ejecutado.';

  @override
  String get na100Arte3 => '(Cumaná - Venezuela, 1795-1830).\n\nEstratega militar, político y prócer de la independencia sudamericana que venció a los españoles en las batallas de Pichincha (1822) y Ayacucho (1824), logrando la libertad de varios países.\n\nFue el segundo Presidente de Bolivia que adoptó medidas administrativas para la organización del Estado. Puso en vigencia la primera Constitución del país y reivindicó los derechos de los indígenas con reformas de impacto social.\n';

  @override
  String get na100Arte4 => 'Construida en Potosí entre 1759 y 1773, es la mayor obra de arquitectura civil colonial en el territorio boliviano.\n\nPreserva y exhibe tecnologías de acuñación de monedas de distintas épocas; y una valiosa colección de numismática propia que incluye piezas que circularon en todo el mundo. Se constituye en uno de los repositorios históricos más importantes de la región.\n';

  @override
  String get nr100Mire1 => 'Consiste en formar exactamente el número “100” al unir los bordes izquierdo y derecho del reverso del billete.';

  @override
  String get nr100Mire2 => 'Impresiones en ambos lados del billete, en la parte inferior derecha del reverso e izquierda del anverso, que vistas a contraluz completan exactamente el número “100” entre el color violeta y naranja.';

  @override
  String get nr100Toque1 => 'El número “100” y el texto “CIEN BOLIVIANOS” están impresos en alto relieve.';

  @override
  String get nr100Toque2 => 'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.';

  @override
  String get nr100Toque3 => 'Las líneas horizontales en los bordes superior e inferior del billete están impresas en alto relieve.';

  @override
  String get nr100Incline1 => 'En el reverso del billete está impresa con tinta especial una Paraba Azul. Al inclinar el billete de izquierda a derecha o de arriba hacia abajo, muestra círculos que se mueven y cambian de color, del verde al azul.\n\n';

  @override
  String get nr100Mireuv1 => 'En el reverso de los billetes se pueden observar con luz ultravioleta:\n\ni) La Flor Patujú y el valor del corte con fluorescencia roja.\n\nii) Las fibrillas con fluorescencia roja, amarilla y azul.';

  @override
  String get nr100Arte1 => 'Es uno de los principales atractivos turísticos del Parque Nacional Noel Kempff Mercado, ubicado en Santa Cruz, declarado Patrimonio Natural de la Humanidad por la UNESCO (2002).\n\nEstas cataratas constituyen un salto ininterrumpido de agua del río Paucerna, que se destacan por su gran altura (88 metros).';

  @override
  String get nr100Arte2 => 'Paraba del oriente boliviano que se caracteriza por su gran tamaño (100 cm), plumaje azul, anillos oculares y mandíbula inferior amarillos, además de su pico fuerte de color negro.\n\nEl tráfico ilegal y la pérdida de su hábitat la ubican en la categoría de especie vulnerable a nivel internacional.\n';

  @override
  String get nr100Arte3 => 'Es un símbolo patrio cuyos pétalos en forma de espadines, matizados con los colores de la bandera de Bolivia, encarna la identidad del país.\n\nEsta flor, originaria de los llanos orientales, entrelazada con la Kantuta, representan la unión e interculturalidad de las regiones del Estado Plurinacional.\n';

  @override
  String get na100Mire1T => 'MARCA DE AGUA';

  @override
  String get na100Mire2T => 'FIBRILLAS';

  @override
  String get na100Mire3T => 'MOTIVO COINCIDENTE';

  @override
  String get na100Toque1T => 'BARRAS EN ALTO RELIEVE';

  @override
  String get na100Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get na100Toque3T => 'LINEAS EN ALTO RELIEVE';

  @override
  String get na100Toque4T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get na100Toque5T => 'CALIDAD DEL PAPEL';

  @override
  String get na100Incline1T => 'IMAGEN LATENTE';

  @override
  String get na100Incline2T => 'HILO DE SEGURIDAD';

  @override
  String get na100Mireuv1T => 'FLUORESCENCIA ANVERSO';

  @override
  String get na100Arte1T => 'JUANA AZURDUY DE PADILLA';

  @override
  String get na100Arte2T => 'ALEJO CALATAYUD';

  @override
  String get na100Arte3T => 'ANTONIO JOSÉ DE SUCRE';

  @override
  String get na100Arte4T => 'CASA DE LA MONEDA';

  @override
  String get nr100Mire1T => 'IMPRESION CONTINUA';

  @override
  String get nr100Mire2T => 'MOTIVO COINCIDENTE';

  @override
  String get nr100Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr100Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr100Toque3T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr100Incline1T => 'IMAGEN CON CAMBIO DE COLOR Y MOVIMIENTO';

  @override
  String get nr100Mireuv1T => 'FLUORESCENCIA REVERSO';

  @override
  String get nr100Arte1T => 'CATARATAS ARCO IRIS';

  @override
  String get nr100Arte2T => 'PARABA AZUL';

  @override
  String get nr100Arte3T => 'FLOR PATUJÚ';

  @override
  String get na200Mire1 => 'Compuesta por tres elementos que vistos a contraluz reproducen:\n\ni) La imagen de Tupak Katari.\n\nii) Un pututu (cuerno de toro) al lado del personaje formado por puntos.\n\niii) El número “200” en la parte inferior.';

  @override
  String get na200Mire2 => 'Pequeños y delgados hilos de color rojo, amarillo, verde y azul que se encuentran inmersos y distribuidos al azar en todo el billete.';

  @override
  String get na200Mire3 => 'Impresiones en ambos lados del billete, en la parte inferior izquierda del anverso y derecha del reverso, que vistas a contraluz completan exactamente el número “200” entre el color café y verde.\n';

  @override
  String get na200Toque1 => 'En la parte superior izquierda debajo del número “200”, al igual que en la familia anterior, aparece tres barras verticales en alto relieve.';

  @override
  String get na200Toque2 => 'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.';

  @override
  String get na200Toque3 => 'En los bordes izquierdo y derecho del anverso del billete se sienten al tacto 5 bloques, cada uno de 2 líneas cortas diagonales en alto relieve.';

  @override
  String get na200Toque4 => 'Es una impresión con relieve que se siente al tacto y se encuentra en los personajes, textos y los números “200”.';

  @override
  String get na200Toque5 => 'Los billetes están impresos en un papel especial de 100% algodón, cuyo grosor, calidad y textura son fáciles de sentir al tacto.';

  @override
  String get na200Incline1 => 'Imagen del número “200”, sobre un cuadro café que incluye una estrella. Está ubicada en la parte inferior derecha del anverso, es visible al inclinar el billete.\n\n\n';

  @override
  String get na200Incline2 => 'Ubicado en el anverso del billete, tiene 3 milímetros de ancho, muestra el número \'200\' dentro de un rombo que se intercala con otros de menor tamaño. Al inclinar el billete de arriba hacia abajo, los bordes de los rombos se mueven de adentro hacia afuera.\n\n\n';

  @override
  String get na200Mireuv1 => 'En el anverso de los billetes se pueden observar los siguientes elementos:\n\ni)  El hilo de seguridad con fluorescencia amarilla.\n\nii) El Escudo del Estado Plurinacional de Bolivia, valor del corte, números de serie y firmas de las autoridades del BCB, con fluorescencia.\n\niii) Las fibrillas con fluorescencia roja, amarilla y azul';

  @override
  String get na200Arte1 => '(Julián Apaza, La Paz, 1750 - 1781).\n\nLíder de la lucha descolonizadora, que combatió junto a su esposa, Bartolina Sisa, y sus hermanos, Gregoria y Martín Apaza, en contra del dominio y opresión español.\n\nAliado de Túpac Amaru (José Gabriel Condorcanqui) en la gran rebelión indígena (1780 – 1782), logró cercar la ciudad de La Paz en dos oportunidades, extender su insurrección al Altiplano y Yungas e incorporar a sus filas al pueblo afro.\n\nFue traicionado, apresado y sentenciado a morir descuartizado por cuatro caballos en la plaza del Santuario de Peñas. Declarado en 2005 “Héroe Nacional Aymara”.\n';

  @override
  String get na200Arte2 => '(La Paz,  1750 - 1782).\n\nLuchadora aymara que protagonizó junto a su esposo, Julián Apaza (Tupak Katari), la gran rebelión indígena (1780 -1782). Se consideran defensores de las 36 naciones indígenas-originarias de Bolivia.\n\nDirigió a sus tropas en varias batallas, incluso en ausencia del gran líder durante el Primer Cerco a La Paz, y organizó la logística para el abastecimiento de los campamentos insurgentes.\n\nFue traicionada y encarcelada por más de un año. Enfrentó un juicio donde dignamente reivindicó la justicia de la causa indígena, hasta que fue sentenciada a muerte. Declarada “Heroína Nacional Aymara” en 2005.\n';

  @override
  String get na200Arte3 => '(Caracas - Venezuela, 1783-1830).\n\nLibertador de América que al mando de sus gloriosas tropas enfrentó al ejército español en cerca de 500 batallas y logró la independencia de Venezuela, Colombia, Ecuador, Perú y Bolivia.\n\nFue el fundador y primer Presidente de Bolivia. Organizó el país que inicialmente llevaba su nombre, adoptó medidas a favor de los indígenas, redimiéndolos de la esclavitud y explotación; les dotó de tierras, suprimió los tributos y la mita.\n\nEscribió y remitió la primera Constitución para su aprobación en 1826.\n\nTrasciende en la historia por su visión de conformar la Patria Grande y la lucha antiimperialista.\n';

  @override
  String get na200Arte4 => '(Sucre – Bolivia)\n\nPrimer Monumento Nacional donde se reunió la Asamblea Deliberante que declaró la independencia de Bolivia y se aprobó la primera Constitución Política del país.\n\nFue sede de la Universidad Mayor, Real y Pontificia de San Francisco Xavier (1624), una de las más importantes de la época, que formó a los protagonistas de la lucha  libertaria.\n\nEs un importante repositorio nacional que preserva invalorables bienes históricos y culturales de la época colonial y republicana.\n';

  @override
  String get nr200Mire1 => 'Consiste en formar exactamente el número “200” al unir los bordes izquierdo y derecho del reverso del billete.';

  @override
  String get nr200Mire2 => 'Impresiones en ambos lados del billete, en la parte inferior derecha del reverso e izquierda del anverso, que vistas a contraluz completan exactamente el número “200” entre el color café y verde.';

  @override
  String get nr200Toque1 => 'El número “200” y el texto “DOSCIENTOS BOLIVIANOS” están impresos en alto relieve.';

  @override
  String get nr200Toque2 => 'Tanto el texto “BANCO CENTRAL DE BOLIVIA”, como el texto “ESTADO PLURINACIONAL DE BOLIVIA”, están impresos en alto relieve.';

  @override
  String get nr200Toque3 => 'Las líneas horizontales en los bordes superior e inferior del billete están impresas en alto relieve.';

  @override
  String get nr200Incline1 => 'En el reverso del billete está impreso con tinta especial una Gato Andino. Al inclinar el billete de arriba hacia abajo, muestra un efecto de movimiento con cambio de color de azul a verde en el cuerpo del felino.\n\n';

  @override
  String get nr200Mireuv1 => 'En el reverso de los billetes se pueden observar con luz ultravioleta:\n\ni) La Kantuta y el valor del corte con fluorescencia roja.\n\nii) Las fibrillas con fluorescencia roja, amarilla y azul.';

  @override
  String get nr200Arte1 => 'Centro espiritual y político de la cultura de Tiwanaku, Patrimonio Cultural de la Humanidad (UNESCO - 2000) por su Valor Universal Excepcional expresado en la concepción y maestría constructiva de templos y esculturas monolíticas.\n\nEs el sitio arqueológico más importante del país, que comprende la Pirámide de Akapana, el Templete Semisubterráneo, el Templo de Kalasasaya, la Puerta del Sol, más de 200 estructuras habitacionales enterradas, canales, caminos y otros.\n\nTiwanaku testimonia la existencia y esplendor de una civilización prehispánica única y tecnológicamente avanzada.\n';

  @override
  String get nr200Arte2 => 'Felino de la región alto andina que se caracteriza por su tamaño mediano y pelaje gris con manchas café rojizas-amarillentas. Su cola gruesa y larga representa más del 65% de su cuerpo.\n\nTradicionalmente es considerado símbolo de fertilidad, protección y está estrechamente ligado a los espíritus de las montañas.\n\nLa afectación negativa a su hábitat y su caza furtiva lo convierten en uno de los gatos en Peligro Crítico.\n';

  @override
  String get nr200Arte3 => 'Símbolo patrio cuya flor, con forma acampanada, lleva los colores de la bandera tricolor y simboliza la identidad boliviana.\n\nEra considerada sagrada por los Incas y es originaria de la región occidental del país.\n\nEntrelazada a la Flor Patujú, representan la unión e interculturalidad de las regiones del Estado Plurinacional.\n';

  @override
  String get na200Mire1T => 'MARCA DE AGUA';

  @override
  String get na200Mire2T => 'FIBRILLAS';

  @override
  String get na200Mire3T => 'MOTIVO COINCIDENTE';

  @override
  String get na200Toque1T => 'BARRAS EN ALTO RELIEVE';

  @override
  String get na200Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get na200Toque3T => 'LINEAS EN ALTO RELIEVE';

  @override
  String get na200Toque4T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get na200Toque5T => 'CALIDAD DEL PAPEL';

  @override
  String get na200Incline1T => 'IMAGEN LATENTE';

  @override
  String get na200Incline2T => 'HILO DE SEGURIDAD DINAMICO';

  @override
  String get na200Mireuv1T => 'FLUORESCENCIA ANVERSO';

  @override
  String get na200Arte1T => 'TUPAK KATARI';

  @override
  String get na200Arte2T => 'BARTOLINA SISA';

  @override
  String get na200Arte3T => 'SIMÓN BOLÍVAR';

  @override
  String get na200Arte4T => 'CASA DE LA LIBERTAD';

  @override
  String get nr200Mire1T => 'IMPRESION CONTINUA';

  @override
  String get nr200Mire2T => 'MOTIVO COINCIDENTE';

  @override
  String get nr200Toque1T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr200Toque2T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr200Toque3T => 'IMPRESION EN ALTO RELIEVE';

  @override
  String get nr200Incline1T => 'IMAGEN CON CAMBIO DE COLOR Y MOVIMIENTO';

  @override
  String get nr200Mireuv1T => 'FLUORESCENCIA REVERSO';

  @override
  String get nr200Arte1T => 'TIWANAKU';

  @override
  String get nr200Arte2T => 'GATO ANDINO “TITI”';

  @override
  String get nr200Arte3T => 'KANTUTA';

  @override
  String get toque => 'Toque';

  @override
  String get mire => 'Mire';

  @override
  String get detalleArtistico => 'Detalle artístico';

  @override
  String get incline => 'Incline';

  @override
  String get mireUV => 'Mire ultravioleta';

  @override
  String get billetes => 'Billetes';

  @override
  String get lupa => 'Lupa';

  @override
  String get facebook => 'Facebook';

  @override
  String get twitter => 'Twitter';

  @override
  String get informacion => 'Información';

  @override
  String get cargando => 'Cargando...';

  @override
  String get instagram => 'Instagram';

  @override
  String get youTube => 'YouTube';

  @override
  String get tikTok => 'TikTok';

  @override
  String get linkedIn => 'LinkedIn';

  @override
  String get redesociales => 'Redes sociales';

  @override
  String get bancoCentralBolivia => 'Banco Central de Bolivia';
}
